'use client';
import { useEffect, useState } from 'react';
import { authApi, adminApi, documentApi } from '../lib/api';

type Stats = { total_providers: string; pending_approvals: string; active_providers: string; rejected: string; total_patients: string };
type Provider = { id: string; name: string; email: string; role: string; status: string; specialization?: string; location?: string; created_at: string };
type Document = { id: string; type: string; file_name: string; status: string; signed_url: string };
type Booking = { id: string; patient_name: string; patient_email: string; provider_name: string; provider_role: string; booking_date: string; booking_time: string; type: string; status: string; payment_status: string; amount: number; payment_id?: string; notes?: string; cancel_reason?: string; created_at: string };

export default function AdminApp() {
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState('admin@healthcare.com');
  const [password, setPassword] = useState('password');
  const [loginError, setLoginError] = useState('');
  const [stats, setStats] = useState<Stats | null>(null);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [selectedStatus, setSelectedStatus] = useState('');
  const [view, setView] = useState<'dashboard' | 'applications' | 'detail' | 'bookings'>('dashboard');
  const [selectedProvider, setSelectedProvider] = useState<any>(null);
  const [detailData, setDetailData] = useState<any>(null);
  const [remarks, setRemarks] = useState('');
  const [actionType, setActionType] = useState('');
  const [rejectingDocId, setRejectingDocId] = useState<string | null>(null);
  const [docRemarks, setDocRemarks] = useState('');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [bookingFilter, setBookingFilter] = useState('');

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (t) { setToken(t); fetchDashboard(); fetchProviders(); }
  }, []);

  const login = async () => {
    try {
      const res = await authApi.login(email, password);
      const { token: t, user } = res.data.data;
      if (user.role !== 'ADMIN') { setLoginError('Not an admin account'); return; }
      localStorage.setItem('token', t);
      setToken(t);
      fetchDashboard();
      fetchProviders();
    } catch (e: any) { setLoginError(e.response?.data?.message || 'Login failed'); }
  };

  const fetchDashboard = async () => {
    try { const r = await adminApi.dashboard(); setStats(r.data.data); } catch {}
  };

  const fetchProviders = async (status = '') => {
    try { const r = await adminApi.applications(status); setProviders(r.data.data); } catch {}
  };

  const fetchBookings = async () => {
    try { const r = await adminApi.allBookings(); setBookings(r.data.data); } catch {}
  };

  const openDetail = async (provider: Provider) => {
    try {
      const r = await adminApi.applicationDetail(provider.id);
      setDetailData(r.data.data);
      setSelectedProvider(provider);
      setView('detail');
    } catch { setMsg('Failed to load details'); }
  };

  const refreshDetail = async () => {
    if (!selectedProvider) return;
    const r = await adminApi.applicationDetail(selectedProvider.id);
    setDetailData(r.data.data);
    fetchDashboard();
    fetchProviders(selectedStatus);
  };

  const handleAccountAction = async () => {
    if (!selectedProvider) return;
    setLoading(true);
    try {
      if (actionType === 'approve') await adminApi.approve(selectedProvider.id);
      else if (actionType === 'reject') await adminApi.reject(selectedProvider.id, remarks);
      else await adminApi.requestChanges(selectedProvider.id, remarks);
      setMsg('Action successful!');
      setActionType('');
      setRemarks('');
      await refreshDetail();
    } catch (e: any) { setMsg(e.response?.data?.message || 'Error'); }
    finally { setLoading(false); }
  };

  const handleApproveDoc = async (docId: string, docType: string) => {
    setLoading(true);
    try {
      await documentApi.approve(docId);
      setMsg(`${docType.replace(/_/g, ' ')} approved!`);
      await refreshDetail();
    } catch (e: any) { setMsg(e.response?.data?.message || 'Error'); }
    finally { setLoading(false); }
  };

  const handleRejectDoc = async () => {
    if (!rejectingDocId || !docRemarks) { setMsg('Please enter a reason'); return; }
    setLoading(true);
    try {
      await documentApi.reject(rejectingDocId, docRemarks);
      setMsg('Document rejected.');
      setRejectingDocId(null);
      setDocRemarks('');
      await refreshDetail();
    } catch (e: any) { setMsg(e.response?.data?.message || 'Error'); }
    finally { setLoading(false); }
  };

  const logout = () => { localStorage.removeItem('token'); setToken(null); setStats(null); setProviders([]); setView('dashboard'); };

  const statusBadge = (s: string) => {
    const map: Record<string, string> = { REGISTERED: 'registered', ACTIVE: 'active', REJECTED: 'rejected', DOCUMENT_SUBMITTED: 'submitted', UNDER_REVIEW: 'review', NEEDS_UPDATE: 'needs_update', PROFILE_COMPLETED: 'pending', VERIFIED: 'active', APPROVED: 'active', PENDING: 'pending' };
    return <span className={`badge badge-${map[s] || 'pending'}`}>{s.replace(/_/g, ' ')}</span>;
  };

  const docStatusColor: Record<string, string> = { PENDING: '#d69e2e', APPROVED: '#38a169', REJECTED: '#e53e3e' };
  const bookingStatusColor: Record<string, string> = { CONFIRMED: '#38a169', CANCELLED: '#e53e3e', COMPLETED: '#3182ce', PAYMENT_PENDING: '#d69e2e', PENDING: '#718096' };
  const paymentStatusColor: Record<string, string> = { PAID: '#38a169', PENDING: '#d69e2e', FAILED: '#e53e3e', REFUNDED: '#718096' };

  const filteredBookings = bookings.filter(b => bookingFilter === '' || b.status === bookingFilter);

  // Booking stats
  const bookingStats = {
    total: bookings.length,
    confirmed: bookings.filter(b => b.status === 'CONFIRMED').length,
    completed: bookings.filter(b => b.status === 'COMPLETED').length,
    cancelled: bookings.filter(b => b.status === 'CANCELLED').length,
    revenue: bookings.filter(b => b.payment_status === 'PAID').reduce((sum, b) => sum + Number(b.amount), 0),
  };

  if (!token) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh' }}>
      <div className="card" style={{ width: 380 }}>
        <h1 style={{ fontSize: 24, fontWeight: 700, marginBottom: 8 }}>🏥 Healthcare Admin</h1>
        <p style={{ color: '#718096', marginBottom: 24 }}>Sign in to your admin dashboard</p>
        {loginError && <div style={{ background: '#fff5f5', color: '#c53030', padding: '10px', borderRadius: 6, marginBottom: 16, fontSize: 14 }}>{loginError}</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} type="email" />
          <input placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} type="password" />
          <button className="btn btn-primary" onClick={login} style={{ width: '100%', padding: '10px' }}>Sign In</button>
        </div>
        <p style={{ fontSize: 12, color: '#a0aec0', marginTop: 16, textAlign: 'center' }}>Default: admin@healthcare.com / password</p>
      </div>
    </div>
  );

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      {/* Sidebar */}
      <div style={{ width: 240, background: '#1a365d', color: 'white', padding: 24, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 20, fontWeight: 700 }}>🏥 HealthCare</div>
          <div style={{ fontSize: 12, color: '#90cdf4' }}>Admin Panel</div>
        </div>
        <button onClick={() => setView('dashboard')} style={{ background: view === 'dashboard' ? '#2b6cb0' : 'transparent', color: 'white', border: 'none', borderRadius: 8, padding: '10px 14px', textAlign: 'left', cursor: 'pointer', fontSize: 14 }}>📊 Dashboard</button>
        <button onClick={() => { setView('applications'); fetchProviders(selectedStatus); }} style={{ background: view === 'applications' || view === 'detail' ? '#2b6cb0' : 'transparent', color: 'white', border: 'none', borderRadius: 8, padding: '10px 14px', textAlign: 'left', cursor: 'pointer', fontSize: 14 }}>📋 Applications</button>
        <button onClick={() => { setView('bookings'); fetchBookings(); }} style={{ background: view === 'bookings' ? '#2b6cb0' : 'transparent', color: 'white', border: 'none', borderRadius: 8, padding: '10px 14px', textAlign: 'left', cursor: 'pointer', fontSize: 14 }}>🗓 Bookings</button>
        <div style={{ marginTop: 'auto' }}>
          <button onClick={logout} style={{ background: 'transparent', color: '#fc8181', border: 'none', cursor: 'pointer', fontSize: 14 }}>← Logout</button>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, padding: 32, overflow: 'auto' }}>
        {msg && <div style={{ background: '#f0fff4', color: '#276749', padding: 12, borderRadius: 8, marginBottom: 16 }}>{msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button></div>}

        {/* DASHBOARD */}
        {view === 'dashboard' && stats && (
          <>
            <h2 style={{ fontSize: 24, fontWeight: 700, marginBottom: 24 }}>Dashboard</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16 }}>
              {[
                { label: 'Total Providers', value: stats.total_providers, color: '#3182ce' },
                { label: 'Pending Approvals', value: stats.pending_approvals, color: '#d69e2e' },
                { label: 'Active Providers', value: stats.active_providers, color: '#38a169' },
                { label: 'Rejected', value: stats.rejected, color: '#e53e3e' },
                { label: 'Total Patients', value: stats.total_patients, color: '#805ad5' },
              ].map(s => (
                <div key={s.label} className="card" style={{ borderTop: `4px solid ${s.color}` }}>
                  <div style={{ fontSize: 32, fontWeight: 700, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: '#718096', marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* APPLICATIONS LIST */}
        {view === 'applications' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h2 style={{ fontSize: 24, fontWeight: 700 }}>Applications</h2>
              <select value={selectedStatus} onChange={e => { setSelectedStatus(e.target.value); fetchProviders(e.target.value); }} style={{ width: 200 }}>
                <option value="">All Statuses</option>
                {['REGISTERED','PROFILE_COMPLETED','DOCUMENT_SUBMITTED','UNDER_REVIEW','VERIFIED','REJECTED','NEEDS_UPDATE','ACTIVE'].map(s => (
                  <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>
                ))}
              </select>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {providers.map(p => (
                <div key={p.id} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: 600 }}>{p.name} <span style={{ color: '#718096', fontSize: 13 }}>({p.role})</span></div>
                    <div style={{ fontSize: 13, color: '#718096' }}>{p.email} · {p.specialization || p.location || 'No profile yet'}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    {statusBadge(p.status)}
                    <button className="btn btn-primary" style={{ fontSize: 12 }} onClick={() => openDetail(p)}>Review</button>
                  </div>
                </div>
              ))}
              {providers.length === 0 && <div className="card" style={{ textAlign: 'center', color: '#718096' }}>No applications found</div>}
            </div>
          </>
        )}

        {/* APPLICATION DETAIL */}
        {view === 'detail' && detailData && (
          <>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24 }}>
              <button onClick={() => { setView('applications'); setActionType(''); }} style={{ background: '#e2e8f0', border: 'none', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontSize: 13 }}>← Back</button>
              <h2 style={{ fontSize: 22, fontWeight: 700 }}>Review: {detailData.name}</h2>
              {statusBadge(detailData.status)}
            </div>
            <div className="card" style={{ marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700, marginBottom: 12 }}>👤 Profile Information</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 14 }}>
                <div><strong>Role:</strong> {detailData.role}</div>
                <div><strong>Email:</strong> {detailData.email}</div>
                <div><strong>Phone:</strong> {detailData.phone || 'N/A'}</div>
                <div><strong>Specialization:</strong> {detailData.specialization || 'N/A'}</div>
                <div><strong>Experience:</strong> {detailData.experience ? `${detailData.experience} years` : 'N/A'}</div>
                <div><strong>Location:</strong> {detailData.location || 'N/A'}</div>
                <div><strong>Fee:</strong> {detailData.consultation_fee ? `₹${detailData.consultation_fee}` : 'N/A'}</div>
                <div><strong>Languages:</strong> {Array.isArray(detailData.languages) ? detailData.languages.join(', ') : detailData.languages || 'N/A'}</div>
              </div>
              {detailData.bio && <div style={{ marginTop: 10, fontSize: 14, color: '#4a5568' }}><strong>Bio:</strong> {detailData.bio}</div>}
            </div>
            <div className="card" style={{ marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700, marginBottom: 12 }}>📄 Documents</h3>
              {detailData.documents && detailData.documents.length > 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {detailData.documents.map((doc: Document) => (
                    <div key={doc.id} style={{ border: `2px solid ${docStatusColor[doc.status] || '#e2e8f0'}`, borderRadius: 8, padding: 14 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                        <div>
                          <span style={{ fontWeight: 600, fontSize: 14 }}>{doc.type.replace(/_/g, ' ')}</span>
                          <span style={{ marginLeft: 10, fontSize: 12, color: '#718096' }}>{doc.file_name}</span>
                        </div>
                        <span style={{ background: docStatusColor[doc.status], color: 'white', padding: '3px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600 }}>{doc.status}</span>
                      </div>
                      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                        <a href={doc.signed_url} target="_blank" rel="noreferrer" style={{ background: '#ebf8ff', color: '#2b6cb0', padding: '6px 14px', borderRadius: 6, fontSize: 13, textDecoration: 'none', fontWeight: 500 }}>👁 View Document</a>
                        {doc.status !== 'APPROVED' && (
                          <button onClick={() => handleApproveDoc(doc.id, doc.type)} disabled={loading} style={{ background: '#f0fff4', color: '#276749', border: '1px solid #9ae6b4', borderRadius: 6, padding: '6px 14px', fontSize: 13, cursor: 'pointer', fontWeight: 500 }}>✓ Approve</button>
                        )}
                        {doc.status !== 'REJECTED' && (
                          <button onClick={() => setRejectingDocId(rejectingDocId === doc.id ? null : doc.id)} style={{ background: '#fff5f5', color: '#c53030', border: '1px solid #feb2b2', borderRadius: 6, padding: '6px 14px', fontSize: 13, cursor: 'pointer', fontWeight: 500 }}>✕ Reject</button>
                        )}
                      </div>
                      {rejectingDocId === doc.id && (
                        <div style={{ marginTop: 10, background: '#fff5f5', borderRadius: 6, padding: 10 }}>
                          <input placeholder="Reason for rejection..." value={docRemarks} onChange={e => setDocRemarks(e.target.value)} style={{ marginBottom: 8 }} />
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button className="btn btn-danger" style={{ fontSize: 12 }} onClick={handleRejectDoc} disabled={loading}>Confirm Reject</button>
                            <button className="btn" style={{ background: '#e2e8f0', fontSize: 12 }} onClick={() => { setRejectingDocId(null); setDocRemarks(''); }}>Cancel</button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ color: '#718096', fontSize: 14 }}>No documents uploaded yet</div>
              )}
            </div>
            <div style={{ background: '#ebf8ff', border: '1px solid #bee3f8', borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 13, color: '#2b6cb0' }}>
              💡 <strong>Auto-activation:</strong> Account becomes <strong>ACTIVE</strong> automatically once all required documents are approved.
            </div>
            {detailData.status !== 'ACTIVE' && (
              <div className="card">
                <h3 style={{ fontWeight: 700, marginBottom: 12 }}>⚡ Account Actions</h3>
                {!actionType ? (
                  <div style={{ display: 'flex', gap: 10 }}>
                    <button className="btn btn-success" onClick={() => setActionType('approve')}>✓ Force Approve</button>
                    <button className="btn btn-danger" onClick={() => setActionType('reject')}>✕ Reject Account</button>
                    <button className="btn btn-warning" onClick={() => setActionType('request')}>↩ Request Changes</button>
                  </div>
                ) : (
                  <div>
                    {actionType !== 'approve' && (
                      <div style={{ marginBottom: 12 }}>
                        <label style={{ display: 'block', marginBottom: 6, fontWeight: 500, fontSize: 13 }}>Remarks *</label>
                        <textarea value={remarks} onChange={e => setRemarks(e.target.value)} rows={3} placeholder="Enter reason..." />
                      </div>
                    )}
                    <div style={{ display: 'flex', gap: 10 }}>
                      <button className={`btn ${actionType === 'approve' ? 'btn-success' : actionType === 'reject' ? 'btn-danger' : 'btn-warning'}`} onClick={handleAccountAction} disabled={loading}>
                        {loading ? 'Processing...' : `Confirm ${actionType === 'approve' ? 'Approval' : actionType === 'reject' ? 'Rejection' : 'Request'}`}
                      </button>
                      <button className="btn" style={{ background: '#e2e8f0' }} onClick={() => { setActionType(''); setRemarks(''); }}>Cancel</button>
                    </div>
                  </div>
                )}
              </div>
            )}
            {detailData.status === 'ACTIVE' && (
              <div style={{ background: '#f0fff4', border: '1px solid #9ae6b4', borderRadius: 8, padding: 16, textAlign: 'center', color: '#276749', fontWeight: 600 }}>
                ✅ This provider is ACTIVE and visible to patients
              </div>
            )}
          </>
        )}

        {/* BOOKINGS */}
        {view === 'bookings' && (
          <>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h2 style={{ fontSize: 24, fontWeight: 700 }}>🗓 All Bookings</h2>
              <select value={bookingFilter} onChange={e => setBookingFilter(e.target.value)} style={{ width: 200 }}>
                <option value="">All Statuses</option>
                {['PAYMENT_PENDING','PENDING','CONFIRMED','COMPLETED','CANCELLED'].map(s => (
                  <option key={s} value={s}>{s.replace(/_/g,' ')}</option>
                ))}
              </select>
            </div>

            {/* Booking Stats */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: 12, marginBottom: 24 }}>
              {[
                { label: 'Total Bookings', value: bookingStats.total, color: '#3182ce' },
                { label: 'Confirmed', value: bookingStats.confirmed, color: '#38a169' },
                { label: 'Completed', value: bookingStats.completed, color: '#805ad5' },
                { label: 'Cancelled', value: bookingStats.cancelled, color: '#e53e3e' },
                { label: 'Total Revenue', value: `₹${bookingStats.revenue}`, color: '#d69e2e' },
              ].map(s => (
                <div key={s.label} className="card" style={{ borderTop: `4px solid ${s.color}`, padding: 14 }}>
                  <div style={{ fontSize: 24, fontWeight: 700, color: s.color }}>{s.value}</div>
                  <div style={{ fontSize: 12, color: '#718096', marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Bookings List */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {filteredBookings.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', color: '#718096', padding: 40 }}>
                  <div style={{ fontSize: 32, marginBottom: 8 }}>📭</div>
                  No bookings found
                </div>
              ) : (
                filteredBookings.map(b => (
                  <div key={b.id} className="card" style={{ borderLeft: `4px solid ${bookingStatusColor[b.status] || '#718096'}` }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 15 }}>
                          {b.patient_name} → {b.provider_name}
                          <span style={{ color: '#718096', fontSize: 12, fontWeight: 400, marginLeft: 8 }}>({b.provider_role})</span>
                        </div>
                        <div style={{ fontSize: 13, color: '#718096' }}>{b.patient_email}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 8, flexDirection: 'column', alignItems: 'flex-end' }}>
                        <span style={{ background: bookingStatusColor[b.status], color: 'white', padding: '3px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600 }}>{b.status}</span>
                        <span style={{ background: paymentStatusColor[b.payment_status] || '#718096', color: 'white', padding: '3px 12px', borderRadius: 20, fontSize: 11 }}>💳 {b.payment_status}</span>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 8, fontSize: 13, color: '#4a5568' }}>
                      <span>📅 {new Date(b.booking_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                      <span>🕐 {b.booking_time.slice(0, 5)}</span>
                      <span>{b.type === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}</span>
                      <span style={{ fontWeight: 600, color: '#276749' }}>💰 ₹{b.amount}</span>
                      {b.payment_id && <span style={{ fontSize: 11, color: '#718096' }}>ID: {b.payment_id}</span>}
                    </div>
                    {b.notes && <div style={{ fontSize: 12, color: '#718096', marginTop: 8 }}>📝 {b.notes}</div>}
                    {b.cancel_reason && <div style={{ fontSize: 12, color: '#e53e3e', marginTop: 6 }}>❌ {b.cancel_reason}</div>}
                    <div style={{ fontSize: 11, color: '#a0aec0', marginTop: 8 }}>Booked on {new Date(b.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
