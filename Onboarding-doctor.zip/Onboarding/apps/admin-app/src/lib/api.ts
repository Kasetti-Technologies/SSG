import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
const api = axios.create({ baseURL: API_URL });

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authApi = {
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
};

export const adminApi = {
  dashboard: () => api.get('/admin/dashboard'),
  applications: (status?: string) => api.get(`/admin/applications${status ? `?status=${status}` : ''}`),
  applicationDetail: (userId: string) => api.get(`/admin/applications/${userId}`),
  approve: (userId: string) => api.post('/admin/approve', { userId }),
  reject: (userId: string, remarks: string) => api.post('/admin/reject', { userId, remarks }),
  requestChanges: (userId: string, remarks: string) => api.post('/admin/request-changes', { userId, remarks }),
  allBookings: () => api.get('/bookings/admin/all'),
};

export const documentApi = {
  approve: (docId: string) => api.post('/documents/approve', { docId }),
  reject: (docId: string, remarks: string) => api.post('/documents/reject', { docId, remarks }),
};

export default api;