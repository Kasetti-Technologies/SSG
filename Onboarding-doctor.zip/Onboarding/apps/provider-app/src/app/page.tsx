'use client';
import { useEffect, useState } from 'react';
import { authApi, profileApi, documentApi, userApi, bookingApi } from '../lib/api';

type Step = 'auth' | 'profile' | 'documents' | 'status';
type Tab = 'status' | 'availability' | 'bookings';

const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

export default function ProviderApp() {
  const [isLogin, setIsLogin] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [step, setStep] = useState<Step>('auth');
  const [tab, setTab] = useState<Tab>('status');
  const [user, setUser] = useState<any>(null);
  const [msg, setMsg] = useState('');
  const [error, setError] = useState('');
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '', role: 'DOCTOR', phone: '' });
  const [profileForm, setProfileForm] = useState({ specialization: '', experience: '', consultation_fee: '', languages: '', location: '', bio: '' });
  const [docType, setDocType] = useState('MEDICAL_DEGREE');
  const [docFile, setDocFile] = useState<File | null>(null);
  const [docs, setDocs] = useState<any[]>([]);
  const [statusData, setStatusData] = useState<any>(null);
  const [bookings, setBookings] = useState<any[]>([]);
  const [availability, setAvailability] = useState<any[]>([]);
  const [newSlot, setNewSlot] = useState({ day_of_week: 1, start_time: '09:00', end_time: '17:00', slot_duration: 30 });

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (t) { setToken(t); initUser(); }
  }, []);

  const initUser = async () => {
    try {
      const r = await userApi.status();
      setUser(r.data.data);
      const s = r.data.data.status;
      if (s === 'REGISTERED') setStep('profile');
      else if (s === 'PROFILE_COMPLETED') setStep('documents');
      else { setStep('status'); setStatusData(r.data.data); fetchDocs(); }
    } catch { setStep('profile'); }
  };

  const fetchDocs = async () => {
    try { const r = await documentApi.list(); setDocs(r.data.data); } catch {}
  };

  const fetchBookings = async () => {
    try { const r = await bookingApi.getProviderBookings(); setBookings(r.data.data); } catch {}
  };

  const fetchAvailability = async (userId: string) => {
    try { const r = await bookingApi.getAvailability(userId); setAvailability(r.data.data); } catch {}
  };

  useEffect(() => {
    if (user?.status === 'ACTIVE') {
      fetchBookings();
      fetchAvailability(user.id);
    }
  }, [user]);

  const handleAuth = async () => {
    setError('');
    try {
      if (isLogin) {
        const r = await authApi.login(authForm.email, authForm.password);
        const { token: t, user: u } = r.data.data;
        if (u.role === 'USER' || u.role === 'ADMIN') { setError('Please use the correct portal'); return; }
        localStorage.setItem('token', t);
        setToken(t); setUser(u);
        if (u.status === 'REGISTERED') setStep('profile');
        else if (u.status === 'PROFILE_COMPLETED') setStep('documents');
        else { setStep('status'); setStatusData(u); fetchDocs(); }
      } else {
        const r = await authApi.register(authForm);
        const { token: t, user: u } = r.data.data;
        localStorage.setItem('token', t);
        setToken(t); setUser(u);
        setStep('profile');
      }
    } catch (e: any) { setError(e.response?.data?.message || 'Error occurred'); }
  };

  const handleProfile = async () => {
    setError('');
    try {
      const data = { ...profileForm, experience: parseInt(profileForm.experience), consultation_fee: parseFloat(profileForm.consultation_fee), languages: profileForm.languages.split(',').map((l: string) => l.trim()) };
      await profileApi.update(data);
      setMsg('Profile saved!');
      setStep('documents');
    } catch (e: any) { setError(e.response?.data?.message || 'Error'); }
  };

  const handleDocUpload = async () => {
    if (!docFile) { setError('Please select a file'); return; }
    setError('');
    const fd = new FormData();
    fd.append('file', docFile);
    fd.append('type', docType);
    try {
      await documentApi.upload(fd);
      setMsg(`${docType.replace(/_/g,' ')} uploaded!`);
      setDocFile(null);
      fetchDocs();
    } catch (e: any) { setError(e.response?.data?.message || 'Upload failed'); }
  };

  const handleAddSlot = async () => {
    try {
      const updated = [...availability.map(a => ({ day_of_week: a.day_of_week, start_time: a.start_time.slice(0,5), end_time: a.end_time.slice(0,5), slot_duration: a.slot_duration })), newSlot];
      const r = await bookingApi.setAvailability(updated);
      setAvailability(r.data.data);
      setMsg('Availability saved!');
    } catch (e: any) { setError(e.response?.data?.message || 'Error'); }
  };

  const handleRemoveSlot = async (index: number) => {
    const updated = availability.filter((_, i) => i !== index).map(a => ({ day_of_week: a.day_of_week, start_time: a.start_time.slice(0,5), end_time: a.end_time.slice(0,5), slot_duration: a.slot_duration }));
    const r = await bookingApi.setAvailability(updated);
    setAvailability(r.data.data);
    setMsg('Slot removed!');
  };

  const handleBookingAction = async (bookingId: string, status: string, reason?: string) => {
    try {
      await bookingApi.updateStatus(bookingId, status, reason);
      setMsg(`Booking ${status.toLowerCase()}!`);
      fetchBookings();
    } catch (e: any) { setError(e.response?.data?.message || 'Error'); }
  };

  const logout = () => { localStorage.removeItem('token'); setToken(null); setStep('auth'); setUser(null); };

  const statusColor: Record<string, string> = { ACTIVE: '#38a169', REJECTED: '#e53e3e', NEEDS_UPDATE: '#d69e2e', UNDER_REVIEW: '#3182ce', DOCUMENT_SUBMITTED: '#805ad5', PROFILE_COMPLETED: '#718096', REGISTERED: '#718096' };
  const bookingStatusColor: Record<string, string> = { CONFIRMED: '#38a169', CANCELLED: '#e53e3e', COMPLETED: '#3182ce', PAYMENT_PENDING: '#d69e2e', PENDING: '#718096' };

  if (step === 'auth') return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', background: '#ebf8ff' }}>
      <div className="card" style={{ width: 420 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 6 }}>🩺 Provider Portal</h1>
        <p style={{ color: '#718096', marginBottom: 20, fontSize: 14 }}>For Doctors & Nurses</p>
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          <button style={{ flex: 1, padding: '8px', border: 'none', borderRadius: 6, background: isLogin ? '#3182ce' : '#e2e8f0', color: isLogin ? 'white' : '#4a5568', cursor: 'pointer', fontWeight: 500 }} onClick={() => setIsLogin(true)}>Login</button>
          <button style={{ flex: 1, padding: '8px', border: 'none', borderRadius: 6, background: !isLogin ? '#3182ce' : '#e2e8f0', color: !isLogin ? 'white' : '#4a5568', cursor: 'pointer', fontWeight: 500 }} onClick={() => setIsLogin(false)}>Register</button>
        </div>
        {error && <div style={{ background: '#fff5f5', color: '#c53030', padding: 10, borderRadius: 6, marginBottom: 12, fontSize: 13 }}>{error}</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {!isLogin && <input placeholder="Full Name" value={authForm.name} onChange={e => setAuthForm({ ...authForm, name: e.target.value })} />}
          <input placeholder="Email" type="email" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} />
          <input placeholder="Password" type="password" value={authForm.password} onChange={e => setAuthForm({ ...authForm, password: e.target.value })} />
          {!isLogin && <>
            <select value={authForm.role} onChange={e => setAuthForm({ ...authForm, role: e.target.value })}>
              <option value="DOCTOR">Doctor</option>
              <option value="NURSE">Nurse</option>
            </select>
            <input placeholder="Phone (optional)" value={authForm.phone} onChange={e => setAuthForm({ ...authForm, phone: e.target.value })} />
          </>}
          <button className="btn btn-primary" onClick={handleAuth} style={{ padding: 10 }}>{isLogin ? 'Sign In' : 'Create Account'}</button>
        </div>
      </div>
    </div>
  );

  // Active provider - show full dashboard
  if (step === 'status' && statusData?.status === 'ACTIVE') return (
    <div style={{ minHeight: '100vh', background: '#f7fafc' }}>
      {/* Header */}
      <div style={{ background: '#1a365d', color: 'white', padding: '16px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700 }}>🩺 {user?.name}</div>
          <div style={{ fontSize: 12, color: '#90cdf4' }}>{user?.role} · ACTIVE</div>
        </div>
        <button onClick={logout} style={{ background: 'transparent', color: '#fc8181', border: '1px solid #fc8181', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontSize: 13 }}>Logout</button>
      </div>

      {/* Tabs */}
      <div style={{ background: 'white', borderBottom: '1px solid #e2e8f0', padding: '0 32px', display: 'flex', gap: 0 }}>
        {([['status','📋 My Status'], ['availability','📅 Availability'], ['bookings','🗓 Bookings']] as [Tab, string][]).map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: '14px 20px', border: 'none', background: 'transparent', cursor: 'pointer', fontWeight: tab === t ? 700 : 400, color: tab === t ? '#3182ce' : '#718096', borderBottom: tab === t ? '2px solid #3182ce' : '2px solid transparent', fontSize: 14 }}>{label}</button>
        ))}
      </div>

      <div style={{ maxWidth: 800, margin: '0 auto', padding: 32 }}>
        {msg && <div style={{ background: '#f0fff4', color: '#276749', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 14 }}>{msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button></div>}
        {error && <div style={{ background: '#fff5f5', color: '#c53030', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 14 }}>{error} <button onClick={() => setError('')} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button></div>}

        {/* STATUS TAB */}
        {tab === 'status' && (
          <div>
            <div className="card" style={{ textAlign: 'center', padding: 32, marginBottom: 16 }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>✅</div>
              <div style={{ fontSize: 20, fontWeight: 700 }}>Your profile is LIVE</div>
              <div style={{ color: '#718096', marginTop: 8 }}>Patients can find and book you</div>
            </div>
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: 12 }}>📄 Documents</h3>
              {docs.map((d: any) => (
                <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #e2e8f0', fontSize: 13 }}>
                  <span>{d.type.replace(/_/g,' ')} — {d.file_name}</span>
                  <span style={{ background: d.status === 'APPROVED' ? '#f0fff4' : '#fffbeb', color: d.status === 'APPROVED' ? '#276749' : '#744210', padding: '2px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600 }}>{d.status}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AVAILABILITY TAB */}
        {tab === 'availability' && (
          <div>
            <div className="card" style={{ marginBottom: 16 }}>
              <h3 style={{ fontWeight: 700, marginBottom: 16 }}>➕ Add Availability Slot</h3>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 10, marginBottom: 12 }}>
                <div>
                  <label style={{ fontSize: 12, color: '#718096', display: 'block', marginBottom: 4 }}>Day</label>
                  <select value={newSlot.day_of_week} onChange={e => setNewSlot({ ...newSlot, day_of_week: parseInt(e.target.value) })}>
                    {DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 12, color: '#718096', display: 'block', marginBottom: 4 }}>Start Time</label>
                  <input type="time" value={newSlot.start_time} onChange={e => setNewSlot({ ...newSlot, start_time: e.target.value })} />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: '#718096', display: 'block', marginBottom: 4 }}>End Time</label>
                  <input type="time" value={newSlot.end_time} onChange={e => setNewSlot({ ...newSlot, end_time: e.target.value })} />
                </div>
                <div>
                  <label style={{ fontSize: 12, color: '#718096', display: 'block', marginBottom: 4 }}>Slot (mins)</label>
                  <select value={newSlot.slot_duration} onChange={e => setNewSlot({ ...newSlot, slot_duration: parseInt(e.target.value) })}>
                    {[15,20,30,45,60].map(d => <option key={d} value={d}>{d} min</option>)}
                  </select>
                </div>
              </div>
              <button className="btn btn-primary" onClick={handleAddSlot}>Add Slot</button>
            </div>
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: 12 }}>📅 Current Availability</h3>
              {availability.length === 0 ? (
                <p style={{ color: '#718096', fontSize: 14 }}>No availability set yet. Add slots above.</p>
              ) : (
                availability.map((a: any, i: number) => (
                  <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #e2e8f0' }}>
                    <div style={{ fontSize: 14 }}>
                      <strong>{DAYS[a.day_of_week]}</strong>
                      <span style={{ color: '#718096', marginLeft: 12 }}>{a.start_time.slice(0,5)} – {a.end_time.slice(0,5)}</span>
                      <span style={{ color: '#3182ce', marginLeft: 12, fontSize: 12 }}>{a.slot_duration} min slots</span>
                    </div>
                    <button onClick={() => handleRemoveSlot(i)} style={{ background: '#fff5f5', color: '#e53e3e', border: '1px solid #feb2b2', borderRadius: 6, padding: '4px 12px', cursor: 'pointer', fontSize: 12 }}>Remove</button>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* BOOKINGS TAB */}
        {tab === 'bookings' && (
          <div>
            <h3 style={{ fontWeight: 700, marginBottom: 16 }}>🗓 Your Bookings ({bookings.length})</h3>
            {bookings.length === 0 ? (
              <div className="card" style={{ textAlign: 'center', color: '#718096', padding: 40 }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>📭</div>
                No bookings yet. Set your availability to start receiving bookings!
              </div>
            ) : (
              bookings.map((b: any) => (
                <div key={b.id} className="card" style={{ marginBottom: 12, borderLeft: `4px solid ${bookingStatusColor[b.status] || '#718096'}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700 }}>{b.patient_name}</div>
                      <div style={{ fontSize: 13, color: '#718096' }}>{b.patient_email} {b.patient_phone ? `· ${b.patient_phone}` : ''}</div>
                    </div>
                    <span style={{ background: bookingStatusColor[b.status], color: 'white', padding: '3px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600 }}>{b.status}</span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, fontSize: 13, marginBottom: 10 }}>
                    <div>📅 {new Date(b.booking_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
                    <div>🕐 {b.booking_time.slice(0,5)}</div>
                    <div>{b.type === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}</div>
                    <div>💰 ₹{b.amount}</div>
                    <div>💳 {b.payment_status}</div>
                    {b.notes && <div>📝 {b.notes}</div>}
                  </div>
                  {b.status === 'CONFIRMED' && (
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-primary" style={{ fontSize: 12 }} onClick={() => handleBookingAction(b.id, 'COMPLETED')}>✓ Mark Complete</button>
                      <button className="btn btn-danger" style={{ fontSize: 12 }} onClick={() => handleBookingAction(b.id, 'CANCELLED', 'Cancelled by provider')}>✕ Cancel</button>
                    </div>
                  )}
                  {b.status === 'PENDING' && (
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-success" style={{ fontSize: 12 }} onClick={() => handleBookingAction(b.id, 'CONFIRMED')}>✓ Confirm</button>
                      <button className="btn btn-danger" style={{ fontSize: 12 }} onClick={() => handleBookingAction(b.id, 'CANCELLED', 'Cancelled by provider')}>✕ Cancel</button>
                    </div>
                  )}
                  {b.cancel_reason && <div style={{ fontSize: 12, color: '#e53e3e', marginTop: 8 }}>Reason: {b.cancel_reason}</div>}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );

  // Onboarding flow (non-active providers)
  return (
    <div style={{ maxWidth: 700, margin: '0 auto', padding: 32 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div><h1 style={{ fontSize: 22, fontWeight: 700 }}>🩺 Provider Portal</h1><p style={{ color: '#718096', fontSize: 13 }}>Welcome, {user?.name} ({user?.role})</p></div>
        <button className="btn" style={{ background: '#e2e8f0', fontSize: 13 }} onClick={logout}>Logout</button>
      </div>
      <div style={{ display: 'flex', marginBottom: 28 }}>
        {(['profile','documents','status'] as Step[]).map((s, i) => (
          <div key={s} style={{ flex: 1, textAlign: 'center' }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: step === s ? '#3182ce' : (i < ['profile','documents','status'].indexOf(step) ? '#38a169' : '#e2e8f0'), color: (step === s || i < ['profile','documents','status'].indexOf(step)) ? 'white' : '#718096', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto', fontSize: 12, fontWeight: 700 }}>{i + 1}</div>
            <div style={{ fontSize: 11, color: '#718096', marginTop: 4 }}>{s === 'profile' ? 'Profile' : s === 'documents' ? 'Documents' : 'Status'}</div>
          </div>
        ))}
      </div>
      {msg && <div style={{ background: '#f0fff4', color: '#276749', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 14 }}>{msg}</div>}
      {error && <div style={{ background: '#fff5f5', color: '#c53030', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 14 }}>{error}</div>}
      {step === 'profile' && (
        <div className="card">
          <h2 style={{ fontWeight: 700, marginBottom: 16 }}>Complete Your Profile</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Specialization / Skills</label><input placeholder="e.g. Cardiologist" value={profileForm.specialization} onChange={e => setProfileForm({ ...profileForm, specialization: e.target.value })} /></div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Experience (years)</label><input type="number" value={profileForm.experience} onChange={e => setProfileForm({ ...profileForm, experience: e.target.value })} /></div>
              <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Consultation Fee (₹)</label><input type="number" value={profileForm.consultation_fee} onChange={e => setProfileForm({ ...profileForm, consultation_fee: e.target.value })} /></div>
            </div>
            <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Languages</label><input placeholder="e.g. English, Hindi" value={profileForm.languages} onChange={e => setProfileForm({ ...profileForm, languages: e.target.value })} /></div>
            <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Location</label><input placeholder="City, State" value={profileForm.location} onChange={e => setProfileForm({ ...profileForm, location: e.target.value })} /></div>
            <div><label style={{ display: 'block', marginBottom: 4, fontSize: 13, fontWeight: 500 }}>Bio</label><textarea rows={3} placeholder="Brief about yourself..." value={profileForm.bio} onChange={e => setProfileForm({ ...profileForm, bio: e.target.value })} /></div>
            <button className="btn btn-primary" onClick={handleProfile} style={{ padding: 10 }}>Save & Continue →</button>
          </div>
        </div>
      )}
      {step === 'documents' && (
        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            <h2 style={{ fontWeight: 700, marginBottom: 16 }}>Upload Documents</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <select value={docType} onChange={e => setDocType(e.target.value)}>
                {user?.role === 'DOCTOR' ? ['MEDICAL_DEGREE','LICENSE','ID_PROOF','PROFILE_PHOTO'].map(t => <option key={t} value={t}>{t.replace(/_/g,' ')}</option>) : ['NURSING_CERTIFICATE','ID_PROOF','PROFILE_PHOTO','EXPERIENCE_PROOF'].map(t => <option key={t} value={t}>{t.replace(/_/g,' ')}</option>)}
              </select>
              <input type="file" onChange={e => setDocFile(e.target.files?.[0] || null)} style={{ border: 'none', padding: 0 }} />
              <button className="btn btn-primary" onClick={handleDocUpload}>Upload Document</button>
            </div>
          </div>
          {docs.length > 0 && (
            <div className="card">
              <h3 style={{ fontWeight: 600, marginBottom: 12 }}>Uploaded Documents</h3>
              {docs.map((d: any) => (
                <div key={d.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #e2e8f0', fontSize: 13 }}>
                  <span>{d.type.replace(/_/g,' ')} — {d.file_name}</span>
                  <span style={{ background: '#fffbeb', color: '#744210', padding: '2px 10px', borderRadius: 20, fontSize: 11 }}>{d.status}</span>
                </div>
              ))}
              <button className="btn btn-primary" onClick={() => { setStep('status'); setStatusData(user); fetchDocs(); }} style={{ marginTop: 16, width: '100%' }}>Submit for Review →</button>
            </div>
          )}
        </div>
      )}
      {step === 'status' && statusData?.status !== 'ACTIVE' && (
        <div className="card" style={{ textAlign: 'center', padding: 32 }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>{statusData?.status === 'REJECTED' ? '❌' : statusData?.status === 'NEEDS_UPDATE' ? '⚠️' : '⏳'}</div>
          <div style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>Application Status</div>
          <div style={{ display: 'inline-block', padding: '6px 20px', borderRadius: 20, background: statusColor[statusData?.status] || '#718096', color: 'white', fontWeight: 600 }}>{statusData?.status?.replace(/_/g,' ')}</div>
          {statusData?.remarks && <div style={{ background: '#fffbeb', border: '1px solid #f6e05e', borderRadius: 8, padding: 12, fontSize: 14, color: '#744210', marginTop: 16 }}><strong>Admin Remarks:</strong> {statusData.remarks}</div>}
          {statusData?.status === 'NEEDS_UPDATE' && <button className="btn btn-primary" onClick={() => setStep('profile')} style={{ marginTop: 16 }}>Update Profile</button>}
        </div>
      )}
    </div>
  );
}
