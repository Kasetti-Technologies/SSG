import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
const api = axios.create({ baseURL: API_URL });

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authApi = {
  register: (data: any) => api.post('/auth/register', data),
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
};

export const profileApi = {
  getMe: () => api.get('/profile/me'),
  update: (data: any) => api.put('/profile/update', data),
};

export const documentApi = {
  upload: (formData: FormData) => api.post('/documents/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  list: () => api.get('/documents/my'),
};

export const userApi = {
  status: () => api.get('/users/status'),
};

export const bookingApi = {
  setAvailability: (slots: any[]) => api.post('/bookings/availability', { slots }),
  getAvailability: (providerId: string) => api.get(`/bookings/availability/${providerId}`),
  getProviderBookings: () => api.get('/bookings/provider'),
  updateStatus: (bookingId: string, status: string, reason?: string) =>
    api.post('/bookings/status', { bookingId, status, reason }),
};

export default api;
