import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "HealthCare - Find Doctors & Nurses", description: "Book consultations with verified healthcare providers" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
