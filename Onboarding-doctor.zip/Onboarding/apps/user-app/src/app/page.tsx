'use client';
import { useEffect, useState } from 'react';
import { authApi, providerApi, bookingApi } from '../lib/api';

type View = 'browse' | 'book' | 'payment' | 'mybookings';

export default function UserApp() {
  const [token, setToken] = useState<string | null>(null);
  const [isLogin, setIsLogin] = useState(true);
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [providers, setProviders] = useState<any[]>([]);
  const [roleFilter, setRoleFilter] = useState('');
  const [search, setSearch] = useState('');
  const [view, setView] = useState<View>('browse');
  const [selectedProvider, setSelectedProvider] = useState<any>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [bookingType, setBookingType] = useState('ONLINE');
  const [bookingNotes, setBookingNotes] = useState('');
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [currentBooking, setCurrentBooking] = useState<any>(null);
  const [myBookings, setMyBookings] = useState<any[]>([]);
  const [msg, setMsg] = useState('');
  const [paymentLoading, setPaymentLoading] = useState(false);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (t) { setToken(t); fetchProviders(); }
  }, []);

  const fetchProviders = async (role = '') => {
    try { const r = await providerApi.list(role); setProviders(r.data.data); } catch {}
  };

  const fetchMyBookings = async () => {
    try { const r = await bookingApi.myBookings(); setMyBookings(r.data.data); } catch {}
  };

  const handleAuth = async () => {
    setError('');
    try {
      if (isLogin) {
        const r = await authApi.login(authForm.email, authForm.password);
        const { token: t } = r.data.data;
        localStorage.setItem('token', t);
        setToken(t);
        fetchProviders();
      } else {
        const r = await authApi.register(authForm);
        const { token: t } = r.data.data;
        localStorage.setItem('token', t);
        setToken(t);
        fetchProviders();
      }
    } catch (e: any) { setError(e.response?.data?.message || 'Error'); }
  };

  const handleDateChange = async (date: string) => {
    setBookingDate(date);
    setBookingTime('');
    if (!date || !selectedProvider) return;
    setSlotsLoading(true);
    try {
      const r = await bookingApi.getSlots(selectedProvider.id, date);
      setAvailableSlots(r.data.data);
    } catch { setAvailableSlots([]); }
    finally { setSlotsLoading(false); }
  };

  const handleBookNow = async () => {
    if (!bookingDate || !bookingTime) { setError('Please select date and time'); return; }
    setError('');
    try {
      const r = await bookingApi.createBooking({
        providerId: selectedProvider.id,
        date: bookingDate,
        time: bookingTime,
        type: bookingType,
        notes: bookingNotes
      });
      setCurrentBooking(r.data.data);
      setView('payment');
    } catch (e: any) { setError(e.response?.data?.message || 'Booking failed'); }
  };

  const handlePayment = async () => {
    setPaymentLoading(true);
    try {
      await new Promise(r => setTimeout(r, 2000)); // Simulate payment processing
      await bookingApi.confirmPayment(currentBooking.booking.id);
      setMsg('🎉 Booking confirmed! Payment successful.');
      setView('mybookings');
      fetchMyBookings();
    } catch (e: any) { setError(e.response?.data?.message || 'Payment failed'); }
    finally { setPaymentLoading(false); }
  };

  const handleCancel = async (bookingId: string) => {
    try {
      await bookingApi.cancelBooking(bookingId, 'Cancelled by patient');
      setMsg('Booking cancelled.');
      fetchMyBookings();
    } catch (e: any) { setError(e.response?.data?.message || 'Error'); }
  };

  const logout = () => { localStorage.removeItem('token'); setToken(null); setProviders([]); };

  const filtered = providers.filter(p =>
    search === '' ||
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    (p.specialization || '').toLowerCase().includes(search.toLowerCase()) ||
    (p.location || '').toLowerCase().includes(search.toLowerCase())
  );

  const bookingStatusColor: Record<string, string> = {
    CONFIRMED: '#38a169', CANCELLED: '#e53e3e', COMPLETED: '#3182ce',
    PAYMENT_PENDING: '#d69e2e', PENDING: '#718096'
  };

  const today = new Date().toISOString().split('T')[0];

  if (!token) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' }}>
      <div className="card" style={{ width: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>🏥</div>
          <h1 style={{ fontSize: 22, fontWeight: 700 }}>HealthCare</h1>
          <p style={{ color: '#718096', fontSize: 13 }}>Find & book verified doctors and nurses</p>
        </div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
          <button onClick={() => setIsLogin(true)} style={{ flex: 1, padding: '8px', border: 'none', borderRadius: 6, background: isLogin ? '#667eea' : '#e2e8f0', color: isLogin ? 'white' : '#4a5568', cursor: 'pointer', fontWeight: 500 }}>Login</button>
          <button onClick={() => setIsLogin(false)} style={{ flex: 1, padding: '8px', border: 'none', borderRadius: 6, background: !isLogin ? '#667eea' : '#e2e8f0', color: !isLogin ? 'white' : '#4a5568', cursor: 'pointer', fontWeight: 500 }}>Sign Up</button>
        </div>
        {error && <div style={{ background: '#fff5f5', color: '#c53030', padding: 10, borderRadius: 6, marginBottom: 12, fontSize: 13 }}>{error}</div>}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {!isLogin && <input placeholder="Full Name" value={authForm.name} onChange={e => setAuthForm({ ...authForm, name: e.target.value })} />}
          <input placeholder="Email" type="email" value={authForm.email} onChange={e => setAuthForm({ ...authForm, email: e.target.value })} />
          <input placeholder="Password" type="password" value={authForm.password} onChange={e => setAuthForm({ ...authForm, password: e.target.value })} />
          <button onClick={handleAuth} style={{ background: '#667eea', color: 'white', border: 'none', borderRadius: 6, padding: '10px', cursor: 'pointer', fontWeight: 600 }}>{isLogin ? 'Sign In' : 'Create Account'}</button>
        </div>
      </div>
    </div>
  );

  return (
    <div style={{ minHeight: '100vh', background: '#f7fafc' }}>
      {/* Header */}
      <div style={{ background: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', padding: '0 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: 20, fontWeight: 700, padding: '16px 0' }}>🏥 HealthCare</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => { setView('browse'); }} style={{ background: view === 'browse' ? '#ebf8ff' : 'transparent', color: view === 'browse' ? '#2b6cb0' : '#718096', border: 'none', borderRadius: 6, padding: '8px 16px', cursor: 'pointer', fontWeight: 500, fontSize: 14 }}>🔍 Browse</button>
          <button onClick={() => { setView('mybookings'); fetchMyBookings(); }} style={{ background: view === 'mybookings' ? '#ebf8ff' : 'transparent', color: view === 'mybookings' ? '#2b6cb0' : '#718096', border: 'none', borderRadius: 6, padding: '8px 16px', cursor: 'pointer', fontWeight: 500, fontSize: 14 }}>🗓 My Bookings</button>
          <button onClick={logout} style={{ background: '#e2e8f0', border: 'none', borderRadius: 6, padding: '8px 16px', cursor: 'pointer', fontSize: 13 }}>Logout</button>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: '0 auto', padding: '32px 16px' }}>
        {msg && <div style={{ background: '#f0fff4', color: '#276749', padding: 12, borderRadius: 8, marginBottom: 16 }}>{msg} <button onClick={() => setMsg('')} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button></div>}
        {error && <div style={{ background: '#fff5f5', color: '#c53030', padding: 12, borderRadius: 8, marginBottom: 16 }}>{error} <button onClick={() => setError('')} style={{ float: 'right', background: 'none', border: 'none', cursor: 'pointer' }}>✕</button></div>}

        {/* BROWSE VIEW */}
        {view === 'browse' && (
          <>
            <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 8 }}>Find Healthcare Providers</h2>
            <p style={{ color: '#718096', marginBottom: 20 }}>Book verified doctors and nurses for online or in-person consultations</p>
            <div style={{ display: 'flex', gap: 12, marginBottom: 24 }}>
              <input placeholder="Search by name, specialization, location..." value={search} onChange={e => setSearch(e.target.value)} style={{ flex: 1 }} />
              <select value={roleFilter} onChange={e => { setRoleFilter(e.target.value); fetchProviders(e.target.value); }} style={{ width: 150 }}>
                <option value="">All Providers</option>
                <option value="DOCTOR">Doctors</option>
                <option value="NURSE">Nurses</option>
              </select>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
              {filtered.map(p => (
                <div
  key={p.id}
  className="card"
  onMouseEnter={e => (e.currentTarget.style.transform = 'translateY(-2px)')}
  onMouseLeave={e => (e.currentTarget.style.transform = 'none')}
  style={{
    border: '1px solid #e2e8f0',
    cursor: 'pointer',
    transition: 'transform 0.2s',
    background: 'white',
    borderRadius: 10,
    padding: 20
  }}
>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
                    <div style={{ width: 48, height: 48, borderRadius: '50%', background: p.role === 'DOCTOR' ? '#bee3f8' : '#c6f6d5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>{p.role === 'DOCTOR' ? '👨‍⚕️' : '👩‍⚕️'}</div>
                    <span style={{ background: p.role === 'DOCTOR' ? '#ebf8ff' : '#f0fff4', color: p.role === 'DOCTOR' ? '#2b6cb0' : '#276749', fontSize: 11, padding: '3px 10px', borderRadius: 20, fontWeight: 600 }}>{p.role}</span>
                  </div>
                  <h3 style={{ fontWeight: 700, marginBottom: 4 }}>{p.name}</h3>
                  <p style={{ color: '#3182ce', fontSize: 13, marginBottom: 10 }}>{p.specialization || p.skills?.join(', ') || 'General'}</p>
                  <div style={{ fontSize: 12, color: '#718096', display: 'flex', flexDirection: 'column', gap: 3, marginBottom: 14 }}>
                    {p.experience && <span>📅 {p.experience} yrs exp</span>}
                    {p.location && <span>📍 {p.location}</span>}
                    {p.consultation_fee && <span>💰 ₹{p.consultation_fee}</span>}
                  </div>
                  <button onClick={() => { setSelectedProvider(p); setBookingDate(''); setBookingTime(''); setAvailableSlots([]); setView('book'); }}
                    style={{ width: '100%', background: '#667eea', color: 'white', border: 'none', borderRadius: 6, padding: '8px', cursor: 'pointer', fontWeight: 600, fontSize: 13 }}>
                    📅 Book Appointment
                  </button>
                </div>
              ))}
              {filtered.length === 0 && (
                <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 60, color: '#718096' }}>
                  <div style={{ fontSize: 40, marginBottom: 12 }}>🔍</div>
                  No providers found.
                </div>
              )}
            </div>
          </>
        )}

        {/* BOOKING VIEW */}
        {view === 'book' && selectedProvider && (
          <div style={{ maxWidth: 560, margin: '0 auto' }}>
            <button onClick={() => setView('browse')} style={{ background: '#e2e8f0', border: 'none', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontSize: 13, marginBottom: 20 }}>← Back</button>
            <div className="card" style={{ marginBottom: 16 }}>
              <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 16 }}>
                <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#bee3f8', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26 }}>{selectedProvider.role === 'DOCTOR' ? '👨‍⚕️' : '👩‍⚕️'}</div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 18 }}>{selectedProvider.name}</div>
                  <div style={{ color: '#3182ce', fontSize: 14 }}>{selectedProvider.specialization}</div>
                  <div style={{ color: '#718096', fontSize: 13 }}>💰 ₹{selectedProvider.consultation_fee} per session</div>
                </div>
              </div>
            </div>
            <div className="card">
              <h3 style={{ fontWeight: 700, marginBottom: 16 }}>Book Appointment</h3>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Consultation Type</label>
                  <div style={{ display: 'flex', gap: 10 }}>
                    {['ONLINE', 'IN_PERSON'].map(t => (
                      <button key={t} onClick={() => setBookingType(t)} style={{ flex: 1, padding: '10px', border: `2px solid ${bookingType === t ? '#667eea' : '#e2e8f0'}`, borderRadius: 8, background: bookingType === t ? '#ebf4ff' : 'white', color: bookingType === t ? '#3153b4' : '#4a5568', cursor: 'pointer', fontWeight: bookingType === t ? 600 : 400, fontSize: 13 }}>
                        {t === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Select Date</label>
                  <input type="date" min={today} value={bookingDate} onChange={e => handleDateChange(e.target.value)} />
                </div>
                {bookingDate && (
                  <div>
                    <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Select Time Slot</label>
                    {slotsLoading ? (
                      <div style={{ color: '#718096', fontSize: 13 }}>Loading slots...</div>
                    ) : availableSlots.length === 0 ? (
                      <div style={{ background: '#fff5f5', color: '#c53030', padding: 10, borderRadius: 6, fontSize: 13 }}>No slots available on this date. Please try another date.</div>
                    ) : (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                        {availableSlots.map(slot => (
                          <button key={slot} onClick={() => setBookingTime(slot)} style={{ padding: '8px 16px', border: `2px solid ${bookingTime === slot ? '#667eea' : '#e2e8f0'}`, borderRadius: 6, background: bookingTime === slot ? '#ebf4ff' : 'white', color: bookingTime === slot ? '#3153b4' : '#4a5568', cursor: 'pointer', fontSize: 13, fontWeight: bookingTime === slot ? 600 : 400 }}>
                            {slot}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
                <div>
                  <label style={{ display: 'block', fontSize: 13, fontWeight: 500, marginBottom: 6 }}>Notes (optional)</label>
                  <textarea rows={2} placeholder="Describe your symptoms or reason for visit..." value={bookingNotes} onChange={e => setBookingNotes(e.target.value)} />
                </div>
                <button onClick={handleBookNow} disabled={!bookingDate || !bookingTime}
                  style={{ background: bookingDate && bookingTime ? '#667eea' : '#cbd5e0', color: 'white', border: 'none', borderRadius: 8, padding: '12px', cursor: bookingDate && bookingTime ? 'pointer' : 'not-allowed', fontWeight: 600, fontSize: 15 }}>
                  Proceed to Payment →
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PAYMENT VIEW */}
        {view === 'payment' && currentBooking && (
          <div style={{ maxWidth: 480, margin: '0 auto' }}>
            <div className="card">
              <div style={{ textAlign: 'center', marginBottom: 24 }}>
                <div style={{ fontSize: 36, marginBottom: 8 }}>💳</div>
                <h2 style={{ fontWeight: 700 }}>Complete Payment</h2>
                <p style={{ color: '#718096', fontSize: 14 }}>Dummy payment — no real money charged</p>
              </div>
              {/* Order Summary */}
              <div style={{ background: '#f7fafc', borderRadius: 8, padding: 16, marginBottom: 20 }}>
                <div style={{ fontWeight: 600, marginBottom: 10 }}>Order Summary</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 14 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Provider</span><span>{selectedProvider?.name}</span></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Type</span><span>{currentBooking.booking?.type === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}</span></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Date</span><span>{new Date(currentBooking.booking?.booking_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span></div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>Time</span><span>{currentBooking.booking?.booking_time?.slice(0,5)}</span></div>
                  <div style={{ borderTop: '1px solid #e2e8f0', paddingTop: 8, marginTop: 4, display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: 16 }}>
                    <span>Total</span><span style={{ color: '#667eea' }}>₹{currentBooking.amount}</span>
                  </div>
                </div>
              </div>
              {/* Dummy card UI */}
              <div style={{ background: 'linear-gradient(135deg, #667eea, #764ba2)', borderRadius: 12, padding: 20, color: 'white', marginBottom: 20 }}>
                <div style={{ fontSize: 12, opacity: 0.8, marginBottom: 12 }}>DEMO CARD</div>
                <div style={{ fontSize: 18, letterSpacing: 4, marginBottom: 12 }}>4242 4242 4242 4242</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
                  <span>Test User</span><span>12/28</span>
                </div>
              </div>
              <button onClick={handlePayment} disabled={paymentLoading}
                style={{ width: '100%', background: paymentLoading ? '#cbd5e0' : '#38a169', color: 'white', border: 'none', borderRadius: 8, padding: '14px', cursor: paymentLoading ? 'not-allowed' : 'pointer', fontWeight: 700, fontSize: 16 }}>
                {paymentLoading ? '⏳ Processing...' : `Pay ₹${currentBooking.amount}`}
              </button>
              <button onClick={() => setView('book')} style={{ width: '100%', background: 'transparent', border: 'none', color: '#718096', marginTop: 10, cursor: 'pointer', fontSize: 13 }}>← Go Back</button>
            </div>
          </div>
        )}

        {/* MY BOOKINGS VIEW */}
        {view === 'mybookings' && (
          <>
            <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 20 }}>🗓 My Bookings</h2>
            {myBookings.length === 0 ? (
              <div className="card" style={{ textAlign: 'center', padding: 40, color: '#718096' }}>
                <div style={{ fontSize: 40, marginBottom: 12 }}>📭</div>
                <div>No bookings yet.</div>
                <button onClick={() => setView('browse')} style={{ marginTop: 16, background: '#667eea', color: 'white', border: 'none', borderRadius: 6, padding: '8px 20px', cursor: 'pointer', fontWeight: 500 }}>Browse Providers</button>
              </div>
            ) : (
              myBookings.map((b: any) => (
                <div key={b.id} className="card" style={{ marginBottom: 12, borderLeft: `4px solid ${bookingStatusColor[b.status] || '#718096'}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
                    <div>
                      <div style={{ fontWeight: 700 }}>{b.provider_name} <span style={{ color: '#718096', fontSize: 13 }}>({b.provider_role})</span></div>
                      <div style={{ color: '#3182ce', fontSize: 13 }}>{b.specialization}</div>
                    </div>
                    <span style={{ background: bookingStatusColor[b.status], color: 'white', padding: '3px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600 }}>{b.status}</span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, fontSize: 13, color: '#4a5568', marginBottom: 10 }}>
                    <span>📅 {new Date(b.booking_date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    <span>🕐 {b.booking_time.slice(0,5)}</span>
                    <span>{b.type === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}</span>
                    <span>💰 ₹{b.amount}</span>
                    <span>💳 {b.payment_status}</span>
                    {b.payment_id && <span style={{ fontSize: 11, color: '#718096' }}>ID: {b.payment_id}</span>}
                  </div>
                  {b.notes && <div style={{ fontSize: 13, color: '#718096', marginBottom: 8 }}>📝 {b.notes}</div>}
                  {b.cancel_reason && <div style={{ fontSize: 12, color: '#e53e3e', marginBottom: 8 }}>Cancelled: {b.cancel_reason}</div>}
                  {['CONFIRMED', 'PENDING'].includes(b.status) && (
                    <button onClick={() => handleCancel(b.id)} style={{ background: '#fff5f5', color: '#c53030', border: '1px solid #feb2b2', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontSize: 12 }}>Cancel Booking</button>
                  )}
                </div>
              ))
            )}
          </>
        )}
      </div>
    </div>
  );
}
