import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';
const api = axios.create({ baseURL: API_URL });

api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('token');
    if (token) config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authApi = {
  register: (data: any) => api.post('/auth/register', { ...data, role: 'USER' }),
  login: (email: string, password: string) => api.post('/auth/login', { email, password }),
};

export const providerApi = {
  list: (role?: string) => api.get(`/profile/providers${role ? `?role=${role}` : ''}`),
};

export const bookingApi = {
  getSlots: (providerId: string, date: string) =>
    api.get(`/bookings/slots?providerId=${providerId}&date=${date}`),
  createBooking: (data: any) => api.post('/bookings/create', data),
  confirmPayment: (bookingId: string) => api.post('/bookings/pay', { bookingId }),
  myBookings: () => api.get('/bookings/my'),
  cancelBooking: (bookingId: string, reason: string) =>
    api.post('/bookings/cancel', { bookingId, reason }),
};

export default api;
