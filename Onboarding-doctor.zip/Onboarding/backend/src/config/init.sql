-- Healthcare Platform Database Schema

CREATE TYPE user_role AS ENUM ('ADMIN', 'DOCTOR', 'NURSE', 'USER');
CREATE TYPE user_status AS ENUM (
  'REGISTERED',
  'PROFILE_COMPLETED',
  'DOCUMENT_SUBMITTED',
  'UNDER_REVIEW',
  'VERIFIED',
  'REJECTED',
  'NEEDS_UPDATE',
  'ACTIVE'
);
CREATE TYPE doc_type AS ENUM (
  'MEDICAL_DEGREE',
  'LICENSE',
  'ID_PROOF',
  'PROFILE_PHOTO',
  'NURSING_CERTIFICATE',
  'EXPERIENCE_PROOF'
);
CREATE TYPE doc_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED');
CREATE TYPE verification_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'NEEDS_UPDATE');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'USER',
  status user_status NOT NULL DEFAULT 'REGISTERED',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  specialization VARCHAR(255),
  skills TEXT[],
  experience INTEGER,
  consultation_fee DECIMAL(10,2),
  languages TEXT[],
  availability JSONB,
  location VARCHAR(500),
  bio TEXT,
  pricing JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  type doc_type NOT NULL,
  file_url VARCHAR(1000) NOT NULL,
  file_name VARCHAR(500),
  file_size INTEGER,
  status doc_status DEFAULT 'PENDING',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  status verification_status DEFAULT 'PENDING',
  remarks TEXT,
  verified_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert default admin
INSERT INTO users (name, email, password_hash, role, status)
VALUES (
  'Super Admin',
  'admin@healthcare.com',
  '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: "password"
  'ADMIN',
  'ACTIVE'
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);
CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_verifications_user_id ON verifications(user_id);
