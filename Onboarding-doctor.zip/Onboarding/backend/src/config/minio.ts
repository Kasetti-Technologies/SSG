import * as Minio from 'minio';
import dotenv from 'dotenv';

dotenv.config();

export const minioClient = new Minio.Client({
  endPoint: process.env.MINIO_ENDPOINT || 'localhost',
  port: parseInt(process.env.MINIO_PORT || '9000'),
  useSSL: process.env.MINIO_USE_SSL === 'true',
  accessKey: process.env.MINIO_ACCESS_KEY || 'minioadmin',
  secretKey: process.env.MINIO_SECRET_KEY || 'minioadmin123',
});

export const BUCKET_NAME = process.env.MINIO_BUCKET || 'healthcare-docs';

export const initMinio = async () => {
  try {
    // Create bucket if not exists
    const exists = await minioClient.bucketExists(BUCKET_NAME);
    if (!exists) {
      await minioClient.makeBucket(BUCKET_NAME, 'us-east-1');
      console.log(`✅ MinIO bucket '${BUCKET_NAME}' created`);
    } else {
      console.log(`✅ MinIO bucket '${BUCKET_NAME}' exists`);
    }

    // Always set public read policy on every startup
    const policy = JSON.stringify({
      Version: '2012-10-17',
      Statement: [
        {
          Effect: 'Allow',
          Principal: { AWS: ['*'] },
          Action: ['s3:GetObject'],
          Resource: [`arn:aws:s3:::${BUCKET_NAME}/*`],
        },
      ],
    });

    await minioClient.setBucketPolicy(BUCKET_NAME, policy);
    console.log(`✅ MinIO bucket policy set to public read`);

  } catch (err) {
    console.error('❌ MinIO init error:', err);
  }
};

export const getSignedUrl = async (objectName: string): Promise<string> => {
  // Direct public URL — works since bucket is public read
  return `http://localhost:9000/${BUCKET_NAME}/${objectName}`;
};