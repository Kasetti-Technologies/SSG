import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './modules/auth/auth.routes';
import profileRoutes from './modules/profile/profile.routes';
import documentRoutes from './modules/document/document.routes';
import adminRoutes from './modules/admin/admin.routes';
import userRoutes from './modules/user/user.routes';
import bookingRoutes from './modules/booking/booking.routes';
import { errorHandler } from './middleware/error.middleware';
import { initMinio } from './config/minio';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:3001', 'http://localhost:3002'],
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/users', userRoutes);
app.use('/api/bookings', bookingRoutes);

app.use(errorHandler);

app.listen(PORT, async () => {
  console.log(`🚀 Healthcare API running on port ${PORT}`);
  // Initialize MinIO bucket and set public policy on every startup
  await initMinio();
});

export default app;