import { Response } from 'express';
import { AuthRequest } from '../../middleware/auth.middleware';
import { getDashboardStats, getApplications, getApplicationDetail, approveApplication, rejectApplication, requestChanges } from './admin.service';
import { asyncHandler } from '../../middleware/error.middleware';

export const dashboard = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const stats = await getDashboardStats();
  res.json({ success: true, data: stats });
});

export const listApplications = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { status } = req.query;
  const apps = await getApplications(status as string);
  res.json({ success: true, data: apps });
});

export const applicationDetail = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { userId } = req.params;
  const detail = await getApplicationDetail(userId);
  res.json({ success: true, data: detail });
});

export const approve = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ success: false, message: 'userId required' });
  await approveApplication(userId, req.user!.id);
  res.json({ success: true, message: 'Provider approved and activated' });
});

export const reject = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { userId, remarks } = req.body;
  if (!userId || !remarks) return res.status(400).json({ success: false, message: 'userId and remarks required' });
  await rejectApplication(userId, req.user!.id, remarks);
  res.json({ success: true, message: 'Provider rejected' });
});

export const requestUpdate = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { userId, remarks } = req.body;
  if (!userId || !remarks) return res.status(400).json({ success: false, message: 'userId and remarks required' });
  await requestChanges(userId, req.user!.id, remarks);
  res.json({ success: true, message: 'Update requested from provider' });
});
