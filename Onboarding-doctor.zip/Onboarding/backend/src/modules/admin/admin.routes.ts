import { Router } from 'express';
import { dashboard, listApplications, applicationDetail, approve, reject, requestUpdate } from './admin.controller';
import { authenticate, authorize } from '../../middleware/auth.middleware';

const router = Router();

router.use(authenticate, authorize('ADMIN'));

router.get('/dashboard', dashboard);
router.get('/applications', listApplications);
router.get('/applications/:userId', applicationDetail);
router.post('/approve', approve);
router.post('/reject', reject);
router.post('/request-changes', requestUpdate);

export default router;
