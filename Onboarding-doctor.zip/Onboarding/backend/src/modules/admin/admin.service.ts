import { query } from '../../config/database';
import { getUserDocuments } from '../document/document.service';
import {
  sendProviderApprovedEmail,
  sendProviderRejectedEmail,
  sendProviderNeedsUpdateEmail
} from '../email/email.service';

export const getDashboardStats = async () => {
  const stats = await query(`
    SELECT
      COUNT(*) FILTER (WHERE role IN ('DOCTOR','NURSE')) AS total_providers,
      COUNT(*) FILTER (WHERE status = 'DOCUMENT_SUBMITTED' AND role IN ('DOCTOR','NURSE')) AS pending_approvals,
      COUNT(*) FILTER (WHERE status = 'ACTIVE' AND role IN ('DOCTOR','NURSE')) AS active_providers,
      COUNT(*) FILTER (WHERE status = 'REJECTED') AS rejected,
      COUNT(*) FILTER (WHERE role = 'USER') AS total_patients
    FROM users
  `);
  return stats.rows[0];
};

export const getApplications = async (status?: string) => {
  const statusFilter = status ? `AND u.status = $1` : '';
  const params = status ? [status] : [];
  const result = await query(
    `SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at,
            p.specialization, p.skills, p.experience, p.location,
            v.remarks, v.created_at as verified_at
     FROM users u
     LEFT JOIN profiles p ON u.id = p.user_id
     LEFT JOIN verifications v ON u.id = v.user_id
     WHERE u.role IN ('DOCTOR','NURSE')
     ${statusFilter}
     ORDER BY u.created_at DESC`,
    params
  );
  return result.rows;
};

export const getApplicationDetail = async (userId: string) => {
  const [userResult, docs] = await Promise.all([
    query(
      `SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at,
              p.specialization, p.skills, p.experience, p.consultation_fee,
              p.languages, p.availability, p.location, p.bio, p.pricing,
              v.status as verification_status, v.remarks
       FROM users u
       LEFT JOIN profiles p ON u.id = p.user_id
       LEFT JOIN verifications v ON u.id = v.user_id
       WHERE u.id = $1`,
      [userId]
    ),
    getUserDocuments(userId),
  ]);
  if (userResult.rows.length === 0) throw new Error('User not found');
  return { ...userResult.rows[0], documents: docs };
};

export const approveApplication = async (userId: string, adminId: string) => {
  await query(`UPDATE users SET status = 'ACTIVE', updated_at = NOW() WHERE id = $1`, [userId]);
  await query(`DELETE FROM verifications WHERE user_id = $1`, [userId]);
  await query(
    `INSERT INTO verifications (user_id, status, verified_by) VALUES ($1, 'APPROVED', $2)`,
    [userId, adminId]
  );
  // Send email
  const u = await query(`SELECT name, email FROM users WHERE id = $1`, [userId]);
  if (u.rows.length > 0) {
    sendProviderApprovedEmail(u.rows[0].email, u.rows[0].name).catch(() => {});
  }
};

export const rejectApplication = async (userId: string, adminId: string, remarks: string) => {
  await query(`UPDATE users SET status = 'REJECTED', updated_at = NOW() WHERE id = $1`, [userId]);
  await query(`DELETE FROM verifications WHERE user_id = $1`, [userId]);
  await query(
    `INSERT INTO verifications (user_id, status, verified_by, remarks) VALUES ($1, 'REJECTED', $2, $3)`,
    [userId, adminId, remarks]
  );
  // Send email
  const u = await query(`SELECT name, email FROM users WHERE id = $1`, [userId]);
  if (u.rows.length > 0) {
    sendProviderRejectedEmail(u.rows[0].email, u.rows[0].name, remarks).catch(() => {});
  }
};

export const requestChanges = async (userId: string, adminId: string, remarks: string) => {
  await query(`UPDATE users SET status = 'NEEDS_UPDATE', updated_at = NOW() WHERE id = $1`, [userId]);
  await query(`DELETE FROM verifications WHERE user_id = $1`, [userId]);
  await query(
    `INSERT INTO verifications (user_id, status, verified_by, remarks) VALUES ($1, 'NEEDS_UPDATE', $2, $3)`,
    [userId, adminId, remarks]
  );
  // Send email
  const u = await query(`SELECT name, email FROM users WHERE id = $1`, [userId]);
  if (u.rows.length > 0) {
    sendProviderNeedsUpdateEmail(u.rows[0].email, u.rows[0].name, remarks).catch(() => {});
  }
};
