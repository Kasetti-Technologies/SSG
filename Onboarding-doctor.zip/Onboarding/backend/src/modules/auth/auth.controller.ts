import { Request, Response } from 'express';
import { registerUser, loginUser } from './auth.service';
import { asyncHandler } from '../../middleware/error.middleware';

export const register = asyncHandler(async (req: Request, res: Response) => {
  const { name, email, password, role, phone } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ success: false, message: 'name, email, password, role are required' });
  }

  if (!['DOCTOR', 'NURSE', 'USER'].includes(role)) {
    return res.status(400).json({ success: false, message: 'Role must be DOCTOR, NURSE, or USER' });
  }

  const result = await registerUser({ name, email, password, role, phone });
  res.status(201).json({ success: true, message: 'Registration successful', data: result });
});

export const login = asyncHandler(async (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'email and password are required' });
  }

  const result = await loginUser({ email, password });
  res.json({ success: true, message: 'Login successful', data: result });
});
