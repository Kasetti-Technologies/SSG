import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { query } from '../../config/database';
import { sendWelcomeEmail, sendPatientWelcomeEmail } from '../email/email.service';

export interface RegisterDTO {
  name: string;
  email: string;
  password: string;
  role: 'DOCTOR' | 'NURSE' | 'USER';
  phone?: string;
}

export interface LoginDTO {
  email: string;
  password: string;
}

export const registerUser = async (dto: RegisterDTO) => {
  const { name, email, password, role, phone } = dto;

  const existing = await query('SELECT id FROM users WHERE email = $1', [email]);
  if (existing.rows.length > 0) throw new Error('Email already registered');

  const passwordHash = await bcrypt.hash(password, 10);

  const result = await query(
    `INSERT INTO users (name, email, phone, password_hash, role, status)
     VALUES ($1, $2, $3, $4, $5, 'REGISTERED')
     RETURNING id, name, email, role, status, created_at`,
    [name, email, phone, passwordHash, role]
  );

  const user = result.rows[0];
  const token = generateToken(user);

  // Send welcome email
  if (role === 'USER') {
    sendPatientWelcomeEmail(email, name).catch(() => {});
  } else {
    sendWelcomeEmail(email, name, role).catch(() => {});
  }

  return { user, token };
};

export const loginUser = async (dto: LoginDTO) => {
  const { email, password } = dto;

  const result = await query(
    'SELECT id, name, email, password_hash, role, status FROM users WHERE email = $1',
    [email]
  );

  if (result.rows.length === 0) throw new Error('Invalid email or password');

  const user = result.rows[0];
  const isValid = await bcrypt.compare(password, user.password_hash);
  if (!isValid) throw new Error('Invalid email or password');

  const { password_hash, ...userWithoutPassword } = user;
  const token = generateToken(userWithoutPassword);

  return { user: userWithoutPassword, token };
};

const generateToken = (user: { id: string; email: string; role: string; status: string }) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, status: user.status },
    process.env.JWT_SECRET || 'secret',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' } as jwt.SignOptions
  );
};
