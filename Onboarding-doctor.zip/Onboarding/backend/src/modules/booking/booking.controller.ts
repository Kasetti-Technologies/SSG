import { Response } from 'express';
import { AuthRequest } from '../../middleware/auth.middleware';
import { asyncHandler } from '../../middleware/error.middleware';
import {
  setAvailability, getAvailability, getAvailableSlots,
  initiateBooking, confirmPayment,
  getPatientBookings, getProviderBookings,
  updateBookingStatus, cancelBookingByPatient,
  getAdminBookings
} from './booking.service';

export const setProviderAvailability = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { slots } = req.body;
  if (!slots || !Array.isArray(slots)) {
    return res.status(400).json({ success: false, message: 'slots array required' });
  }
  const result = await setAvailability(req.user!.id, slots);
  res.json({ success: true, message: 'Availability updated', data: result });
});

export const getProviderAvailability = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { providerId } = req.params;
  const result = await getAvailability(providerId);
  res.json({ success: true, data: result });
});

export const getSlots = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { providerId, date } = req.query;
  if (!providerId || !date) {
    return res.status(400).json({ success: false, message: 'providerId and date required' });
  }
  const slots = await getAvailableSlots(providerId as string, date as string);
  res.json({ success: true, data: slots });
});

export const createBooking = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { providerId, date, time, type, notes } = req.body;
  if (!providerId || !date || !time || !type) {
    return res.status(400).json({ success: false, message: 'providerId, date, time, type required' });
  }
  const result = await initiateBooking(req.user!.id, providerId, date, time, type, notes);
  res.status(201).json({ success: true, message: 'Booking initiated', data: result });
});

export const payBooking = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { bookingId } = req.body;
  if (!bookingId) return res.status(400).json({ success: false, message: 'bookingId required' });
  const result = await confirmPayment(bookingId, req.user!.id);
  res.json({ success: true, message: 'Payment confirmed! Booking is now confirmed.', data: result });
});

export const myBookings = asyncHandler(async (req: AuthRequest, res: Response) => {
  const bookings = await getPatientBookings(req.user!.id);
  res.json({ success: true, data: bookings });
});

export const providerBookings = asyncHandler(async (req: AuthRequest, res: Response) => {
  const bookings = await getProviderBookings(req.user!.id);
  res.json({ success: true, data: bookings });
});

export const updateStatus = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { bookingId, status, reason } = req.body;
  if (!bookingId || !status) {
    return res.status(400).json({ success: false, message: 'bookingId and status required' });
  }
  const validStatuses = ['CONFIRMED', 'CANCELLED', 'COMPLETED'];
  if (!validStatuses.includes(status)) {
    return res.status(400).json({ success: false, message: 'Invalid status' });
  }
  const result = await updateBookingStatus(bookingId, req.user!.id, status, reason);
  res.json({ success: true, message: `Booking ${status.toLowerCase()}`, data: result });
});

export const cancelBooking = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { bookingId, reason } = req.body;
  if (!bookingId) return res.status(400).json({ success: false, message: 'bookingId required' });
  const result = await cancelBookingByPatient(bookingId, req.user!.id, reason || 'Cancelled by patient');
  res.json({ success: true, message: 'Booking cancelled', data: result });
});

export const adminAllBookings = asyncHandler(async (_req: AuthRequest, res: Response) => {
  const bookings = await getAdminBookings();
  res.json({ success: true, data: bookings });
});
