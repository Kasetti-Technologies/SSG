import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth.middleware';
import {
  setProviderAvailability, getProviderAvailability, getSlots,
  createBooking, payBooking,
  myBookings, providerBookings,
  updateStatus, cancelBooking,
  adminAllBookings
} from './booking.controller';

const router = Router();

// Availability
router.post('/availability', authenticate, authorize('DOCTOR', 'NURSE'), setProviderAvailability);
router.get('/availability/:providerId', authenticate, getProviderAvailability);
router.get('/slots', authenticate, getSlots);

// Bookings - Patient
router.post('/create', authenticate, authorize('USER'), createBooking);
router.post('/pay', authenticate, authorize('USER'), payBooking);
router.get('/my', authenticate, authorize('USER'), myBookings);
router.post('/cancel', authenticate, authorize('USER'), cancelBooking);

// Bookings - Provider
router.get('/provider', authenticate, authorize('DOCTOR', 'NURSE'), providerBookings);
router.post('/status', authenticate, authorize('DOCTOR', 'NURSE'), updateStatus);

// Admin
router.get('/admin/all', authenticate, authorize('ADMIN'), adminAllBookings);

export default router;
