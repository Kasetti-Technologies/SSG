import { query } from '../../config/database';
import { v4 as uuidv4 } from 'uuid';
import {
  sendBookingConfirmationToPatient,
  sendNewBookingToProvider,
  sendBookingCancelledToPatient,
  sendBookingCancelledToProvider
} from '../email/email.service';

export const setAvailability = async (providerId: string, slots: any[]) => {
  await query(`DELETE FROM availability WHERE provider_id = $1`, [providerId]);
  for (const slot of slots) {
    await query(
      `INSERT INTO availability (provider_id, day_of_week, start_time, end_time, slot_duration)
       VALUES ($1, $2, $3, $4, $5)`,
      [providerId, slot.day_of_week, slot.start_time, slot.end_time, slot.slot_duration || 30]
    );
  }
  return getAvailability(providerId);
};

export const getAvailability = async (providerId: string) => {
  const result = await query(
    `SELECT * FROM availability WHERE provider_id = $1 AND is_active = true ORDER BY day_of_week, start_time`,
    [providerId]
  );
  return result.rows;
};

export const getAvailableSlots = async (providerId: string, date: string) => {
  const dateObj = new Date(date);
  const dayOfWeek = dateObj.getDay();

  const availResult = await query(
    `SELECT * FROM availability WHERE provider_id = $1 AND day_of_week = $2 AND is_active = true`,
    [providerId, dayOfWeek]
  );
  if (availResult.rows.length === 0) return [];

  const bookedResult = await query(
    `SELECT booking_time FROM bookings
     WHERE provider_id = $1 AND booking_date = $2 AND status NOT IN ('CANCELLED')`,
    [providerId, date]
  );
  const bookedTimes = bookedResult.rows.map((r: any) => r.booking_time.slice(0, 5));

  const slots: string[] = [];
  for (const avail of availResult.rows) {
    const start = timeToMinutes(avail.start_time.slice(0, 5));
    const end = timeToMinutes(avail.end_time.slice(0, 5));
    const duration = avail.slot_duration;
    for (let t = start; t + duration <= end; t += duration) {
      const timeStr = minutesToTime(t);
      if (!bookedTimes.includes(timeStr)) slots.push(timeStr);
    }
  }
  return slots;
};

const timeToMinutes = (time: string) => {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
};

const minutesToTime = (minutes: number) => {
  const h = Math.floor(minutes / 60).toString().padStart(2, '0');
  const m = (minutes % 60).toString().padStart(2, '0');
  return `${h}:${m}`;
};

export const initiateBooking = async (
  patientId: string, providerId: string,
  date: string, time: string, type: string, notes: string
) => {
  const providerResult = await query(
    `SELECT u.name, u.email, p.consultation_fee FROM users u
     LEFT JOIN profiles p ON u.id = p.user_id WHERE u.id = $1`,
    [providerId]
  );
  if (providerResult.rows.length === 0) throw new Error('Provider not found');
  const provider = providerResult.rows[0];
  const amount = provider.consultation_fee || 500;

  const result = await query(
    `INSERT INTO bookings (patient_id, provider_id, booking_date, booking_time, type, status, payment_status, amount, notes)
     VALUES ($1, $2, $3, $4, $5, 'PAYMENT_PENDING', 'PENDING', $6, $7) RETURNING *`,
    [patientId, providerId, date, time, type, amount, notes]
  );
  return { booking: result.rows[0], amount, providerName: provider.name };
};

export const confirmPayment = async (bookingId: string, patientId: string) => {
  const fakePaymentId = `PAY_${uuidv4().slice(0, 8).toUpperCase()}`;

  const result = await query(
    `UPDATE bookings SET status = 'CONFIRMED', payment_status = 'PAID', payment_id = $1, updated_at = NOW()
     WHERE id = $2 AND patient_id = $3 RETURNING *`,
    [fakePaymentId, bookingId, patientId]
  );
  if (result.rows.length === 0) throw new Error('Booking not found');
  const booking = result.rows[0];

  // Get patient and provider details for emails
  const [patientRes, providerRes] = await Promise.all([
    query(`SELECT name, email FROM users WHERE id = $1`, [patientId]),
    query(`SELECT u.name, u.email FROM users u WHERE u.id = $1`, [booking.provider_id]),
  ]);

  const patient = patientRes.rows[0];
  const provider = providerRes.rows[0];

  // Send emails
  if (patient && provider) {
    sendBookingConfirmationToPatient(
      patient.email, patient.name, provider.name,
      booking.booking_date, booking.booking_time.slice(0,5),
      booking.type, booking.amount, fakePaymentId
    ).catch(() => {});

    sendNewBookingToProvider(
      provider.email, provider.name, patient.name,
      booking.booking_date, booking.booking_time.slice(0,5),
      booking.type, booking.amount, booking.notes
    ).catch(() => {});
  }

  return booking;
};

export const getPatientBookings = async (patientId: string) => {
  const result = await query(
    `SELECT b.*, u.name as provider_name, u.role as provider_role, p.specialization, p.location
     FROM bookings b
     JOIN users u ON b.provider_id = u.id
     LEFT JOIN profiles p ON u.id = p.user_id
     WHERE b.patient_id = $1
     ORDER BY b.booking_date DESC, b.booking_time DESC`,
    [patientId]
  );
  return result.rows;
};

export const getProviderBookings = async (providerId: string) => {
  const result = await query(
    `SELECT b.*, u.name as patient_name, u.email as patient_email, u.phone as patient_phone
     FROM bookings b
     JOIN users u ON b.patient_id = u.id
     WHERE b.provider_id = $1
     ORDER BY b.booking_date DESC, b.booking_time DESC`,
    [providerId]
  );
  return result.rows;
};

export const updateBookingStatus = async (
  bookingId: string, providerId: string, status: string, reason?: string
) => {
  const result = await query(
    `UPDATE bookings SET status = $1, cancel_reason = $2, updated_at = NOW()
     WHERE id = $3 AND provider_id = $4 RETURNING *`,
    [status, reason || null, bookingId, providerId]
  );
  if (result.rows.length === 0) throw new Error('Booking not found');
  const booking = result.rows[0];

  // Send cancellation email to patient if cancelled
  if (status === 'CANCELLED') {
    const [patientRes, providerRes] = await Promise.all([
      query(`SELECT name, email FROM users WHERE id = $1`, [booking.patient_id]),
      query(`SELECT name FROM users WHERE id = $1`, [providerId]),
    ]);
    if (patientRes.rows[0] && providerRes.rows[0]) {
      sendBookingCancelledToPatient(
        patientRes.rows[0].email,
        patientRes.rows[0].name,
        providerRes.rows[0].name,
        booking.booking_date,
        booking.booking_time.slice(0,5),
        reason || 'Cancelled by provider'
      ).catch(() => {});
    }
  }

  return booking;
};

export const cancelBookingByPatient = async (
  bookingId: string, patientId: string, reason: string
) => {
  const result = await query(
    `UPDATE bookings SET status = 'CANCELLED', cancel_reason = $1, updated_at = NOW()
     WHERE id = $2 AND patient_id = $3 AND status NOT IN ('CANCELLED', 'COMPLETED')
     RETURNING *`,
    [reason, bookingId, patientId]
  );
  if (result.rows.length === 0) throw new Error('Booking not found or cannot be cancelled');
  const booking = result.rows[0];

  // Send email to provider
  const [patientRes, providerRes] = await Promise.all([
    query(`SELECT name FROM users WHERE id = $1`, [patientId]),
    query(`SELECT name, email FROM users WHERE id = $1`, [booking.provider_id]),
  ]);
  if (patientRes.rows[0] && providerRes.rows[0]) {
    sendBookingCancelledToProvider(
      providerRes.rows[0].email,
      providerRes.rows[0].name,
      patientRes.rows[0].name,
      booking.booking_date,
      booking.booking_time.slice(0,5)
    ).catch(() => {});
  }

  return booking;
};

export const getAdminBookings = async () => {
  const result = await query(
    `SELECT b.*,
            pu.name as patient_name, pu.email as patient_email,
            pr.name as provider_name, pr.role as provider_role
     FROM bookings b
     JOIN users pu ON b.patient_id = pu.id
     JOIN users pr ON b.provider_id = pr.id
     ORDER BY b.created_at DESC`
  );
  return result.rows;
};
