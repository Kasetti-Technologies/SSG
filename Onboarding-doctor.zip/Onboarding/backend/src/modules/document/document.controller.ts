import { Request, Response } from 'express';
import multer from 'multer';
import { AuthRequest } from '../../middleware/auth.middleware';
import { uploadDocument, getMyDocuments, approveDocument, rejectDocument } from './document.service';
import { asyncHandler } from '../../middleware/error.middleware';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
export const uploadMiddleware = upload.single('file');

export const uploadDoc = asyncHandler(async (req: AuthRequest, res: Response) => {
  if (!req.file) {
    return res.status(400).json({ success: false, message: 'No file provided' });
  }

  const { type } = req.body;
  if (!type) {
    return res.status(400).json({ success: false, message: 'Document type is required' });
  }

  const validTypes = ['MEDICAL_DEGREE', 'LICENSE', 'ID_PROOF', 'PROFILE_PHOTO', 'NURSING_CERTIFICATE', 'EXPERIENCE_PROOF'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({ success: false, message: 'Invalid document type' });
  }

  const doc = await uploadDocument(req.user!.id, type, req.file);
  res.status(201).json({ success: true, message: 'Document uploaded', data: doc });
});

export const listMyDocuments = asyncHandler(async (req: AuthRequest, res: Response) => {
  const docs = await getMyDocuments(req.user!.id);
  res.json({ success: true, data: docs });
});

export const approveDoc = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { docId } = req.body;
  if (!docId) return res.status(400).json({ success: false, message: 'docId required' });
  await approveDocument(docId, req.user!.id);
  res.json({ success: true, message: 'Document approved' });
});

export const rejectDoc = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { docId, remarks } = req.body;
  if (!docId || !remarks) return res.status(400).json({ success: false, message: 'docId and remarks required' });
  await rejectDocument(docId, req.user!.id, remarks);
  res.json({ success: true, message: 'Document rejected' });
});
