import { Router } from 'express';
import { uploadDoc, uploadMiddleware, listMyDocuments, approveDoc, rejectDoc } from './document.controller';
import { authenticate, authorize } from '../../middleware/auth.middleware';

const router = Router();

router.post('/upload', authenticate, uploadMiddleware, uploadDoc);
router.get('/my', authenticate, listMyDocuments);
router.post('/approve', authenticate, authorize('ADMIN'), approveDoc);
router.post('/reject', authenticate, authorize('ADMIN'), rejectDoc);

export default router;
