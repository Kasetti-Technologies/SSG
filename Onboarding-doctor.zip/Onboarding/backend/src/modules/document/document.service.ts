import { minioClient, BUCKET_NAME, getSignedUrl } from '../../config/minio';
import { query } from '../../config/database';
import { v4 as uuidv4 } from 'uuid';

export const uploadDocument = async (
  userId: string,
  type: string,
  file: Express.Multer.File
) => {
  const objectName = `${userId}/${type}/${uuidv4()}-${file.originalname}`;

  await minioClient.putObject(BUCKET_NAME, objectName, file.buffer, file.size, {
    'Content-Type': file.mimetype,
  });

  // Delete old document of same type if exists
  await query(
    `DELETE FROM documents WHERE user_id = $1 AND type = $2`,
    [userId, type]
  );

  const result = await query(
    `INSERT INTO documents (user_id, type, file_url, file_name, file_size)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING *`,
    [userId, type, objectName, file.originalname, file.size]
  );

  // Update user status to DOCUMENT_SUBMITTED if PROFILE_COMPLETED or NEEDS_UPDATE
  await query(
    `UPDATE users SET status = 'DOCUMENT_SUBMITTED', updated_at = NOW()
     WHERE id = $1 AND status IN ('PROFILE_COMPLETED', 'NEEDS_UPDATE')`,
    [userId]
  );

  return result.rows[0];
};

export const getMyDocuments = async (userId: string) => {
  const result = await query(
    `SELECT * FROM documents WHERE user_id = $1 ORDER BY created_at DESC`,
    [userId]
  );

  const docs = await Promise.all(
    result.rows.map(async (doc) => ({
      ...doc,
      signed_url: await getSignedUrl(doc.file_url),
    }))
  );

  return docs;
};

export const getUserDocuments = async (userId: string) => {
  return getMyDocuments(userId);
};

export const approveDocument = async (docId: string, adminId: string) => {
  await query(
    `UPDATE documents SET status = 'APPROVED', updated_at = NOW() WHERE id = $1`,
    [docId]
  );

  // Check if all documents for this user are approved
  const doc = await query(`SELECT user_id FROM documents WHERE id = $1`, [docId]);
  if (doc.rows.length === 0) return;

  const userId = doc.rows[0].user_id;
  await checkAndActivateProvider(userId, adminId);
};

export const rejectDocument = async (docId: string, adminId: string, remarks: string) => {
  await query(
    `UPDATE documents SET status = 'REJECTED', updated_at = NOW() WHERE id = $1`,
    [docId]
  );

  // Set provider status to NEEDS_UPDATE
  const doc = await query(`SELECT user_id FROM documents WHERE id = $1`, [docId]);
  if (doc.rows.length === 0) return;

  const userId = doc.rows[0].user_id;
  await query(
    `UPDATE users SET status = 'NEEDS_UPDATE', updated_at = NOW() WHERE id = $1`,
    [userId]
  );

  // Log the rejection in verifications
  await query(`DELETE FROM verifications WHERE user_id = $1`, [userId]);
  await query(
    `INSERT INTO verifications (user_id, status, verified_by, remarks)
     VALUES ($1, 'NEEDS_UPDATE', $2, $3)`,
    [userId, adminId, remarks]
  );
};

const checkAndActivateProvider = async (userId: string, adminId: string) => {
  // Get required doc types based on provider role
  const userResult = await query(`SELECT role FROM users WHERE id = $1`, [userId]);
  if (userResult.rows.length === 0) return;

  const role = userResult.rows[0].role;
  const requiredDocs = role === 'DOCTOR'
    ? ['MEDICAL_DEGREE', 'LICENSE', 'ID_PROOF']
    : ['NURSING_CERTIFICATE', 'ID_PROOF'];

  // Check if all required docs are approved
  const docsResult = await query(
    `SELECT type, status FROM documents WHERE user_id = $1`,
    [userId]
  );

  const approvedTypes = docsResult.rows
    .filter((d: any) => d.status === 'APPROVED')
    .map((d: any) => d.type);

  const allApproved = requiredDocs.every(req => approvedTypes.includes(req));

  if (allApproved) {
    await query(
      `UPDATE users SET status = 'ACTIVE', updated_at = NOW() WHERE id = $1`,
      [userId]
    );
    await query(`DELETE FROM verifications WHERE user_id = $1`, [userId]);
    await query(
      `INSERT INTO verifications (user_id, status, verified_by, remarks)
       VALUES ($1, 'APPROVED', $2, $3)`,
      [userId, adminId, 'All required documents verified and approved']
    );
  }
};
