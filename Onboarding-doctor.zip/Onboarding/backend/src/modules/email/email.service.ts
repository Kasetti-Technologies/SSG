import nodemailer from 'nodemailer';
import dotenv from 'dotenv';

dotenv.config();

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'mailpit',
    port: parseInt(process.env.SMTP_PORT || '1025'),
    secure: false,
    ignoreTLS: true,
  });
};

const sendEmail = async (to: string, subject: string, html: string) => {
  try {
    const transporter = createTransporter();
    await transporter.sendMail({
      from: `"HealthCare Platform" <${process.env.SMTP_FROM || 'noreply@healthcare.com'}>`,
      to,
      subject,
      html,
    });
    console.log(`✅ Email sent → ${to}: ${subject}`);
  } catch (err) {
    console.error(`❌ Email failed → ${to}:`, err);
  }
};

const baseTemplate = (content: string) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; margin: 0; padding: 20px; }
    .container { max-width: 560px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    .header { background: #1a365d; padding: 28px 32px; text-align: center; }
    .header h1 { color: white; margin: 0; font-size: 22px; }
    .header p { color: #90cdf4; margin: 6px 0 0; font-size: 13px; }
    .body { padding: 32px; color: #2d3748; line-height: 1.6; }
    .body h2 { font-size: 20px; margin-top: 0; }
    .info-box { background: #f7fafc; border-radius: 8px; padding: 16px; margin: 16px 0; }
    .info-row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid #e2e8f0; font-size: 14px; }
    .info-row:last-child { border-bottom: none; }
    .badge-green { display:inline-block; background: #f0fff4; color: #276749; padding: 4px 14px; border-radius: 20px; font-weight: 600; }
    .badge-red { display:inline-block; background: #fff5f5; color: #c53030; padding: 4px 14px; border-radius: 20px; font-weight: 600; }
    .badge-yellow { display:inline-block; background: #fffbeb; color: #744210; padding: 4px 14px; border-radius: 20px; font-weight: 600; }
    .badge-blue { display:inline-block; background: #ebf8ff; color: #2b6cb0; padding: 4px 14px; border-radius: 20px; font-weight: 600; }
    .footer { background: #f7fafc; padding: 20px 32px; text-align: center; font-size: 12px; color: #a0aec0; border-top: 1px solid #e2e8f0; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🏥 HealthCare Platform</h1>
      <p>Connecting patients with verified healthcare providers</p>
    </div>
    <div class="body">${content}</div>
    <div class="footer">
      <p>© 2026 HealthCare Platform. All rights reserved.</p>
      <p>This is an automated email, please do not reply.</p>
    </div>
  </div>
</body>
</html>`;

// ── Email Senders ─────────────────────────────────────────

export const sendWelcomeEmail = async (to: string, name: string, role: string) => {
  await sendEmail(to, '🏥 Welcome to HealthCare Platform!', baseTemplate(`
    <h2>Welcome, ${name}! 👋</h2>
    <p>Thank you for registering as a <strong>${role}</strong> on HealthCare Platform.</p>
    <p>Here's what happens next:</p>
    <div class="info-box">
      <div class="info-row"><span>Step 1</span><span>Complete your profile</span></div>
      <div class="info-row"><span>Step 2</span><span>Upload required documents</span></div>
      <div class="info-row"><span>Step 3</span><span>Wait for admin verification</span></div>
      <div class="info-row"><span>Step 4</span><span>Go live and accept bookings!</span></div>
    </div>
    <p>Login to your provider portal to get started.</p>
  `));
};

export const sendProviderApprovedEmail = async (to: string, name: string) => {
  await sendEmail(to, '🎉 Your account has been approved!', baseTemplate(`
    <h2>Congratulations, ${name}! 🎉</h2>
    <p>Your application has been <span class="badge-green">APPROVED</span> by our admin team.</p>
    <p>Your profile is now <strong>live</strong> on the platform. Patients can find you and book appointments!</p>
    <div class="info-box">
      <div class="info-row"><span>Status</span><span class="badge-green">ACTIVE</span></div>
      <div class="info-row"><span>Next Step</span><span>Set your availability slots</span></div>
    </div>
    <p>Login to your provider portal to set your availability and start accepting bookings.</p>
  `));
};

export const sendProviderRejectedEmail = async (to: string, name: string, remarks: string) => {
  await sendEmail(to, '❌ Application Status Update', baseTemplate(`
    <h2>Application Update, ${name}</h2>
    <p>Unfortunately, your application has been <span class="badge-red">REJECTED</span>.</p>
    <div class="info-box">
      <div class="info-row"><span>Status</span><span class="badge-red">REJECTED</span></div>
      <div class="info-row"><span>Reason</span><span>${remarks}</span></div>
    </div>
    <p>If you believe this is a mistake or have questions, please contact our support team.</p>
  `));
};

export const sendProviderNeedsUpdateEmail = async (to: string, name: string, remarks: string) => {
  await sendEmail(to, '⚠️ Action Required: Update Your Application', baseTemplate(`
    <h2>Update Required, ${name}</h2>
    <p>Our admin team has reviewed your application and requires some updates.</p>
    <div class="info-box">
      <div class="info-row"><span>Status</span><span class="badge-yellow">NEEDS UPDATE</span></div>
      <div class="info-row"><span>Admin Remarks</span><span>${remarks}</span></div>
    </div>
    <p>Please login to your provider portal and make the requested changes.</p>
  `));
};

export const sendBookingConfirmationToPatient = async (
  to: string,
  patientName: string,
  providerName: string,
  date: string,
  time: string,
  type: string,
  amount: number,
  paymentId: string
) => {
  const formattedDate = new Date(date).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  await sendEmail(to, '✅ Booking Confirmed!', baseTemplate(`
    <h2>Booking Confirmed! ✅</h2>
    <p>Hi ${patientName}, your appointment has been booked successfully.</p>
    <div class="info-box">
      <div class="info-row"><span>Provider</span><span><strong>${providerName}</strong></span></div>
      <div class="info-row"><span>Date</span><span>${formattedDate}</span></div>
      <div class="info-row"><span>Time</span><span>${time}</span></div>
      <div class="info-row"><span>Type</span><span>${type === 'ONLINE' ? '💻 Online Consultation' : '🏥 In-Person Visit'}</span></div>
      <div class="info-row"><span>Amount Paid</span><span><strong>₹${amount}</strong></span></div>
      <div class="info-row"><span>Payment ID</span><span>${paymentId}</span></div>
      <div class="info-row"><span>Status</span><span class="badge-green">CONFIRMED</span></div>
    </div>
    <p>${type === 'ONLINE' ? 'The provider will share the meeting link before your appointment.' : 'Please arrive 10 minutes before your appointment time.'}</p>
  `));
};

export const sendNewBookingToProvider = async (
  to: string,
  providerName: string,
  patientName: string,
  date: string,
  time: string,
  type: string,
  amount: number,
  notes?: string
) => {
  const formattedDate = new Date(date).toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  await sendEmail(to, '📅 New Booking Received!', baseTemplate(`
    <h2>New Appointment Booking! 📅</h2>
    <p>Hi Dr. ${providerName}, you have a new booking from a patient.</p>
    <div class="info-box">
      <div class="info-row"><span>Patient</span><span><strong>${patientName}</strong></span></div>
      <div class="info-row"><span>Date</span><span>${formattedDate}</span></div>
      <div class="info-row"><span>Time</span><span>${time}</span></div>
      <div class="info-row"><span>Type</span><span>${type === 'ONLINE' ? '💻 Online' : '🏥 In-Person'}</span></div>
      <div class="info-row"><span>Fee</span><span><strong>₹${amount}</strong></span></div>
      ${notes ? `<div class="info-row"><span>Patient Notes</span><span>${notes}</span></div>` : ''}
    </div>
    <p>Login to your provider portal to confirm or manage this booking.</p>
  `));
};

export const sendBookingCancelledToPatient = async (
  to: string,
  patientName: string,
  providerName: string,
  date: string,
  time: string,
  reason: string
) => {
  const formattedDate = new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  await sendEmail(to, '❌ Booking Cancelled', baseTemplate(`
    <h2>Booking Cancelled</h2>
    <p>Hi ${patientName}, your appointment has been cancelled.</p>
    <div class="info-box">
      <div class="info-row"><span>Provider</span><span>${providerName}</span></div>
      <div class="info-row"><span>Date</span><span>${formattedDate} at ${time}</span></div>
      <div class="info-row"><span>Status</span><span class="badge-red">CANCELLED</span></div>
      <div class="info-row"><span>Reason</span><span>${reason}</span></div>
    </div>
    <p>You can book another appointment at your convenience.</p>
  `));
};

export const sendBookingCancelledToProvider = async (
  to: string,
  providerName: string,
  patientName: string,
  date: string,
  time: string
) => {
  const formattedDate = new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  await sendEmail(to, '❌ Patient Cancelled Booking', baseTemplate(`
    <h2>Booking Cancelled by Patient</h2>
    <p>Hi ${providerName}, a patient has cancelled their appointment.</p>
    <div class="info-box">
      <div class="info-row"><span>Patient</span><span>${patientName}</span></div>
      <div class="info-row"><span>Date</span><span>${formattedDate} at ${time}</span></div>
      <div class="info-row"><span>Status</span><span class="badge-red">CANCELLED</span></div>
    </div>
    <p>The time slot is now available for other patients.</p>
  `));
};

export const sendPatientWelcomeEmail = async (to: string, name: string) => {
  await sendEmail(to, '🏥 Welcome to HealthCare Platform!', baseTemplate(`
    <h2>Welcome, ${name}! 👋</h2>
    <p>Thank you for joining HealthCare Platform. You can now find and book appointments with verified doctors and nurses.</p>
    <div class="info-box">
      <div class="info-row"><span>✅</span><span>Browse verified doctors & nurses</span></div>
      <div class="info-row"><span>📅</span><span>Book online or in-person appointments</span></div>
      <div class="info-row"><span>💳</span><span>Secure payment processing</span></div>
    </div>
    <p>Start by browsing our verified healthcare providers!</p>
  `));
};
