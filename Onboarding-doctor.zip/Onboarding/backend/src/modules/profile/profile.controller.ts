import { Response } from 'express';
import { AuthRequest } from '../../middleware/auth.middleware';
import { getMyProfile, updateProfile, getActiveProviders } from './profile.service';
import { asyncHandler } from '../../middleware/error.middleware';

export const getProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
  const profile = await getMyProfile(req.user!.id);
  res.json({ success: true, data: profile });
});

export const updateMyProfile = asyncHandler(async (req: AuthRequest, res: Response) => {
  const profile = await updateProfile(req.user!.id, req.body);
  res.json({ success: true, message: 'Profile updated', data: profile });
});

export const listProviders = asyncHandler(async (req: AuthRequest, res: Response) => {
  const { role } = req.query;
  const providers = await getActiveProviders(role as string);
  res.json({ success: true, data: providers });
});
