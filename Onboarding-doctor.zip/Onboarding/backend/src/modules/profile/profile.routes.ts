import { Router } from 'express';
import { getProfile, updateMyProfile, listProviders } from './profile.controller';
import { authenticate } from '../../middleware/auth.middleware';

const router = Router();

router.get('/me', authenticate, getProfile);
router.put('/update', authenticate, updateMyProfile);
router.get('/providers', authenticate, listProviders);

export default router;
