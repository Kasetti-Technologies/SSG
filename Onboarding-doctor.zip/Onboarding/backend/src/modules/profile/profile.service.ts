import { query } from '../../config/database';

export const getMyProfile = async (userId: string) => {
  const result = await query(
    `SELECT u.id, u.name, u.email, u.phone, u.role, u.status, u.created_at,
            p.specialization, p.skills, p.experience, p.consultation_fee,
            p.languages, p.availability, p.location, p.bio, p.pricing
     FROM users u
     LEFT JOIN profiles p ON u.id = p.user_id
     WHERE u.id = $1`,
    [userId]
  );
  if (result.rows.length === 0) throw new Error('User not found');
  return result.rows[0];
};

export const updateProfile = async (userId: string, data: Record<string, unknown>) => {
  const { specialization, skills, experience, consultation_fee, languages, availability, location, bio, pricing, name, phone } = data;

  // Update user name/phone
  if (name || phone) {
    await query(
      `UPDATE users SET name = COALESCE($1, name), phone = COALESCE($2, phone), updated_at = NOW() WHERE id = $3`,
      [name, phone, userId]
    );
  }

  // Upsert profile
  await query(
    `INSERT INTO profiles (user_id, specialization, skills, experience, consultation_fee, languages, availability, location, bio, pricing)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
     ON CONFLICT (user_id) DO UPDATE SET
       specialization = COALESCE(EXCLUDED.specialization, profiles.specialization),
       skills = COALESCE(EXCLUDED.skills, profiles.skills),
       experience = COALESCE(EXCLUDED.experience, profiles.experience),
       consultation_fee = COALESCE(EXCLUDED.consultation_fee, profiles.consultation_fee),
       languages = COALESCE(EXCLUDED.languages, profiles.languages),
       availability = COALESCE(EXCLUDED.availability, profiles.availability),
       location = COALESCE(EXCLUDED.location, profiles.location),
       bio = COALESCE(EXCLUDED.bio, profiles.bio),
       pricing = COALESCE(EXCLUDED.pricing, profiles.pricing),
       updated_at = NOW()`,
    [userId, specialization, skills, experience, consultation_fee, languages, availability ? JSON.stringify(availability) : null, location, bio, pricing ? JSON.stringify(pricing) : null]
  );

  // Update status to PROFILE_COMPLETED if REGISTERED
  await query(
    `UPDATE users SET status = 'PROFILE_COMPLETED', updated_at = NOW()
     WHERE id = $1 AND status = 'REGISTERED'`,
    [userId]
  );

  return getMyProfile(userId);
};

export const getActiveProviders = async (role?: string) => {
  const roleFilter = role ? `AND u.role = $1` : '';
  const params = role ? [role] : [];

  const result = await query(
    `SELECT u.id, u.name, u.role, u.status,
            p.specialization, p.skills, p.experience, p.consultation_fee,
            p.languages, p.location, p.bio, p.pricing
     FROM users u
     LEFT JOIN profiles p ON u.id = p.user_id
     WHERE u.status = 'ACTIVE' AND u.role IN ('DOCTOR','NURSE')
     ${roleFilter}
     ORDER BY u.created_at DESC`,
    params
  );

  return result.rows;
};
