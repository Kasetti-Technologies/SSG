import { Router } from 'express';
import { authenticate, authorize } from '../../middleware/auth.middleware';
import { asyncHandler } from '../../middleware/error.middleware';
import { query } from '../../config/database';
import { AuthRequest } from '../../middleware/auth.middleware';
import { Response } from 'express';

const router = Router();

// Get own status (for providers to track their onboarding)
router.get('/status', authenticate, asyncHandler(async (req: AuthRequest, res: Response) => {
  const result = await query(
    `SELECT u.id, u.name, u.email, u.role, u.status,
            v.remarks, v.status as verification_status
     FROM users u
     LEFT JOIN verifications v ON u.id = v.user_id
     WHERE u.id = $1`,
    [req.user!.id]
  );
  if (result.rows.length === 0) return res.status(404).json({ success: false, message: 'User not found' });
  res.json({ success: true, data: result.rows[0] });
}));

export default router;
