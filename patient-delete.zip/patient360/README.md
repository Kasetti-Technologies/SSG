# 🏥 Patient 360 — Healthcare Management System

## Quick Start

### Prerequisites
- Docker Desktop installed and running
- Git Bash (Windows) or Terminal (Mac/Linux)

### Run in one command
```bash
cd patient360
./start.sh
```

First run takes ~3-4 minutes to build and start all containers.

---

## Access URLs

| App | URL | Credentials |
|---|---|---|
| Patient App | http://localhost:3010 | rahul@example.com / password123 |
| Admin App | http://localhost:3011 | admin@patient360.com / password123 |
| Backend API | http://localhost:4001/health | — |

---

## Demo Credentials

### Patients
| Name | Email | Password | Status |
|---|---|---|---|
| Rahul Sharma | rahul@example.com | password123 | ACTIVE |
| Priya Patel | priya@example.com | password123 | ACTIVE |
| Arjun Kumar | arjun@example.com | password123 | INACTIVE |
| Sneha Reddy | sneha@example.com | password123 | ACTIVE |

### Admin
| Email | Password |
|---|---|
| admin@patient360.com | password123 |

---

## Architecture

```
patient360/
├── docker-compose.yml
├── start.sh
├── backend/               Node.js + TypeScript + Express
│   ├── src/
│   │   ├── routes/
│   │   │   ├── auth.ts    Patient + Admin login
│   │   │   ├── patient.ts Patient 360 view (own data only)
│   │   │   └── admin.ts   Full patient management
│   │   ├── middleware/
│   │   │   └── auth.ts    JWT middleware (patient + admin roles)
│   │   └── db/index.ts    PostgreSQL connection
├── patient-app/           Next.js patient-facing app (:3010)
│   └── app/
│       ├── page.tsx       Login
│       └── dashboard/     360 view with tabs
└── admin-app/             Next.js admin app (:3011)
    └── app/
        ├── login/
        ├── dashboard/     Stats overview
        ├── patients/      Full CRUD + 360 view + actions
        └── deleted/       Soft-deleted patients list
```

---

## Patient Status Flow

```
ACTIVE → INACTIVE → DELETED (soft) → HARD DELETE (permanent)
         ↑_______________↑ (restore)
```

---

## API Endpoints

### Auth
- POST /api/auth/patient/login
- POST /api/auth/admin/login

### Patient (JWT required)
- GET /api/patient/:upi_id
- GET /api/patient/:upi_id/appointments
- GET /api/patient/:upi_id/labs
- GET /api/patient/:upi_id/prescriptions

### Admin (JWT required)
- GET /api/admin/patients
- GET /api/admin/patients/deleted
- GET /api/admin/patient/:upi_id
- POST /api/admin/patient
- PUT /api/admin/patient/:upi_id
- PUT /api/admin/patient/:upi_id/activate
- PUT /api/admin/patient/:upi_id/deactivate
- PUT /api/admin/patient/:upi_id/soft-delete
- PUT /api/admin/patient/:upi_id/restore
- DELETE /api/admin/patient/:upi_id
- GET /api/admin/stats

---

## Stop & Reset

```bash
# Stop (keep data)
docker compose down

# Full reset (delete all data)
docker compose down -v && ./start.sh
```
