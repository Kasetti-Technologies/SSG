"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function Dashboard() {
  const { admin } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    if (!admin) { router.push("/login"); return; }
    adminApi.stats().then(setStats).catch(console.error);
  }, [admin]);

  const statCards = [
    { label: "Total Patients", value: stats?.totalPatients, icon: "👥", color: "#60a5fa", bg: "rgba(96,165,250,0.1)" },
    { label: "Active", value: stats?.activePatients, icon: "✅", color: "#4ade80", bg: "rgba(74,222,128,0.1)" },
    { label: "Inactive", value: stats?.inactivePatients, icon: "⏸️", color: "#f59e0b", bg: "rgba(245,158,11,0.1)" },
    { label: "Soft Deleted", value: stats?.deletedPatients, icon: "🗑️", color: "#f87171", bg: "rgba(248,113,113,0.1)" },
    { label: "Appointments", value: stats?.totalAppointments, icon: "📅", color: "#a78bfa", bg: "rgba(167,139,250,0.1)" },
    { label: "Lab Results", value: stats?.totalLabResults, icon: "🧪", color: "#2dd4bf", bg: "rgba(45,212,191,0.1)" },
  ];

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora',sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        <div style={{ marginBottom: 32 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Dashboard</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>Patient 360 overview</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 32 }}>
          {statCards.map(({ label, value, icon, color, bg }) => (
            <div key={label} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 24 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, marginBottom: 16 }}>{icon}</div>
              <div style={{ color, fontSize: 28, fontWeight: 800 }}>{value ?? "…"}</div>
              <div style={{ color: "#475569", fontSize: 13, marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 24 }}>
          <h2 style={{ color: "#f1f5f9", fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Quick Actions</h2>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {[
              { label: "View All Patients", href: "/patients", color: "#60a5fa" },
              { label: "View Deleted", href: "/deleted", color: "#f87171" },
            ].map(({ label, href, color }) => (
              <button key={label} onClick={() => router.push(href)} style={{ padding: "10px 20px", borderRadius: 12, background: "transparent", border: `1px solid ${color}44`, color, fontSize: 14, fontWeight: 600, cursor: "pointer" }}>
                {label}
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
