"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function DeletedPage() {
  const { admin } = useAuth();
  const router = useRouter();
  const [patients, setPatients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ type: string; text: string } | null>(null);

  useEffect(() => {
    if (!admin) { router.push("/login"); return; }
    load();
  }, [admin]);

  function load() {
    setLoading(true);
    adminApi.patients.deleted().then(setPatients).finally(() => setLoading(false));
  }

  function showT(type: string, text: string) { setToast({ type, text }); setTimeout(() => setToast(null), 3000); }

  async function handleRestore(id: string) {
    try { await adminApi.patients.restore(id); showT("success", "Patient restored to INACTIVE"); load(); }
    catch (e: any) { showT("error", e.message); }
  }

  async function handleHardDelete(id: string) {
    if (!confirm("PERMANENTLY DELETE this patient and ALL records? This cannot be undone!")) return;
    try { await adminApi.patients.hardDelete(id); showT("success", "Patient permanently deleted"); load(); }
    catch (e: any) { showT("error", e.message); }
  }

  const td: React.CSSProperties = { color: "#cbd5e1", fontSize: 13, padding: "14px 16px", borderTop: "1px solid rgba(255,255,255,0.05)" };
  const th: React.CSSProperties = { color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "12px 16px", textTransform: "uppercase", letterSpacing: "0.08em" };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora',sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        {toast && (
          <div style={{ position: "fixed", top: 80, right: 24, zIndex: 100, background: toast.type === "success" ? "rgba(13,148,136,0.95)" : "rgba(220,38,38,0.95)", color: "#fff", padding: "14px 20px", borderRadius: 14, fontSize: 14, fontWeight: 600, boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
            {toast.text}
          </div>
        )}

        <div style={{ marginBottom: 28 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Deleted Patients</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>
            {patients.length} soft-deleted patients — can be restored or permanently deleted
          </p>
        </div>

        {/* Info box */}
        <div style={{ background: "rgba(245,158,11,0.08)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 14, padding: "14px 18px", marginBottom: 24, fontSize: 13, color: "#f59e0b" }}>
          ⚠️ Soft-deleted patients cannot login but their data is preserved. Restore to reactivate, or hard delete to permanently remove all records.
        </div>

        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ background: "rgba(255,255,255,0.03)" }}>
              <tr>
                {["Patient", "UPI ID", "Email", "Deleted On", "Actions"].map(h => (
                  <th key={h} style={th}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} style={{ ...td, textAlign: "center", padding: 48 }}>Loading…</td></tr>
              ) : patients.length === 0 ? (
                <tr><td colSpan={5} style={{ ...td, textAlign: "center", padding: 48, color: "#334155" }}>No deleted patients</td></tr>
              ) : patients.map((p: any) => (
                <tr key={p.upi_id}>
                  <td style={td}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 34, height: 34, borderRadius: 10, background: "rgba(248,113,113,0.2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#f87171", fontWeight: 800, fontSize: 14, flexShrink: 0 }}>
                        {p.first_name?.charAt(0)}
                      </div>
                      <span style={{ color: "#e2e8f0", fontWeight: 600 }}>{p.first_name} {p.last_name}</span>
                    </div>
                  </td>
                  <td style={{ ...td, fontFamily: "monospace", color: "#475569", fontSize: 12 }}>{p.upi_id}</td>
                  <td style={{ ...td, color: "#64748b" }}>{p.email || "—"}</td>
                  <td style={{ ...td, color: "#475569", fontSize: 12 }}>
                    {p.deleted_at ? new Date(p.deleted_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—"}
                  </td>
                  <td style={{ ...td, padding: "14px 16px" }}>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => handleRestore(p.upi_id)}
                        style={{ padding: "6px 12px", borderRadius: 8, background: "rgba(96,165,250,0.1)", border: "1px solid rgba(96,165,250,0.3)", color: "#60a5fa", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                        ↺ Restore
                      </button>
                      <button onClick={() => handleHardDelete(p.upi_id)}
                        style={{ padding: "6px 12px", borderRadius: 8, background: "rgba(220,38,38,0.1)", border: "1px solid rgba(220,38,38,0.3)", color: "#dc2626", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                        ⚠ Hard Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
