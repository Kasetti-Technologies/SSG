"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function PatientsPage() {
  const { admin } = useAuth();
  const router = useRouter();
  const [patients, setPatients] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ type: string; text: string } | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ upi_id: "", first_name: "", last_name: "", email: "", password: "", dob: "", gender: "", phone: "", aadhaar_no: "" });
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => { if (!admin) { router.push("/login"); return; } load(); }, [admin]);

  async function load() {
    setLoading(true);
    adminApi.patients.list().then(setPatients).finally(() => setLoading(false));
  }

  async function loadPatient(id: string) {
    const p = await adminApi.patients.get(id);
    setSelected(p);
    setActiveTab("overview");
  }

  function showT(type: string, text: string) { setToast({ type, text }); setTimeout(() => setToast(null), 3000); }

  async function action(fn: () => Promise<any>, msg: string) {
    try { await fn(); showT("success", msg); load(); if (selected) loadPatient(selected.upi_id); }
    catch (e: any) { showT("error", e.message); }
  }

  const filtered = patients.filter(p =>
    p.first_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.last_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.upi_id?.toLowerCase().includes(search.toLowerCase()) ||
    p.email?.toLowerCase().includes(search.toLowerCase())
  );

  const statusColor: Record<string, string> = { ACTIVE: "#4ade80", INACTIVE: "#f59e0b", DELETED: "#f87171" };
  const inp: React.CSSProperties = { width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none", boxSizing: "border-box" };
  const td: React.CSSProperties = { color: "#cbd5e1", fontSize: 13, padding: "12px 14px", borderTop: "1px solid rgba(255,255,255,0.05)" };
  const th: React.CSSProperties = { color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "10px 14px", textTransform: "uppercase", letterSpacing: "0.08em" };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora',sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        {toast && (
          <div style={{ position: "fixed", top: 80, right: 24, zIndex: 100, background: toast.type === "success" ? "rgba(13,148,136,0.95)" : "rgba(220,38,38,0.95)", color: "#fff", padding: "14px 20px", borderRadius: 14, fontSize: 14, fontWeight: 600, boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
            {toast.text}
          </div>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 24 }}>
          <div>
            <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Patients</h1>
            <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>{patients.length} patients registered</p>
          </div>
          <button onClick={() => setShowCreate(true)} style={{ padding: "9px 18px", borderRadius: 10, background: "linear-gradient(135deg,#7c3aed,#4f46e5)", border: "none", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
            + Add Patient
          </button>
        </div>

        {/* Create Form */}
        {showCreate && (
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: 24, marginBottom: 20 }}>
            <div style={{ color: "#f1f5f9", fontWeight: 700, marginBottom: 16 }}>New Patient</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 16 }}>
              {[
                { key: "upi_id", label: "UPI ID", ph: "UPI005" },
                { key: "first_name", label: "First Name", ph: "Rahul" },
                { key: "last_name", label: "Last Name", ph: "Sharma" },
                { key: "email", label: "Email", ph: "rahul@example.com" },
                { key: "password", label: "Password", ph: "••••••••" },
                { key: "phone", label: "Phone", ph: "9876543210" },
                { key: "dob", label: "Date of Birth", ph: "1990-05-15" },
                { key: "gender", label: "Gender", ph: "Male / Female" },
                { key: "aadhaar_no", label: "Aadhaar No", ph: "1234-5678-9012" },
              ].map(({ key, label, ph }) => (
                <div key={key}>
                  <label style={{ display: "block", color: "#64748b", fontSize: 12, marginBottom: 6, fontWeight: 600 }}>{label}</label>
                  <input value={(form as any)[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={ph}
                    type={key === "password" ? "password" : "text"} style={inp} />
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={async () => {
                try { await adminApi.patients.create(form); showT("success", "Patient created!"); setShowCreate(false); setForm({ upi_id: "", first_name: "", last_name: "", email: "", password: "", dob: "", gender: "", phone: "", aadhaar_no: "" }); load(); }
                catch (e: any) { showT("error", e.message); }
              }} style={{ padding: "9px 20px", borderRadius: 10, background: "linear-gradient(135deg,#7c3aed,#4f46e5)", border: "none", color: "#fff", fontWeight: 700, cursor: "pointer" }}>Create Patient</button>
              <button onClick={() => setShowCreate(false)} style={{ padding: "9px 20px", borderRadius: 10, background: "transparent", border: "1px solid rgba(255,255,255,0.1)", color: "#64748b", cursor: "pointer" }}>Cancel</button>
            </div>
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 1.6fr" : "1fr", gap: 20 }}>
          {/* Patient List */}
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
            <div style={{ padding: "16px 16px 12px" }}>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, UPI ID, email…"
                style={{ ...inp, background: "rgba(255,255,255,0.03)" }} />
            </div>
            {loading ? <div style={{ textAlign: "center", padding: 40, color: "#475569" }}>Loading…</div> : (
              <div style={{ maxHeight: 600, overflowY: "auto" }}>
                {filtered.map(p => (
                  <div key={p.upi_id} onClick={() => loadPatient(p.upi_id)}
                    style={{ padding: "14px 16px", borderTop: "1px solid rgba(255,255,255,0.05)", cursor: "pointer", background: selected?.upi_id === p.upi_id ? "rgba(124,58,237,0.1)" : "transparent", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ width: 36, height: 36, borderRadius: 10, background: "linear-gradient(135deg,#7c3aed,#4f46e5)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 800, fontSize: 14, flexShrink: 0 }}>
                        {p.first_name?.charAt(0)}
                      </div>
                      <div>
                        <div style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{p.first_name} {p.last_name}</div>
                        <div style={{ color: "#475569", fontSize: 12, marginTop: 2 }}>{p.upi_id} · {p.email}</div>
                      </div>
                    </div>
                    <span style={{ background: `${statusColor[p.status]}22`, color: statusColor[p.status], fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999, flexShrink: 0 }}>{p.status}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Patient 360 View */}
          {selected && (
            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
              {/* Header */}
              <div style={{ background: "linear-gradient(135deg,#7c3aed,#4f46e5)", padding: "20px 24px", position: "relative" }}>
                <button onClick={() => setSelected(null)} style={{ position: "absolute", top: 16, right: 16, background: "rgba(255,255,255,0.15)", border: "none", color: "#fff", width: 28, height: 28, borderRadius: "50%", cursor: "pointer", fontSize: 16, display: "flex", alignItems: "center", justifyContent: "center" }}>×</button>
                <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 4 }}>Patient 360 View</div>
                <div style={{ color: "#fff", fontSize: 20, fontWeight: 800 }}>{selected.first_name} {selected.last_name}</div>
                <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 13, marginTop: 2 }}>{selected.upi_id} · {selected.email}</div>
                <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
                  {[{ l: "DOB", v: selected.dob ? new Date(selected.dob).toLocaleDateString("en-IN") : "—" },
                    { l: "Gender", v: selected.gender || "—" },
                    { l: "Phone", v: selected.phone || "—" }].map(({ l, v }) => (
                    <div key={l}><div style={{ color: "rgba(255,255,255,0.5)", fontSize: 10, textTransform: "uppercase" }}>{l}</div><div style={{ color: "#fff", fontSize: 13 }}>{v}</div></div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div style={{ padding: "16px 24px", borderBottom: "1px solid rgba(255,255,255,0.07)", display: "flex", gap: 8, flexWrap: "wrap" }}>
                {selected.status !== "ACTIVE" && selected.status !== "DELETED" && (
                  <button onClick={() => action(() => adminApi.patients.activate(selected.upi_id), "Patient activated")}
                    style={{ padding: "7px 14px", borderRadius: 9, background: "rgba(74,222,128,0.1)", border: "1px solid rgba(74,222,128,0.3)", color: "#4ade80", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                    ✓ Activate
                  </button>
                )}
                {selected.status === "ACTIVE" && (
                  <button onClick={() => action(() => adminApi.patients.deactivate(selected.upi_id), "Patient deactivated")}
                    style={{ padding: "7px 14px", borderRadius: 9, background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)", color: "#f59e0b", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                    ⏸ Deactivate
                  </button>
                )}
                {selected.status !== "DELETED" && (
                  <button onClick={() => { if (confirm("Soft delete this patient?")) action(() => adminApi.patients.softDelete(selected.upi_id), "Patient soft deleted"); }}
                    style={{ padding: "7px 14px", borderRadius: 9, background: "rgba(248,113,113,0.1)", border: "1px solid rgba(248,113,113,0.3)", color: "#f87171", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                    🗑 Soft Delete
                  </button>
                )}
                {selected.status === "DELETED" && (
                  <button onClick={() => action(() => adminApi.patients.restore(selected.upi_id), "Patient restored")}
                    style={{ padding: "7px 14px", borderRadius: 9, background: "rgba(96,165,250,0.1)", border: "1px solid rgba(96,165,250,0.3)", color: "#60a5fa", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                    ↺ Restore
                  </button>
                )}
                <button onClick={() => { if (confirm("PERMANENTLY DELETE this patient? This cannot be undone.")) { action(() => adminApi.patients.hardDelete(selected.upi_id), "Patient permanently deleted"); setSelected(null); }}}
                  style={{ padding: "7px 14px", borderRadius: 9, background: "rgba(220,38,38,0.1)", border: "1px solid rgba(220,38,38,0.3)", color: "#dc2626", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                  ⚠ Hard Delete
                </button>
              </div>

              {/* Tabs */}
              <div style={{ padding: "12px 24px 0", display: "flex", gap: 8 }}>
                {["overview", "appointments", "labs", "prescriptions"].map(t => (
                  <button key={t} onClick={() => setActiveTab(t)} style={{ padding: "6px 14px", borderRadius: 999, fontSize: 12, fontWeight: 600, cursor: "pointer", border: "1px solid", textTransform: "capitalize",
                    background: activeTab === t ? "rgba(124,58,237,0.2)" : "transparent",
                    borderColor: activeTab === t ? "rgba(124,58,237,0.5)" : "rgba(255,255,255,0.08)",
                    color: activeTab === t ? "#a78bfa" : "#475569" }}>
                    {t}
                  </button>
                ))}
              </div>

              {/* Tab content */}
              <div style={{ padding: "16px 24px", maxHeight: 380, overflowY: "auto" }}>
                {activeTab === "overview" && (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    {[
                      { l: "Appointments", v: selected.appointments?.length || 0, icon: "📅", color: "#60a5fa" },
                      { l: "Lab Results", v: selected.labResults?.length || 0, icon: "🧪", color: "#2dd4bf" },
                      { l: "Prescriptions", v: selected.prescriptions?.length || 0, icon: "💊", color: "#a78bfa" },
                      { l: "Account Status", v: selected.status, icon: "🔒", color: statusColor[selected.status] },
                    ].map(({ l, v, icon, color }) => (
                      <div key={l} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "14px 16px" }}>
                        <div style={{ fontSize: 20, marginBottom: 6 }}>{icon}</div>
                        <div style={{ color, fontSize: 22, fontWeight: 800 }}>{v}</div>
                        <div style={{ color: "#475569", fontSize: 12 }}>{l}</div>
                      </div>
                    ))}
                  </div>
                )}
                {activeTab === "appointments" && (
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr>{["Doctor", "Date", "Status"].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                    <tbody>
                      {!selected.appointments?.length ? <tr><td colSpan={3} style={{ ...td, textAlign: "center", color: "#334155" }}>No appointments</td></tr>
                        : selected.appointments.map((a: any) => (
                          <tr key={a.appointment_id}>
                            <td style={td}>{a.doctor_name}</td>
                            <td style={td}>{new Date(a.appointment_date).toLocaleDateString("en-IN")}</td>
                            <td style={td}><span style={{ background: `${statusColor[a.status] || "#94a3b8"}22`, color: statusColor[a.status] || "#94a3b8", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>{a.status}</span></td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                )}
                {activeTab === "labs" && (
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr>{["Test", "Result", "Date", "Status"].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                    <tbody>
                      {!selected.labResults?.length ? <tr><td colSpan={4} style={{ ...td, textAlign: "center", color: "#334155" }}>No lab results</td></tr>
                        : selected.labResults.map((l: any) => (
                          <tr key={l.lab_id}>
                            <td style={td}>{l.test_name}</td>
                            <td style={td}>{l.result}</td>
                            <td style={td}>{new Date(l.result_date).toLocaleDateString("en-IN")}</td>
                            <td style={td}><span style={{ background: (l.status === "NORMAL" ? "#4ade80" : "#f87171") + "22", color: l.status === "NORMAL" ? "#4ade80" : "#f87171", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>{l.status}</span></td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                )}
                {activeTab === "prescriptions" && (
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr>{["Medicine", "Dosage", "Doctor", "Duration"].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
                    <tbody>
                      {!selected.prescriptions?.length ? <tr><td colSpan={4} style={{ ...td, textAlign: "center", color: "#334155" }}>No prescriptions</td></tr>
                        : selected.prescriptions.map((p: any) => (
                          <tr key={p.prescription_id}>
                            <td style={{ ...td, fontWeight: 600, color: "#e2e8f0" }}>{p.medicine}</td>
                            <td style={td}>{p.dosage}</td>
                            <td style={td}>{p.doctor}</td>
                            <td style={td}>{p.duration || "—"}</td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
