"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

const links = [
  { href: "/dashboard", icon: "📊", label: "Dashboard" },
  { href: "/patients", icon: "👥", label: "Patients" },
  { href: "/deleted", icon: "🗑️", label: "Deleted Patients" },
];

export default function Sidebar() {
  const path = usePathname();
  const { admin, logout } = useAuth();
  const router = useRouter();

  return (
    <aside style={{ width: 240, background: "#060d1a", borderRight: "1px solid rgba(255,255,255,0.06)", minHeight: "100vh", display: "flex", flexDirection: "column", flexShrink: 0, fontFamily: "'Sora',sans-serif" }}>
      <div style={{ padding: "28px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 24 }}>🏥</span>
          <div>
            <div style={{ color: "#a78bfa", fontWeight: 800, fontSize: 15 }}>Patient 360</div>
            <div style={{ color: "#334155", fontSize: 11, marginTop: 1 }}>Admin Panel</div>
          </div>
        </div>
      </div>
      <nav style={{ padding: "16px 12px", flex: 1 }}>
        {links.map(({ href, icon, label }) => {
          const active = path === href;
          return (
            <Link key={href} href={href} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 14px", borderRadius: 12, marginBottom: 4, textDecoration: "none", background: active ? "rgba(124,58,237,0.15)" : "transparent", color: active ? "#a78bfa" : "#475569", fontWeight: active ? 600 : 400, fontSize: 14, borderLeft: active ? "3px solid #a78bfa" : "3px solid transparent" }}>
              <span style={{ fontSize: 17 }}>{icon}</span>{label}
            </Link>
          );
        })}
      </nav>
      <div style={{ padding: 16, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ color: "#475569", fontSize: 12, marginBottom: 8 }}>{admin?.name}</div>
        <button onClick={() => { logout(); router.push("/login"); }} style={{ width: "100%", padding: "8px", borderRadius: 10, background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#f87171", fontSize: 13, cursor: "pointer", fontWeight: 600 }}>
          Logout
        </button>
      </div>
    </aside>
  );
}
