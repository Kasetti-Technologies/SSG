const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4001";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("p360_admin_token");
}

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Request failed" }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

export const adminApi = {
  auth: { login: (email: string, password: string) => apiFetch<any>("/api/auth/admin/login", { method: "POST", body: JSON.stringify({ email, password }) }) },
  patients: {
    list: () => apiFetch<any[]>("/api/admin/patients"),
    deleted: () => apiFetch<any[]>("/api/admin/patients/deleted"),
    get: (id: string) => apiFetch<any>(`/api/admin/patient/${id}`),
    create: (data: any) => apiFetch<any>("/api/admin/patient", { method: "POST", body: JSON.stringify(data) }),
    update: (id: string, data: any) => apiFetch<any>(`/api/admin/patient/${id}`, { method: "PUT", body: JSON.stringify(data) }),
    activate: (id: string) => apiFetch<any>(`/api/admin/patient/${id}/activate`, { method: "PUT" }),
    deactivate: (id: string) => apiFetch<any>(`/api/admin/patient/${id}/deactivate`, { method: "PUT" }),
    softDelete: (id: string) => apiFetch<any>(`/api/admin/patient/${id}/soft-delete`, { method: "PUT" }),
    restore: (id: string) => apiFetch<any>(`/api/admin/patient/${id}/restore`, { method: "PUT" }),
    hardDelete: (id: string) => apiFetch<any>(`/api/admin/patient/${id}`, { method: "DELETE" }),
  },
  stats: () => apiFetch<any>("/api/admin/stats"),
};
