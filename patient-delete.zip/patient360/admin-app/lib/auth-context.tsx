"use client";
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { adminApi } from "./api";

interface Admin { adminId: string; name: string; email: string; }
interface AuthCtx { admin: Admin | null; login: (e: string, p: string) => Promise<void>; logout: () => void; }
const AuthContext = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<Admin | null>(null);
  useEffect(() => { const a = localStorage.getItem("p360_admin"); if (a) setAdmin(JSON.parse(a)); }, []);

  async function login(email: string, password: string) {
    const res = await adminApi.auth.login(email, password);
    localStorage.setItem("p360_admin_token", res.token);
    localStorage.setItem("p360_admin", JSON.stringify(res.admin));
    setAdmin(res.admin);
  }

  function logout() { localStorage.removeItem("p360_admin_token"); localStorage.removeItem("p360_admin"); setAdmin(null); }
  return <AuthContext.Provider value={{ admin, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth outside provider");
  return ctx;
}
