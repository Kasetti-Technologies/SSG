import { Pool } from "pg";

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL ||
    "postgresql://admin:secret123@localhost:5433/patient360",
});

export async function query<T = any>(text: string, params?: any[]): Promise<T[]> {
  const res = await pool.query(text, params);
  return res.rows as T[];
}

export async function queryOne<T = any>(text: string, params?: any[]): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows[0] ?? null;
}
