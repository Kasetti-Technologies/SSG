import "dotenv/config";
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth";
import patientRoutes from "./routes/patient";
import adminRoutes from "./routes/admin";

const app = express();
const PORT = process.env.PORT || 4001;

app.use(cors({ origin: ["http://localhost:3010", "http://localhost:3011"], credentials: true }));
app.use(express.json());

app.get("/health", (_req, res) => res.json({ status: "ok", timestamp: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api/patient", patientRoutes);
app.use("/api/admin", adminRoutes);

app.listen(PORT, () => {
  console.log(`\n🏥 Patient 360 Backend running on http://localhost:${PORT}`);
});

export default app;
