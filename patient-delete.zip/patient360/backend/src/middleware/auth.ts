import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "patient360_secret";

export interface AuthRequest extends Request {
  upiId?: string;
  adminId?: string;
  role?: "patient" | "admin";
}

export function patientAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) { res.status(401).json({ error: "Unauthorized" }); return; }
  try {
    const payload = jwt.verify(token, JWT_SECRET) as any;
    if (payload.role !== "patient") { res.status(403).json({ error: "Forbidden" }); return; }
    req.upiId = payload.upiId;
    req.role = "patient";
    next();
  } catch { res.status(401).json({ error: "Invalid token" }); }
}

export function adminAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) { res.status(401).json({ error: "Unauthorized" }); return; }
  try {
    const payload = jwt.verify(token, JWT_SECRET) as any;
    if (payload.role !== "admin") { res.status(403).json({ error: "Forbidden" }); return; }
    req.adminId = payload.adminId;
    req.role = "admin";
    next();
  } catch { res.status(401).json({ error: "Invalid token" }); }
}

export function signPatientToken(upiId: string): string {
  return jwt.sign({ upiId, role: "patient" }, JWT_SECRET, { expiresIn: "7d" });
}

export function signAdminToken(adminId: string): string {
  return jwt.sign({ adminId, role: "admin" }, JWT_SECRET, { expiresIn: "7d" });
}
