import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { query, queryOne } from "../db";
import { adminAuth, AuthRequest } from "../middleware/auth";

const router = Router();

// ─── GET /api/admin/patients — list all (excluding deleted) ─────────────────
router.get("/patients", adminAuth, async (_req, res: Response) => {
  try {
    const patients = await query(`
      SELECT p.upi_id, p.first_name, p.last_name, p.dob, p.gender, p.phone,
             p.status, p.created_at, a.email,
             COUNT(DISTINCT ap.appointment_id) AS appointment_count,
             COUNT(DISTINCT l.lab_id)          AS lab_count,
             COUNT(DISTINCT pr.prescription_id) AS prescription_count
      FROM upi_patient p
      LEFT JOIN upi_patient_auth a   ON a.upi_id = p.upi_id
      LEFT JOIN appointments ap      ON ap.upi_id = p.upi_id
      LEFT JOIN lab_results l        ON l.upi_id  = p.upi_id
      LEFT JOIN prescriptions pr     ON pr.upi_id = p.upi_id
      WHERE p.status != 'DELETED'
      GROUP BY p.upi_id, a.email
      ORDER BY p.created_at DESC
    `);
    res.json(patients);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch patients" });
  }
});

// ─── GET /api/admin/patients/deleted — soft-deleted patients ─────────────────
router.get("/patients/deleted", adminAuth, async (_req, res: Response) => {
  try {
    const patients = await query(`
      SELECT p.*, a.email
      FROM upi_patient p
      LEFT JOIN upi_patient_auth a ON a.upi_id = p.upi_id
      WHERE p.status = 'DELETED'
      ORDER BY p.deleted_at DESC
    `);
    res.json(patients);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/admin/patient/:upi_id — Patient 360 view ──────────────────────
router.get("/patient/:upi_id", adminAuth, async (req: Request, res: Response) => {
  try {
    const { upi_id } = req.params;

    const patient = await queryOne(`
      SELECT p.*, a.email, a.last_login
      FROM upi_patient p
      LEFT JOIN upi_patient_auth a ON a.upi_id = p.upi_id
      WHERE p.upi_id = $1
    `, [upi_id]);

    if (!patient) { res.status(404).json({ error: "Patient not found" }); return; }

    const [appointments, labResults, prescriptions] = await Promise.all([
      query("SELECT * FROM appointments WHERE upi_id = $1 ORDER BY appointment_date DESC", [upi_id]),
      query("SELECT * FROM lab_results WHERE upi_id = $1 ORDER BY result_date DESC", [upi_id]),
      query("SELECT * FROM prescriptions WHERE upi_id = $1 ORDER BY prescribed_date DESC", [upi_id]),
    ]);

    res.json({ ...patient, appointments, labResults, prescriptions });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch patient" });
  }
});

// ─── POST /api/admin/patient — create new patient ───────────────────────────
router.post("/patient", adminAuth, async (req: Request, res: Response) => {
  try {
    const { upi_id, aadhaar_no, first_name, last_name, dob, gender, phone, address, email, password } = req.body;

    if (!upi_id || !first_name || !last_name || !email || !password) {
      res.status(400).json({ error: "upi_id, first_name, last_name, email, password required" });
      return;
    }

    // Check if UPI ID already exists
    const existing = await queryOne("SELECT upi_id FROM upi_patient WHERE upi_id = $1", [upi_id]);
    if (existing) { res.status(409).json({ error: "UPI ID already exists" }); return; }

    const hash = await bcrypt.hash(password, 10);

    await query(
      `INSERT INTO upi_patient (upi_id, aadhaar_no, first_name, last_name, dob, gender, phone, address)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [upi_id, aadhaar_no || null, first_name, last_name, dob || null, gender || null, phone || null, address || null]
    );

    await query(
      "INSERT INTO upi_patient_auth (upi_id, email, password_hash) VALUES ($1, $2, $3)",
      [upi_id, email, hash]
    );

    res.status(201).json({ message: "Patient created", upi_id });
  } catch (err: any) {
    console.error(err);
    if (err.code === "23505") { res.status(409).json({ error: "Email already exists" }); return; }
    res.status(500).json({ error: "Failed to create patient" });
  }
});

// ─── PUT /api/admin/patient/:upi_id — update profile ────────────────────────
router.put("/patient/:upi_id", adminAuth, async (req: Request, res: Response) => {
  try {
    const { upi_id } = req.params;
    const { first_name, last_name, dob, gender, phone, address, aadhaar_no } = req.body;

    await query(
      `UPDATE upi_patient SET
         first_name = COALESCE($1, first_name),
         last_name  = COALESCE($2, last_name),
         dob        = COALESCE($3, dob),
         gender     = COALESCE($4, gender),
         phone      = COALESCE($5, phone),
         address    = COALESCE($6, address),
         aadhaar_no = COALESCE($7, aadhaar_no),
         updated_at = NOW()
       WHERE upi_id = $8`,
      [first_name, last_name, dob, gender, phone, address, aadhaar_no, upi_id]
    );

    res.json({ message: "Patient updated" });
  } catch {
    res.status(500).json({ error: "Failed to update patient" });
  }
});

// ─── PUT /api/admin/patient/:upi_id/activate ────────────────────────────────
router.put("/patient/:upi_id/activate", adminAuth, async (req: Request, res: Response) => {
  try {
    await query(
      "UPDATE upi_patient SET status = 'ACTIVE', updated_at = NOW() WHERE upi_id = $1",
      [req.params.upi_id]
    );
    res.json({ message: "Patient activated" });
  } catch { res.status(500).json({ error: "Failed" }); }
});

// ─── PUT /api/admin/patient/:upi_id/deactivate ──────────────────────────────
router.put("/patient/:upi_id/deactivate", adminAuth, async (req: Request, res: Response) => {
  try {
    await query(
      "UPDATE upi_patient SET status = 'INACTIVE', updated_at = NOW() WHERE upi_id = $1",
      [req.params.upi_id]
    );
    res.json({ message: "Patient deactivated" });
  } catch { res.status(500).json({ error: "Failed" }); }
});

// ─── PUT /api/admin/patient/:upi_id/soft-delete ─────────────────────────────
router.put("/patient/:upi_id/soft-delete", adminAuth, async (req: Request, res: Response) => {
  try {
    await query(
      "UPDATE upi_patient SET status = 'DELETED', deleted_at = NOW(), updated_at = NOW() WHERE upi_id = $1",
      [req.params.upi_id]
    );
    res.json({ message: "Patient soft deleted — can be restored" });
  } catch { res.status(500).json({ error: "Failed" }); }
});

// ─── PUT /api/admin/patient/:upi_id/restore ─────────────────────────────────
router.put("/patient/:upi_id/restore", adminAuth, async (req: Request, res: Response) => {
  try {
    await query(
      "UPDATE upi_patient SET status = 'INACTIVE', deleted_at = NULL, updated_at = NOW() WHERE upi_id = $1 AND status = 'DELETED'",
      [req.params.upi_id]
    );
    res.json({ message: "Patient restored to INACTIVE" });
  } catch { res.status(500).json({ error: "Failed" }); }
});

// ─── DELETE /api/admin/patient/:upi_id — hard delete ────────────────────────
router.delete("/patient/:upi_id", adminAuth, async (req: Request, res: Response) => {
  try {
    // CASCADE removes all appointments, labs, prescriptions, auth
    await query("DELETE FROM upi_patient WHERE upi_id = $1", [req.params.upi_id]);
    res.json({ message: "Patient permanently deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete patient" });
  }
});

// ─── Stats ────────────────────────────────────────────────────────────────────
router.get("/stats", adminAuth, async (_req, res: Response) => {
  try {
    const [total] = await query<{ count: string }>("SELECT COUNT(*) FROM upi_patient WHERE status != 'DELETED'");
    const [active] = await query<{ count: string }>("SELECT COUNT(*) FROM upi_patient WHERE status = 'ACTIVE'");
    const [inactive] = await query<{ count: string }>("SELECT COUNT(*) FROM upi_patient WHERE status = 'INACTIVE'");
    const [deleted] = await query<{ count: string }>("SELECT COUNT(*) FROM upi_patient WHERE status = 'DELETED'");
    const [appointments] = await query<{ count: string }>("SELECT COUNT(*) FROM appointments");
    const [labs] = await query<{ count: string }>("SELECT COUNT(*) FROM lab_results");

    res.json({
      totalPatients: parseInt(total.count),
      activePatients: parseInt(active.count),
      inactivePatients: parseInt(inactive.count),
      deletedPatients: parseInt(deleted.count),
      totalAppointments: parseInt(appointments.count),
      totalLabResults: parseInt(labs.count),
    });
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

export default router;
