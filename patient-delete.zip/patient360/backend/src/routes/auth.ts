import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { queryOne, query } from "../db";
import { signPatientToken, signAdminToken } from "../middleware/auth";

const router = Router();

// POST /api/auth/patient/login
router.post("/patient/login", async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Email and password required" });
      return;
    }

    // Get auth record
    const auth = await queryOne<{ upi_id: string; password_hash: string }>(
      "SELECT * FROM upi_patient_auth WHERE email = $1", [email]
    );
    if (!auth) { res.status(401).json({ error: "Invalid credentials" }); return; }

    // Check password
    const valid = await bcrypt.compare(password, auth.password_hash);
    if (!valid) { res.status(401).json({ error: "Invalid credentials" }); return; }

    // Check patient status
    const patient = await queryOne<{ upi_id: string; first_name: string; last_name: string; status: string }>(
      "SELECT upi_id, first_name, last_name, status FROM upi_patient WHERE upi_id = $1",
      [auth.upi_id]
    );
    if (!patient) { res.status(401).json({ error: "Patient not found" }); return; }

    if (patient.status === "INACTIVE") {
      res.status(403).json({ error: "Your account is inactive. Please contact administrator." });
      return;
    }
    if (patient.status === "DELETED") {
      res.status(403).json({ error: "Account not found. Please contact administrator." });
      return;
    }

    // Update last login
    await query("UPDATE upi_patient_auth SET last_login = NOW() WHERE upi_id = $1", [auth.upi_id]);

    const token = signPatientToken(patient.upi_id);
    res.json({
      token,
      patient: { upiId: patient.upi_id, name: `${patient.first_name} ${patient.last_name}`, status: patient.status }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

// POST /api/auth/admin/login
router.post("/admin/login", async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      res.status(400).json({ error: "Email and password required" });
      return;
    }

    const admin = await queryOne<{ admin_id: string; name: string; email: string; password_hash: string }>(
      "SELECT * FROM admins WHERE email = $1", [email]
    );
    if (!admin) { res.status(401).json({ error: "Invalid credentials" }); return; }

    const valid = await bcrypt.compare(password, admin.password_hash);
    if (!valid) { res.status(401).json({ error: "Invalid credentials" }); return; }

    const token = signAdminToken(admin.admin_id);
    res.json({
      token,
      admin: { adminId: admin.admin_id, name: admin.name, email: admin.email }
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

export default router;
