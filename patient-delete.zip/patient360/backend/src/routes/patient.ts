import { Router, Response } from "express";
import { query, queryOne } from "../db";
import { patientAuth, AuthRequest } from "../middleware/auth";

const router = Router();

// GET /api/patient/:upi_id — Patient 360 view (own data only)
router.get("/:upi_id", patientAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { upi_id } = req.params;

    // Patient can only see their own data
    if (req.upiId !== upi_id) {
      res.status(403).json({ error: "Access denied" });
      return;
    }

    const patient = await queryOne(
      "SELECT upi_id, first_name, last_name, dob, gender, phone, address, aadhaar_no, status, created_at FROM upi_patient WHERE upi_id = $1 AND status != 'DELETED'",
      [upi_id]
    );
    if (!patient) { res.status(404).json({ error: "Patient not found" }); return; }

    const [appointments, labResults, prescriptions, auth] = await Promise.all([
      query("SELECT * FROM appointments WHERE upi_id = $1 ORDER BY appointment_date DESC", [upi_id]),
      query("SELECT * FROM lab_results WHERE upi_id = $1 ORDER BY result_date DESC", [upi_id]),
      query("SELECT * FROM prescriptions WHERE upi_id = $1 ORDER BY prescribed_date DESC", [upi_id]),
      queryOne<{ email: string; last_login: string }>("SELECT email, last_login FROM upi_patient_auth WHERE upi_id = $1", [upi_id]),
    ]);

    res.json({ ...patient, email: auth?.email, lastLogin: auth?.last_login, appointments, labResults, prescriptions });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch patient data" });
  }
});

// GET /api/patient/:upi_id/appointments
router.get("/:upi_id/appointments", patientAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (req.upiId !== req.params.upi_id) { res.status(403).json({ error: "Access denied" }); return; }
    const rows = await query("SELECT * FROM appointments WHERE upi_id = $1 ORDER BY appointment_date DESC", [req.params.upi_id]);
    res.json(rows);
  } catch { res.status(500).json({ error: "Failed" }); }
});

// GET /api/patient/:upi_id/labs
router.get("/:upi_id/labs", patientAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (req.upiId !== req.params.upi_id) { res.status(403).json({ error: "Access denied" }); return; }
    const rows = await query("SELECT * FROM lab_results WHERE upi_id = $1 ORDER BY result_date DESC", [req.params.upi_id]);
    res.json(rows);
  } catch { res.status(500).json({ error: "Failed" }); }
});

// GET /api/patient/:upi_id/prescriptions
router.get("/:upi_id/prescriptions", patientAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (req.upiId !== req.params.upi_id) { res.status(403).json({ error: "Access denied" }); return; }
    const rows = await query("SELECT * FROM prescriptions WHERE upi_id = $1 ORDER BY prescribed_date DESC", [req.params.upi_id]);
    res.json(rows);
  } catch { res.status(500).json({ error: "Failed" }); }
});

export default router;
