-- ─────────────────────────────────────────────────────────────────
--  Patient 360 — PostgreSQL Schema
-- ─────────────────────────────────────────────────────────────────

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── UpiPatient ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS upi_patient (
  upi_id       VARCHAR(50)  PRIMARY KEY,
  aadhaar_no   VARCHAR(20),
  first_name   VARCHAR(100) NOT NULL,
  last_name    VARCHAR(100) NOT NULL,
  dob          DATE,
  gender       VARCHAR(20),
  phone        VARCHAR(20),
  address      TEXT,
  status       VARCHAR(20)  DEFAULT 'ACTIVE',
  deleted_at   TIMESTAMP    NULL,
  created_at   TIMESTAMPTZ  DEFAULT NOW(),
  updated_at   TIMESTAMPTZ  DEFAULT NOW()
);

-- ─── Patient Auth ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS upi_patient_auth (
  upi_id        VARCHAR(50)  PRIMARY KEY REFERENCES upi_patient(upi_id) ON DELETE CASCADE,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  last_login    TIMESTAMPTZ  NULL
);

-- ─── Admins ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
  admin_id      UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at    TIMESTAMPTZ  DEFAULT NOW()
);

-- ─── Appointments ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS appointments (
  appointment_id UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
  upi_id         VARCHAR(50)  REFERENCES upi_patient(upi_id) ON DELETE CASCADE,
  doctor_name    VARCHAR(255) NOT NULL,
  department     VARCHAR(100),
  appointment_date TIMESTAMPTZ NOT NULL,
  status         VARCHAR(20)  DEFAULT 'SCHEDULED',
  notes          TEXT,
  created_at     TIMESTAMPTZ  DEFAULT NOW()
);

-- ─── Lab Results ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS lab_results (
  lab_id       UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
  upi_id       VARCHAR(50)  REFERENCES upi_patient(upi_id) ON DELETE CASCADE,
  test_name    VARCHAR(255) NOT NULL,
  result       TEXT,
  result_date  TIMESTAMPTZ  NOT NULL,
  lab_name     VARCHAR(255),
  normal_range VARCHAR(100),
  status       VARCHAR(20)  DEFAULT 'NORMAL',
  created_at   TIMESTAMPTZ  DEFAULT NOW()
);

-- ─── Prescriptions ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS prescriptions (
  prescription_id UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
  upi_id          VARCHAR(50)  REFERENCES upi_patient(upi_id) ON DELETE CASCADE,
  medicine        VARCHAR(255) NOT NULL,
  dosage          VARCHAR(100),
  doctor          VARCHAR(255),
  duration        VARCHAR(100),
  instructions    TEXT,
  prescribed_date TIMESTAMPTZ  DEFAULT NOW(),
  created_at      TIMESTAMPTZ  DEFAULT NOW()
);

-- ─── Seed: Default Admin ──────────────────────────────────────────
-- password: admin123 (bcrypt hash)
INSERT INTO admins (name, email, password_hash) VALUES
  ('Super Admin', 'admin@patient360.com', '$2a$10$ylB4Mk5PkxQl9m2hsBnVY.Ag4HjN8l0bCO9od.GlA.VIjnYm1M4Bq')
ON CONFLICT (email) DO NOTHING;

-- ─── Seed: Sample Patients ────────────────────────────────────────
INSERT INTO upi_patient (upi_id, aadhaar_no, first_name, last_name, dob, gender, phone, status) VALUES
  ('UPI001', '1234-5678-9012', 'Rahul',  'Sharma', '1990-05-15', 'Male',   '9876543210', 'ACTIVE'),
  ('UPI002', '2345-6789-0123', 'Priya',  'Patel',  '1985-08-22', 'Female', '9876543211', 'ACTIVE'),
  ('UPI003', '3456-7890-1234', 'Arjun',  'Kumar',  '1995-03-10', 'Male',   '9876543212', 'INACTIVE'),
  ('UPI004', '4567-8901-2345', 'Sneha',  'Reddy',  '1992-11-30', 'Female', '9876543213', 'ACTIVE')
ON CONFLICT (upi_id) DO NOTHING;

-- password: patient123 (bcrypt hash)
INSERT INTO upi_patient_auth (upi_id, email, password_hash) VALUES
  ('UPI001', 'rahul@example.com',  '$2a$10$ylB4Mk5PkxQl9m2hsBnVY.Ag4HjN8l0bCO9od.GlA.VIjnYm1M4Bq'),
  ('UPI002', 'priya@example.com',  '$2a$10$ylB4Mk5PkxQl9m2hsBnVY.Ag4HjN8l0bCO9od.GlA.VIjnYm1M4Bq'),
  ('UPI003', 'arjun@example.com',  '$2a$10$ylB4Mk5PkxQl9m2hsBnVY.Ag4HjN8l0bCO9od.GlA.VIjnYm1M4Bq'),
  ('UPI004', 'sneha@example.com',  '$2a$10$ylB4Mk5PkxQl9m2hsBnVY.Ag4HjN8l0bCO9od.GlA.VIjnYm1M4Bq')
ON CONFLICT (upi_id) DO NOTHING;

-- ─── Seed: Sample Appointments ───────────────────────────────────
INSERT INTO appointments (upi_id, doctor_name, department, appointment_date, status, notes) VALUES
  ('UPI001', 'Dr. Rajesh Kumar',  'Cardiology',   '2026-05-01 10:00:00+05:30', 'COMPLETED', 'Regular checkup'),
  ('UPI001', 'Dr. Meena Singh',   'Neurology',    '2026-04-15 11:30:00+05:30', 'COMPLETED', 'Follow-up'),
  ('UPI001', 'Dr. Rajesh Kumar',  'Cardiology',   '2026-06-10 10:00:00+05:30', 'SCHEDULED', 'Monthly review'),
  ('UPI002', 'Dr. Anita Sharma',  'Orthopedics',  '2026-05-20 09:00:00+05:30', 'COMPLETED', 'Knee pain'),
  ('UPI002', 'Dr. Anita Sharma',  'Orthopedics',  '2026-06-20 09:00:00+05:30', 'SCHEDULED', 'Follow-up'),
  ('UPI004', 'Dr. Vikram Nair',   'General',      '2026-05-25 14:00:00+05:30', 'COMPLETED', 'Annual checkup')
ON CONFLICT DO NOTHING;

-- ─── Seed: Sample Lab Results ────────────────────────────────────
INSERT INTO lab_results (upi_id, test_name, result, result_date, lab_name, normal_range, status) VALUES
  ('UPI001', 'Complete Blood Count', 'Normal', '2026-04-20 08:00:00+05:30', 'Apollo Labs', 'WBC: 4-11 K/uL', 'NORMAL'),
  ('UPI001', 'Lipid Profile',        'LDL slightly elevated', '2026-03-10 08:00:00+05:30', 'Apollo Labs', 'LDL < 100 mg/dL', 'ABNORMAL'),
  ('UPI002', 'X-Ray Left Knee',      'Mild arthritis', '2026-05-20 10:00:00+05:30', 'City Diagnostics', 'Normal', 'ABNORMAL'),
  ('UPI004', 'Blood Sugar Fasting',  '95 mg/dL', '2026-05-25 07:00:00+05:30', 'Apollo Labs', '70-100 mg/dL', 'NORMAL')
ON CONFLICT DO NOTHING;

-- ─── Seed: Sample Prescriptions ─────────────────────────────────
INSERT INTO prescriptions (upi_id, medicine, dosage, doctor, duration, instructions) VALUES
  ('UPI001', 'Atorvastatin', '10mg', 'Dr. Rajesh Kumar', '3 months', 'Take at night after food'),
  ('UPI001', 'Aspirin',      '75mg', 'Dr. Rajesh Kumar', '3 months', 'Take in morning after breakfast'),
  ('UPI002', 'Diclofenac',   '50mg', 'Dr. Anita Sharma', '2 weeks',  'Take twice daily after food'),
  ('UPI002', 'Calcium + D3', '500mg','Dr. Anita Sharma', '3 months', 'Take once daily'),
  ('UPI004', 'Multivitamin', '1 tab','Dr. Vikram Nair',  '1 month',  'Take in morning')
ON CONFLICT DO NOTHING;
