"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";

const S = {
  page: { minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora',sans-serif" } as React.CSSProperties,
  card: { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 24, marginBottom: 20 } as React.CSSProperties,
  badge: (color: string) => ({ background: `${color}22`, color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999, border: `1px solid ${color}44` } as React.CSSProperties),
  th: { color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "10px 14px", textTransform: "uppercase", letterSpacing: "0.08em" } as React.CSSProperties,
  td: { color: "#cbd5e1", fontSize: 13, padding: "12px 14px", borderTop: "1px solid rgba(255,255,255,0.05)" } as React.CSSProperties,
};

export default function Dashboard() {
  const { user, logout } = useAuth();
  const router = useRouter();
  const [data, setData] = useState<any>(null);
  const [tab, setTab] = useState("overview");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.push("/"); return; }
    api.patient.get360(user.upiId).then(setData).catch(console.error).finally(() => setLoading(false));
  }, [user]);

  if (loading) return <div style={{ ...S.page, display: "flex", alignItems: "center", justifyContent: "center", color: "#2dd4bf", fontSize: 18 }}>Loading…</div>;
  if (!data) return null;

  const statusColor: Record<string, string> = { ACTIVE: "#2dd4bf", INACTIVE: "#f59e0b", SCHEDULED: "#60a5fa", COMPLETED: "#4ade80", CANCELLED: "#f87171", NORMAL: "#4ade80", ABNORMAL: "#f87171" };

  const tabs = ["overview", "appointments", "labs", "prescriptions"];

  return (
    <div style={S.page}>
      {/* Navbar */}
      <nav style={{ background: "rgba(15,23,42,0.95)", borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "0 24px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 22 }}>🏥</span>
          <span style={{ color: "#2dd4bf", fontWeight: 800, fontSize: 18 }}>Patient 360</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <span style={{ color: "#475569", fontSize: 14 }}>{user?.name}</span>
          <button onClick={() => { logout(); router.push("/"); }} style={{ padding: "6px 14px", borderRadius: 8, background: "transparent", border: "1px solid rgba(239,68,68,0.3)", color: "#f87171", fontSize: 13, cursor: "pointer" }}>Logout</button>
        </div>
      </nav>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "32px 24px" }}>
        {/* Profile Card */}
        <div style={{ background: "linear-gradient(135deg,#0d9488,#0891b2)", borderRadius: 24, padding: "28px 32px", marginBottom: 24, position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", top: -40, right: -40, width: 180, height: 180, background: "rgba(255,255,255,0.07)", borderRadius: "50%" }} />
          <div style={{ position: "relative" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 16 }}>
              <div style={{ width: 56, height: 56, borderRadius: "50%", background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, fontWeight: 800, color: "#fff" }}>
                {data.first_name?.charAt(0)}
              </div>
              <div>
                <div style={{ color: "#fff", fontSize: 22, fontWeight: 800 }}>{data.first_name} {data.last_name}</div>
                <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 14, marginTop: 2 }}>UPI ID: {data.upi_id}</div>
              </div>
            </div>
            <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
              {[
                { label: "DOB", value: data.dob ? new Date(data.dob).toLocaleDateString("en-IN") : "—" },
                { label: "Gender", value: data.gender || "—" },
                { label: "Phone", value: data.phone || "—" },
                { label: "Email", value: data.email || "—" },
              ].map(({ label, value }) => (
                <div key={label}>
                  <div style={{ color: "rgba(255,255,255,0.5)", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>{label}</div>
                  <div style={{ color: "#fff", fontSize: 14, marginTop: 2 }}>{value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
          {tabs.map(t => (
            <button key={t} onClick={() => setTab(t)}
              style={{ padding: "8px 18px", borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: "pointer", border: "1px solid", transition: "all 0.15s", textTransform: "capitalize",
                background: tab === t ? "linear-gradient(135deg,#0d9488,#0891b2)" : "rgba(255,255,255,0.04)",
                borderColor: tab === t ? "transparent" : "rgba(255,255,255,0.1)",
                color: tab === t ? "#fff" : "#64748b" }}>
              {t} {t === "appointments" ? `(${data.appointments?.length || 0})` : t === "labs" ? `(${data.labResults?.length || 0})` : t === "prescriptions" ? `(${data.prescriptions?.length || 0})` : ""}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === "overview" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16 }}>
            {[
              { label: "Appointments", count: data.appointments?.length || 0, icon: "📅", color: "#60a5fa" },
              { label: "Lab Results", count: data.labResults?.length || 0, icon: "🧪", color: "#2dd4bf" },
              { label: "Prescriptions", count: data.prescriptions?.length || 0, icon: "💊", color: "#a78bfa" },
              { label: "Account Status", count: data.status, icon: "✅", color: "#4ade80" },
            ].map(({ label, count, icon, color }) => (
              <div key={label} style={{ ...S.card, marginBottom: 0 }}>
                <div style={{ fontSize: 28, marginBottom: 10 }}>{icon}</div>
                <div style={{ color, fontSize: 26, fontWeight: 800 }}>{count}</div>
                <div style={{ color: "#475569", fontSize: 13, marginTop: 4 }}>{label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Appointments */}
        {tab === "appointments" && (
          <div style={S.card}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr>
                {["Doctor", "Department", "Date", "Status", "Notes"].map(h => <th key={h} style={S.th}>{h}</th>)}
              </tr></thead>
              <tbody>
                {data.appointments?.length === 0 ? (
                  <tr><td colSpan={5} style={{ ...S.td, textAlign: "center", padding: 40, color: "#334155" }}>No appointments found</td></tr>
                ) : data.appointments?.map((a: any) => (
                  <tr key={a.appointment_id}>
                    <td style={{ ...S.td, fontWeight: 600, color: "#e2e8f0" }}>{a.doctor_name}</td>
                    <td style={S.td}>{a.department || "—"}</td>
                    <td style={S.td}>{new Date(a.appointment_date).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</td>
                    <td style={S.td}><span style={badge(statusColor[a.status] || "#94a3b8")}>{a.status}</span></td>
                    <td style={S.td}>{a.notes || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Lab Results */}
        {tab === "labs" && (
          <div style={S.card}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr>
                {["Test Name", "Result", "Date", "Lab", "Status"].map(h => <th key={h} style={S.th}>{h}</th>)}
              </tr></thead>
              <tbody>
                {data.labResults?.length === 0 ? (
                  <tr><td colSpan={5} style={{ ...S.td, textAlign: "center", padding: 40, color: "#334155" }}>No lab results found</td></tr>
                ) : data.labResults?.map((l: any) => (
                  <tr key={l.lab_id}>
                    <td style={{ ...S.td, fontWeight: 600, color: "#e2e8f0" }}>{l.test_name}</td>
                    <td style={S.td}>{l.result}</td>
                    <td style={S.td}>{new Date(l.result_date).toLocaleDateString("en-IN")}</td>
                    <td style={S.td}>{l.lab_name || "—"}</td>
                    <td style={S.td}><span style={badge(statusColor[l.status] || "#94a3b8")}>{l.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Prescriptions */}
        {tab === "prescriptions" && (
          <div style={S.card}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr>
                {["Medicine", "Dosage", "Doctor", "Duration", "Instructions"].map(h => <th key={h} style={S.th}>{h}</th>)}
              </tr></thead>
              <tbody>
                {data.prescriptions?.length === 0 ? (
                  <tr><td colSpan={5} style={{ ...S.td, textAlign: "center", padding: 40, color: "#334155" }}>No prescriptions found</td></tr>
                ) : data.prescriptions?.map((p: any) => (
                  <tr key={p.prescription_id}>
                    <td style={{ ...S.td, fontWeight: 600, color: "#e2e8f0" }}>{p.medicine}</td>
                    <td style={S.td}>{p.dosage}</td>
                    <td style={S.td}>{p.doctor}</td>
                    <td style={S.td}>{p.duration || "—"}</td>
                    <td style={S.td}>{p.instructions || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function badge(color: string) {
  return { background: `${color}22`, color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999, border: `1px solid ${color}44` } as React.CSSProperties;
}
