const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4001";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("p360_token");
}

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Request failed" }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

export const api = {
  auth: {
    login: (email: string, password: string) =>
      apiFetch<{ token: string; patient: any }>("/api/auth/patient/login", {
        method: "POST", body: JSON.stringify({ email, password }),
      }),
  },
  patient: {
    get360: (upiId: string) => apiFetch<any>(`/api/patient/${upiId}`),
    getAppointments: (upiId: string) => apiFetch<any[]>(`/api/patient/${upiId}/appointments`),
    getLabs: (upiId: string) => apiFetch<any[]>(`/api/patient/${upiId}/labs`),
    getPrescriptions: (upiId: string) => apiFetch<any[]>(`/api/patient/${upiId}/prescriptions`),
  },
};
