"use client";
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { api } from "./api";

interface PatientUser { upiId: string; name: string; status: string; }
interface AuthCtx {
  user: PatientUser | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<PatientUser | null>(null);

  useEffect(() => {
    const u = localStorage.getItem("p360_user");
    if (u) setUser(JSON.parse(u));
  }, []);

  async function login(email: string, password: string) {
    const res = await api.auth.login(email, password);
    localStorage.setItem("p360_token", res.token);
    localStorage.setItem("p360_user", JSON.stringify(res.patient));
    setUser(res.patient);
  }

  function logout() {
    localStorage.removeItem("p360_token");
    localStorage.removeItem("p360_user");
    setUser(null);
  }

  return <AuthContext.Provider value={{ user, login, logout }}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be inside AuthProvider");
  return ctx;
}
