#!/bin/bash
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   🏥 Patient 360 — Startup               ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

command -v docker >/dev/null 2>&1 || { echo "❌ Docker not found."; exit 1; }

echo -e "${YELLOW}Starting all services...${NC}"
docker compose up -d --build

echo ""
echo -e "${YELLOW}Waiting for PostgreSQL...${NC}"
until docker exec p360-postgres pg_isready -U admin -d patient360 >/dev/null 2>&1; do
  sleep 2; echo -n ".";
done
echo -e "\n${GREEN}✅ PostgreSQL ready${NC}"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   🎉 Patient 360 is ready!               ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BLUE}👤 Patient App${NC}  →  http://localhost:3010"
echo -e "  ${BLUE}🔐 Admin App${NC}    →  http://localhost:3011"
echo -e "  ${BLUE}🔌 Backend API${NC}  →  http://localhost:4001/health"
echo ""
echo -e "  ${YELLOW}Patient login:${NC}  rahul@example.com / password123"
echo -e "  ${YELLOW}Admin login:${NC}    admin@patient360.com / password123"
echo ""
echo -e "${YELLOW}To stop:   docker compose down${NC}"
echo -e "${YELLOW}To reset:  docker compose down -v && ./start.sh${NC}"
echo ""
