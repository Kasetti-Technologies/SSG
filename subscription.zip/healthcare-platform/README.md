# 🏥 HealthCare+ Subscription Platform

A full-stack healthcare subscription platform demo with real external services — Kill Bill for subscription lifecycle, Odoo ERP for pricing, Razorpay (demo mode) for payments, and PostgreSQL as the core database.

---

## 📐 Architecture

```
┌──────────────────┐    ┌──────────────────┐
│   User App       │    │   Admin App      │
│   :3000          │    │   :3002          │
│   (Next.js)      │    │   (Next.js)      │
└────────┬─────────┘    └────────┬─────────┘
         │                       │
         └───────────┬───────────┘
                     ▼
         ┌───────────────────────┐
         │   Backend API         │
         │   :3001 (Node.js/TS)  │
         └──────┬──────┬─────────┘
                │      │
       ┌────────▼┐  ┌──▼──────────┐
       │  Odoo   │  │  Kill Bill  │
       │  :8069  │  │  :8080      │
       └─────────┘  └──────┬──────┘
                           │
                    ┌──────▼──────┐
                    │  Razorpay   │
                    │  (demo)     │
                    └─────────────┘
       ┌─────────────────────────┐
       │   PostgreSQL :5432      │
       │  (users, entitlements,  │
       │   bookings, packages)   │
       └─────────────────────────┘
```

### Service Responsibilities

| Service      | Port  | Responsibility                                      |
|-------------|-------|-----------------------------------------------------|
| User App    | 3000  | Patient-facing: browse services, subscribe, book    |
| Admin App   | 3002  | Manage services, packages, view users & bookings    |
| Backend     | 3001  | Business logic, entitlements, API gateway           |
| PostgreSQL  | 5432  | Core operational data                               |
| Kill Bill   | 8080  | Subscription lifecycle, invoices, renewals          |
| KAUI        | 9090  | Kill Bill admin UI                                  |
| Odoo        | 8069  | Service pricing master, ERP/accounting              |

---

## 🚀 Quick Start

### Prerequisites

- **Docker Desktop** — [download](https://www.docker.com/products/docker-desktop/)
- **Node.js 18+** — [download](https://nodejs.org/)
- At least **6 GB RAM** for Docker (Kill Bill + Odoo are heavy)

### Run Everything

```bash
# Clone / unzip the project
cd healthcare-platform

# One command to start everything
./start.sh
```

That's it. The script will:
1. Start all Docker services (Kill Bill, Odoo, PostgreSQL, Backend, User App, Admin App)
2. Wait for services to be healthy
3. Auto-configure Kill Bill (create tenant, upload catalog with Silver/Gold/Platinum plans)

**First startup takes ~3–5 minutes** — Kill Bill and Odoo need time to initialize.

---

## 🌐 Access URLs

| App              | URL                           | Credentials         |
|-----------------|-------------------------------|---------------------|
| User App        | http://localhost:3000         | Register a new account |
| Admin App       | http://localhost:3002         | No auth (demo)      |
| Backend API     | http://localhost:3001/health  | —                   |
| Kill Bill KAUI  | http://localhost:9090         | admin / password    |
| Odoo ERP        | http://localhost:8069         | admin / admin       |
| Kill Bill API   | http://localhost:8080/api.html| swagger docs        |

---

## 🎬 Demo Flow (Full End-to-End)

### As a Patient (User App — :3000)

1. **Register** → creates account in PostgreSQL + Kill Bill account
2. **Browse Services** → see all diagnostics with pricing from DB
3. **View Plans** → Silver / Gold / Platinum subscription options
4. **Subscribe to Gold Plan** → simulates Razorpay payment → activates Kill Bill subscription → grants entitlements
5. **Go to Services** → MRI Brain now shows "FREE — 2 uses left"
6. **Book MRI Brain** → entitlement decremented (2 → 1)
7. **Book again** → (1 → 0)
8. **Try booking again** → out of entitlements, prompts to pay ₹2000
9. **My Bookings** → full history showing covered vs paid

### As an Admin (Admin App — :3002)

1. **Dashboard** → stats (users, active subs, bookings, revenue) + system status
2. **Services** → edit any service price (reflects immediately for new bookings)
3. **Packages** → create a new package with custom services & quantities → auto-registers in Kill Bill
4. **Users** → see all patients with their active plan
5. **Bookings** → all bookings with covered vs paid breakdown

### Kill Bill (KAUI — :9090)

- Login: `admin` / `password`
- See accounts created for each registered user
- See subscriptions and invoices
- Kill Bill's test mode lets you advance dates to trigger renewals

---

## 📊 Database Schema

```sql
users              — patient accounts + kill bill account ID
services           — diagnostic services with pricing (synced from Odoo)
packages           — subscription plans
package_items      — which services + qty are in each plan
subscriptions      — user subscription records + KB subscription ID
entitlements       — per-user remaining usage per service
bookings           — all bookings (plan-covered or pay-per-use)
payments           — payment audit log
```

---

## 🔑 Key Flows Explained

### Flow: User Subscribes (FLOW 4)

```
User clicks Subscribe
  → Backend creates Razorpay order
  → Frontend simulates payment (demo mode)
  → Backend verifies payment signature
  → Backend calls Kill Bill: create subscription
  → Backend inserts entitlements in PostgreSQL
  → User now has X uses of each service
```

### Flow: User Books (FLOW 6 + 7)

```
User clicks "Book MRI Brain"
  → Backend checks entitlements table
  → remaining > 0 → price = ₹0, covered = true
    → Create booking record
    → Decrement entitlement (remaining - 1)
  → remaining = 0 → price = ₹2000 from services table
    → Razorpay order created
    → User pays
    → Booking confirmed
```

### Flow: Price Change (FLOW 11)

```
Admin changes MRI Brain: ₹2000 → ₹2500
  → services table updated
  → Next pay-per-use booking = ₹2500 automatically
  → Plan-covered bookings unaffected
```

---

## 🛠 Development

### Run locally without Docker

```bash
# Start only infrastructure in Docker
docker compose up -d postgres kb-db killbill kaui odoo-db odoo

# Backend
cd backend
npm install
npm run dev      # http://localhost:3001

# User App
cd user-app
npm install
npm run dev      # http://localhost:3000

# Admin App
cd admin-app
npm install
npm run dev      # http://localhost:3002  (Next.js uses port 3000 by default; set PORT=3002)
```

### Environment Variables

Backend `.env` (copy from docker-compose environment):

```env
DATABASE_URL=postgresql://admin:secret123@localhost:5432/healthcare
KILLBILL_URL=http://localhost:8080
KILLBILL_API_KEY=bob
KILLBILL_API_SECRET=lazar
KILLBILL_USERNAME=admin
KILLBILL_PASSWORD=password
ODOO_URL=http://localhost:8069
RAZORPAY_KEY_ID=rzp_test_demo123
RAZORPAY_KEY_SECRET=demo_secret_456
JWT_SECRET=super_secret_jwt_key_change_in_prod
```

---

## 📦 Project Structure

```
healthcare-platform/
├── docker-compose.yml          # All services
├── start.sh                    # One-command startup
├── scripts/
│   └── setup-killbill.js       # KB tenant + catalog setup
├── backend/                    # Node.js TypeScript API
│   ├── src/
│   │   ├── index.ts
│   │   ├── db/index.ts         # PostgreSQL pool
│   │   ├── middleware/auth.ts  # JWT middleware
│   │   ├── routes/
│   │   │   ├── auth.ts         # Register, login
│   │   │   ├── services.ts     # List services
│   │   │   ├── packages.ts     # Subscription plans
│   │   │   ├── subscriptions.ts # Subscribe, activate, cancel
│   │   │   ├── bookings.ts     # Book + entitlement check
│   │   │   └── admin.ts        # Admin endpoints
│   │   └── services/
│   │       ├── killbill.ts     # Kill Bill API client
│   │       ├── odoo.ts         # Odoo pricing sync
│   │       └── razorpay.ts     # Payment helper
│   └── db/init.sql             # Schema + seed data
├── user-app/                   # Patient Next.js app
│   ├── app/
│   │   ├── page.tsx            # Landing
│   │   ├── auth/login/
│   │   ├── auth/register/
│   │   ├── dashboard/
│   │   ├── services/
│   │   ├── plans/
│   │   └── bookings/
│   ├── components/Navbar.tsx
│   └── lib/
│       ├── api.ts
│       └── auth-context.tsx
└── admin-app/                  # Admin Next.js app
    ├── app/
    │   ├── dashboard/
    │   ├── services/
    │   ├── packages/
    │   ├── users/
    │   └── bookings/
    ├── components/Sidebar.tsx
    └── lib/api.ts
```

---

## ⚠️ Notes for Demo

- **Razorpay is in demo/simulation mode** — no real payments occur. Signatures are auto-accepted.
- **Kill Bill is in test mode** (`KB_org_killbill_server_test_mode=true`) — allows date manipulation for testing renewals.
- **Odoo pricing sync** works when Odoo is configured with a "Healthcare Services" product category.
- To reset all data: `docker compose down -v && docker compose up -d`

---

## 🔄 Stopping & Resetting

```bash
# Stop all services (keep data)
docker compose down

# Stop and delete all data (full reset)
docker compose down -v

# View logs
docker compose logs -f backend
docker compose logs -f killbill
```
