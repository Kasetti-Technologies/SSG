"use client";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function BookingsPage() {
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("All");

  useEffect(() => { adminApi.bookings().then(setBookings).finally(() => setLoading(false)); }, []);

  const filtered = filter === "All" ? bookings : filter === "Covered" ? bookings.filter(b => b.covered_by_plan) : bookings.filter(b => !b.covered_by_plan);
  const totalRevenue = bookings.filter(b => !b.covered_by_plan).reduce((s, b) => s + parseFloat(b.amount_paid || 0), 0);
  const coveredCount = bookings.filter(b => b.covered_by_plan).length;

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Bookings</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>All patient bookings</p>
        </div>

        {/* Summary */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 24 }}>
          {[
            { label: "Total Bookings", value: bookings.length, color: "#60a5fa", bg: "rgba(96,165,250,0.1)" },
            { label: "Covered by Plan", value: coveredCount, color: "#2dd4bf", bg: "rgba(45,212,191,0.1)" },
            { label: "Pay-per-use Revenue", value: `₹${totalRevenue.toLocaleString("en-IN")}`, color: "#4ade80", bg: "rgba(74,222,128,0.1)" },
          ].map(({ label, value, color, bg }) => (
            <div key={label} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: "20px 24px" }}>
              <div style={{ color, fontSize: 26, fontWeight: 800, marginBottom: 4 }}>{loading ? "…" : value}</div>
              <div style={{ color: "#475569", fontSize: 13 }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Filter */}
        <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
          {["All", "Covered", "Paid"].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{ padding: "8px 18px", borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: "pointer", border: "1px solid", transition: "all 0.15s",
                background: filter === f ? "linear-gradient(135deg,#0d9488,#0891b2)" : "rgba(255,255,255,0.04)",
                borderColor: filter === f ? "transparent" : "rgba(255,255,255,0.1)",
                color: filter === f ? "#fff" : "#64748b" }}>
              {f}
            </button>
          ))}
        </div>

        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ background: "rgba(255,255,255,0.03)" }}>
              <tr>
                {["Patient", "Service", "Type", "Amount", "Status", "Date"].map(h => (
                  <th key={h} style={{ color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "14px 20px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? <tr><td colSpan={6} style={{ color: "#475569", textAlign: "center", padding: 48 }}>Loading…</td></tr>
              : filtered.length === 0 ? <tr><td colSpan={6} style={{ color: "#334155", textAlign: "center", padding: 48 }}>No bookings yet</td></tr>
              : filtered.map((b: any) => (
                <tr key={b.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                  <td style={{ padding: "14px 20px", color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{b.user_name}</td>
                  <td style={{ padding: "14px 20px", color: "#94a3b8", fontSize: 14 }}>{b.service_name}</td>
                  <td style={{ padding: "14px 20px" }}>
                    {b.covered_by_plan
                      ? <span style={{ background: "rgba(13,148,136,0.2)", color: "#2dd4bf", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>Plan Covered</span>
                      : <span style={{ background: "rgba(96,165,250,0.15)", color: "#60a5fa", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>Pay-per-use</span>}
                  </td>
                  <td style={{ padding: "14px 20px", fontWeight: 700, fontSize: 14, color: b.covered_by_plan ? "#2dd4bf" : "#f1f5f9" }}>
                    {b.covered_by_plan ? "₹0" : `₹${b.amount_paid}`}
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <span style={{ background: "rgba(74,222,128,0.1)", color: "#4ade80", fontSize: 11, fontWeight: 600, padding: "3px 10px", borderRadius: 999 }}>{b.status}</span>
                  </td>
                  <td style={{ padding: "14px 20px", color: "#475569", fontSize: 12 }}>{new Date(b.booked_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
