"use client";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

const S = {
  page: { display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" } as React.CSSProperties,
  main: { flex: 1, padding: "36px 32px", overflow: "auto" } as React.CSSProperties,
  card: { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20 } as React.CSSProperties,
};

export default function AdminDashboard() {
  const [stats, setStats] = useState<any>(null);
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([adminApi.stats(), adminApi.bookings()])
      .then(([s, b]) => { setStats(s); setBookings(b.slice(0, 8)); })
      .finally(() => setLoading(false));
  }, []);

  const statCards = [
    { label: "Total Users", value: stats?.totalUsers ?? "—", icon: "👥", color: "#60a5fa", bg: "rgba(96,165,250,0.1)" },
    { label: "Active Subscriptions", value: stats?.activeSubscriptions ?? "—", icon: "✅", color: "#2dd4bf", bg: "rgba(45,212,191,0.1)" },
    { label: "Total Bookings", value: stats?.totalBookings ?? "—", icon: "📅", color: "#f59e0b", bg: "rgba(245,158,11,0.1)" },
    { label: "Revenue (INR)", value: stats ? `₹${Number(stats.totalRevenue).toLocaleString("en-IN")}` : "—", icon: "💰", color: "#4ade80", bg: "rgba(74,222,128,0.1)" },
  ];

  return (
    <div style={S.page}>
      <Sidebar />
      <main style={S.main}>
        <div style={{ marginBottom: 32 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Dashboard</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>Platform overview</p>
        </div>

        {/* Stat cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 28 }}>
          {statCards.map(({ label, value, icon, color, bg }) => (
            <div key={label} style={{ ...S.card, padding: 24 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
                <div style={{ width: 40, height: 40, borderRadius: 12, background: bg, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20 }}>{icon}</div>
                <div style={{ width: 4, height: 36, background: color, borderRadius: 4 }} />
              </div>
              <div style={{ color, fontSize: 28, fontWeight: 800 }}>{loading ? "…" : value}</div>
              <div style={{ color: "#475569", fontSize: 13, marginTop: 4 }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Grid: status + architecture */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
          <div style={{ ...S.card, padding: 24 }}>
            <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 15, marginBottom: 18 }}>System Status</div>
            {[
              { name: "User App", port: "3000", url: "http://localhost:3000", color: "#2dd4bf" },
              { name: "Admin App", port: "3002", url: "http://localhost:3002", color: "#2dd4bf" },
              { name: "Backend API", port: "3001", url: "http://localhost:3001/health", color: "#2dd4bf" },
              { name: "Kill Bill", port: "8080", url: "http://localhost:9090", color: "#2dd4bf" },
              { name: "Odoo ERP", port: "8069", url: "http://localhost:8069", color: "#f59e0b" },
              { name: "PostgreSQL", port: "5432", url: null, color: "#2dd4bf" },
            ].map(({ name, port, url, color }) => (
              <div key={name} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: color, display: "inline-block" }} />
                  <span style={{ color: "#cbd5e1", fontSize: 14 }}>{name}</span>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ color: "#334155", fontSize: 12, fontFamily: "monospace" }}>:{port}</span>
                  {url && <a href={url} target="_blank" rel="noreferrer" style={{ color: "#2dd4bf", fontSize: 12, textDecoration: "none" }}>Open ↗</a>}
                </div>
              </div>
            ))}
          </div>

          <div style={{ ...S.card, padding: 24 }}>
            <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 15, marginBottom: 18 }}>Key Flows</div>
            {[
              { flow: "User registers", result: "→ Kill Bill account created" },
              { flow: "User subscribes", result: "→ KB subscription + entitlements granted" },
              { flow: "Book (covered)", result: "→ Entitlement decremented, cost ₹0" },
              { flow: "Book (no balance)", result: "→ Razorpay charge at service price" },
              { flow: "Admin edits price", result: "→ Instant, affects next pay-per-use" },
              { flow: "Monthly renewal", result: "→ Kill Bill auto-charges, resets usage" },
            ].map(({ flow, result }) => (
              <div key={flow} style={{ padding: "9px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                <span style={{ color: "#60a5fa", fontSize: 13, fontWeight: 600 }}>{flow}</span>
                <span style={{ color: "#475569", fontSize: 13 }}> {result}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recent bookings */}
        <div style={{ ...S.card, padding: 24 }}>
          <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 15, marginBottom: 18 }}>Recent Bookings</div>
          {bookings.length === 0 ? (
            <div style={{ color: "#334155", fontSize: 14, textAlign: "center", padding: 32 }}>No bookings yet</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                  {["Patient", "Service", "Type", "Amount", "Date"].map(h => (
                    <th key={h} style={{ color: "#334155", fontSize: 11, fontWeight: 600, textAlign: "left", padding: "0 0 12px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bookings.map((b: any) => (
                  <tr key={b.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                    <td style={{ color: "#e2e8f0", fontSize: 14, fontWeight: 600, padding: "12px 0" }}>{b.user_name}</td>
                    <td style={{ color: "#94a3b8", fontSize: 14, padding: "12px 0" }}>{b.service_name}</td>
                    <td style={{ padding: "12px 0" }}>
                      {b.covered_by_plan
                        ? <span style={{ background: "rgba(13,148,136,0.2)", color: "#2dd4bf", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>Plan</span>
                        : <span style={{ background: "rgba(96,165,250,0.15)", color: "#60a5fa", fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 999 }}>Paid</span>}
                    </td>
                    <td style={{ color: b.covered_by_plan ? "#2dd4bf" : "#f1f5f9", fontWeight: 700, fontSize: 14, padding: "12px 0" }}>
                      {b.covered_by_plan ? "₹0" : `₹${b.amount_paid}`}
                    </td>
                    <td style={{ color: "#475569", fontSize: 12, padding: "12px 0" }}>{new Date(b.booked_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>
    </div>
  );
}
