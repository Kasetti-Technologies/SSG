import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = { title: "HealthCare+ Admin", description: "Admin dashboard" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
      </head>
      <body style={{ fontFamily: "'Sora', system-ui, sans-serif", margin: 0, padding: 0, background: "#0b1120" }}>
        {children}
      </body>
    </html>
  );
}
