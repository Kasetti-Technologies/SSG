"use client";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

const planColors: Record<string, string> = { "Silver Plan": "#94a3b8", "Gold Plan": "#f59e0b", "Platinum Plan": "#a78bfa" };

export default function PackagesPage() {
  const [packages, setPackages] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [toast, setToast] = useState("");
  const [form, setForm] = useState({ name: "", description: "", monthly_price: "", items: [] as { service_code: string; quantity: number }[] });
  const inp = { width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none", boxSizing: "border-box" } as React.CSSProperties;

  useEffect(() => {
    Promise.all([adminApi.packages.list(), adminApi.services.list()])
      .then(([p, s]) => { setPackages(p); setServices(s); }).finally(() => setLoading(false));
  }, []);

  function showT(msg: string) { setToast(msg); setTimeout(() => setToast(""), 4000); }
  function addItem() { setForm({ ...form, items: [...form.items, { service_code: services[0]?.code || "", quantity: 1 }] }); }
  function updateItem(i: number, key: string, val: any) {
    const items = [...form.items]; items[i] = { ...items[i], [key]: key === "quantity" ? parseInt(val) : val }; setForm({ ...form, items });
  }
  async function createPackage() {
    try {
      await adminApi.packages.create({ name: form.name, description: form.description, monthly_price: parseFloat(form.monthly_price), items: form.items });
      showT("✅ Package created and registered in Kill Bill!");
      setShowCreate(false); setForm({ name: "", description: "", monthly_price: "", items: [] });
      const p = await adminApi.packages.list(); setPackages(p);
    } catch (e: any) { showT("❌ " + e.message); }
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
          <div>
            <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Packages</h1>
            <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>Subscription plans — auto-synced to Kill Bill</p>
          </div>
          <button onClick={() => setShowCreate(true)} style={{ padding: "9px 18px", borderRadius: 10, background: "linear-gradient(135deg,#0d9488,#0891b2)", border: "none", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>+ Create Package</button>
        </div>

        {toast && <div style={{ background: toast.startsWith("✅") ? "rgba(13,148,136,0.15)" : "rgba(220,38,38,0.15)", border: `1px solid ${toast.startsWith("✅") ? "rgba(45,212,191,0.25)" : "rgba(239,68,68,0.25)"}`, color: toast.startsWith("✅") ? "#2dd4bf" : "#f87171", borderRadius: 12, padding: "12px 16px", marginBottom: 16, fontSize: 14 }}>{toast}</div>}

        {showCreate && (
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: 24, marginBottom: 24 }}>
            <div style={{ color: "#f1f5f9", fontWeight: 700, marginBottom: 16 }}>New Package</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 16 }}>
              {[{ key: "name", label: "Package Name", ph: "Gold Plan" }, { key: "description", label: "Description", ph: "Comprehensive plan" }, { key: "monthly_price", label: "Monthly Price (₹)", ph: "4999" }].map(({ key, label, ph }) => (
                <div key={key}>
                  <label style={{ display: "block", color: "#64748b", fontSize: 12, marginBottom: 6, fontWeight: 600 }}>{label}</label>
                  <input value={(form as any)[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={ph} style={inp} />
                </div>
              ))}
            </div>
            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <label style={{ color: "#64748b", fontSize: 12, fontWeight: 600 }}>Package Items</label>
                <button onClick={addItem} style={{ color: "#2dd4bf", fontSize: 13, fontWeight: 600, background: "none", border: "none", cursor: "pointer" }}>+ Add Service</button>
              </div>
              {form.items.map((item, i) => (
                <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "center" }}>
                  <select value={item.service_code} onChange={e => updateItem(i, "service_code", e.target.value)} style={{ ...inp, flex: 1 }}>
                    {services.map(s => <option key={s.code} value={s.code}>{s.name}</option>)}
                  </select>
                  <input type="number" min="1" value={item.quantity} onChange={e => updateItem(i, "quantity", e.target.value)} style={{ ...inp, width: 70, textAlign: "center" }} />
                  <button onClick={() => setForm({ ...form, items: form.items.filter((_, j) => j !== i) })} style={{ color: "#f87171", fontSize: 18, background: "none", border: "none", cursor: "pointer", lineHeight: 1 }}>×</button>
                </div>
              ))}
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={createPackage} style={{ padding: "9px 20px", borderRadius: 10, background: "linear-gradient(135deg,#0d9488,#0891b2)", border: "none", color: "#fff", fontWeight: 700, cursor: "pointer" }}>Create Package</button>
              <button onClick={() => setShowCreate(false)} style={{ padding: "9px 20px", borderRadius: 10, background: "transparent", border: "1px solid rgba(255,255,255,0.1)", color: "#64748b", cursor: "pointer" }}>Cancel</button>
            </div>
          </div>
        )}

        {loading ? <div style={{ color: "#475569", textAlign: "center", padding: 60 }}>Loading…</div> : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 20 }}>
            {packages.map((pkg: any) => {
              const color = planColors[pkg.name] || "#2dd4bf";
              return (
                <div key={pkg.id} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 28 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                    <div style={{ color: "#f1f5f9", fontWeight: 800, fontSize: 18 }}>{pkg.name}</div>
                    <span style={{ fontFamily: "monospace", fontSize: 10, background: "rgba(255,255,255,0.06)", color: "#475569", padding: "3px 8px", borderRadius: 6 }}>{pkg.kb_plan_name}</span>
                  </div>
                  <div style={{ color: "#475569", fontSize: 13, marginBottom: 16, lineHeight: 1.5 }}>{pkg.description}</div>
                  <div style={{ marginBottom: 20 }}>
                    <span style={{ color, fontSize: 34, fontWeight: 800 }}>₹{pkg.monthly_price}</span>
                    <span style={{ color: "#475569", fontSize: 13 }}>/mo</span>
                  </div>
                  <div style={{ borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 16 }}>
                    {pkg.items?.map((item: any) => (
                      <div key={item.service_code} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0" }}>
                        <span style={{ color, fontSize: 14 }}>◆</span>
                        <span style={{ color: "#94a3b8", fontSize: 13 }}>{item.quantity}× {item.service_name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
