"use client";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function ServicesPage() {
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newPrice, setNewPrice] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ code: "", name: "", description: "", price: "", category: "Radiology" });
  const [toast, setToast] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);
  const [odooStatus, setOdooStatus] = useState<{ ok: boolean; message: string } | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);

  function load() { adminApi.services.list().then(setServices).finally(() => setLoading(false)); }

  useEffect(() => {
    load();
    // Check Odoo connection on mount
    checkOdoo();
  }, []);

  async function checkOdoo() {
    try {
      const status = await fetch(`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001"}/api/admin/odoo/status`).then(r => r.json());
      setOdooStatus(status);
    } catch {
      setOdooStatus({ ok: false, message: "Cannot reach backend" });
    }
  }

  function showToast(type: "success" | "error" | "info", text: string) {
    setToast({ type, text });
    setTimeout(() => setToast(null), 4000);
  }

  async function savePrice(code: string) {
    try {
      const res = await adminApi.services.updatePrice(code, parseFloat(newPrice));
      const odooMsg = res.odoo?.synced
        ? ` • Odoo: ${res.odoo.action} ✅`
        : ` • Odoo: skipped ⚠`;
      showToast("success", `✅ Price updated${odooMsg}`);
      setEditingId(null);
      load();
    } catch (e: any) {
      showToast("error", e.message);
    }
  }

  async function addService() {
    try {
      const res = await adminApi.services.save({ ...form, price: parseFloat(form.price) });
      const odooMsg = res.odoo?.synced
        ? ` • Odoo synced ✅`
        : ` • Odoo: skipped ⚠`;
      showToast("success", `✅ Service saved${odooMsg}`);
      setShowAdd(false);
      setForm({ code: "", name: "", description: "", price: "", category: "Radiology" });
      load();
    } catch (e: any) {
      showToast("error", e.message);
    }
  }

  async function handlePushAll() {
    setSyncing(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001"}/api/admin/odoo/push-all`, {
        method: "POST",
      }).then(r => r.json());

      if (res.error) throw new Error(res.error);

      setLastSync(new Date().toLocaleTimeString("en-IN"));
      showToast("success",
        `✅ Sync done — Services: ${res.services.pushed} pushed, ${res.services.failed} failed | Packages: ${res.packages.pushed} pushed, ${res.packages.failed} failed`
      );
      await checkOdoo();
    } catch (e: any) {
      showToast("error", `❌ Sync failed: ${e.message}`);
    } finally {
      setSyncing(false);
    }
  }

  const inp = { width: "100%", padding: "10px 12px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none", boxSizing: "border-box" } as React.CSSProperties;

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Services</h1>
            <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>Manage diagnostic services — auto-synced to Odoo</p>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={handlePushAll} disabled={syncing}
              style={{ padding: "9px 16px", borderRadius: 10, background: syncing ? "rgba(124,58,237,0.3)" : "rgba(124,58,237,0.15)", border: "1px solid rgba(124,58,237,0.4)", color: "#a78bfa", fontSize: 13, fontWeight: 600, cursor: syncing ? "not-allowed" : "pointer" }}>
              {syncing ? "⏳ Syncing…" : "🔄 Sync All to Odoo"}
            </button>
            <button onClick={() => setShowAdd(true)}
              style={{ padding: "9px 18px", borderRadius: 10, background: "linear-gradient(135deg,#0d9488,#0891b2)", border: "none", color: "#fff", fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
              + Add Service
            </button>
          </div>
        </div>

        {/* Odoo status bar */}
        <div style={{ background: odooStatus?.ok ? "rgba(13,148,136,0.1)" : "rgba(245,158,11,0.08)", border: `1px solid ${odooStatus?.ok ? "rgba(45,212,191,0.2)" : "rgba(245,158,11,0.2)"}`, borderRadius: 12, padding: "12px 18px", marginBottom: 20, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <span style={{ width: 8, height: 8, borderRadius: "50%", background: odooStatus?.ok ? "#2dd4bf" : "#f59e0b", display: "inline-block" }} />
            <span style={{ color: odooStatus?.ok ? "#2dd4bf" : "#f59e0b", fontSize: 13, fontWeight: 600 }}>
              Odoo ERP — {odooStatus === null ? "Checking…" : odooStatus.ok ? `Connected (${odooStatus.message})` : `Not connected: ${odooStatus.message}`}
            </span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {lastSync && <span style={{ color: "#334155", fontSize: 12 }}>Last sync: {lastSync}</span>}
            <button onClick={checkOdoo} style={{ color: "#475569", fontSize: 12, background: "none", border: "none", cursor: "pointer" }}>Refresh ↺</button>
          </div>
        </div>

        {/* Toast */}
        {toast && (
          <div style={{ borderRadius: 12, padding: "12px 16px", marginBottom: 16, fontSize: 13, fontWeight: 500,
            background: toast.type === "success" ? "rgba(13,148,136,0.15)" : toast.type === "error" ? "rgba(220,38,38,0.15)" : "rgba(96,165,250,0.15)",
            border: `1px solid ${toast.type === "success" ? "rgba(45,212,191,0.25)" : toast.type === "error" ? "rgba(239,68,68,0.25)" : "rgba(96,165,250,0.25)"}`,
            color: toast.type === "success" ? "#2dd4bf" : toast.type === "error" ? "#f87171" : "#60a5fa" }}>
            {toast.text}
          </div>
        )}

        {/* Add service form */}
        {showAdd && (
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: 24, marginBottom: 20 }}>
            <div style={{ color: "#f1f5f9", fontWeight: 700, marginBottom: 16 }}>Add / Update Service</div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
              {[
                { key: "code", label: "Code (e.g. MRI_BRAIN)", ph: "MRI_BRAIN" },
                { key: "name", label: "Display Name", ph: "MRI Brain Scan" },
                { key: "description", label: "Description", ph: "Full brain MRI with contrast" },
                { key: "price", label: "Price (₹)", ph: "2000" },
              ].map(({ key, label, ph }) => (
                <div key={key}>
                  <label style={{ display: "block", color: "#64748b", fontSize: 12, marginBottom: 6, fontWeight: 600 }}>{label}</label>
                  <input value={(form as any)[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} placeholder={ph} style={inp} />
                </div>
              ))}
              <div>
                <label style={{ display: "block", color: "#64748b", fontSize: 12, marginBottom: 6, fontWeight: 600 }}>Category</label>
                <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} style={inp}>
                  {["Radiology", "Pathology", "Cardiology", "General"].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
            </div>
            <div style={{ background: "rgba(124,58,237,0.08)", border: "1px solid rgba(124,58,237,0.2)", borderRadius: 10, padding: "10px 14px", marginBottom: 16, fontSize: 12, color: "#a78bfa" }}>
              💡 This service will be automatically synced to Odoo after saving
            </div>
            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={addService} style={{ padding: "9px 20px", borderRadius: 10, background: "linear-gradient(135deg,#0d9488,#0891b2)", border: "none", color: "#fff", fontWeight: 700, cursor: "pointer" }}>Save & Sync to Odoo</button>
              <button onClick={() => setShowAdd(false)} style={{ padding: "9px 20px", borderRadius: 10, background: "transparent", border: "1px solid rgba(255,255,255,0.1)", color: "#64748b", cursor: "pointer" }}>Cancel</button>
            </div>
          </div>
        )}

        {/* Services table */}
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ background: "rgba(255,255,255,0.03)" }}>
              <tr>
                {["Code", "Name", "Category", "Price", "Action"].map(h => (
                  <th key={h} style={{ color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "14px 20px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} style={{ color: "#475569", textAlign: "center", padding: 48 }}>Loading…</td></tr>
              ) : services.map((s: any) => (
                <tr key={s.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                  <td style={{ padding: "14px 20px", fontFamily: "monospace", color: "#475569", fontSize: 12 }}>{s.code}</td>
                  <td style={{ padding: "14px 20px", color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{s.name}</td>
                  <td style={{ padding: "14px 20px" }}>
                    <span style={{ background: "rgba(255,255,255,0.06)", color: "#94a3b8", fontSize: 11, padding: "3px 10px", borderRadius: 999 }}>{s.category}</span>
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    {editingId === s.id ? (
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <input type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)}
                          style={{ width: 90, padding: "6px 10px", borderRadius: 8, border: "1px solid rgba(45,212,191,0.4)", background: "rgba(45,212,191,0.05)", color: "#f1f5f9", fontSize: 14, outline: "none" }} />
                        <button onClick={() => savePrice(s.code)} style={{ color: "#2dd4bf", fontSize: 13, fontWeight: 600, background: "none", border: "none", cursor: "pointer" }}>Save</button>
                        <button onClick={() => setEditingId(null)} style={{ color: "#475569", fontSize: 13, background: "none", border: "none", cursor: "pointer" }}>✕</button>
                      </div>
                    ) : (
                      <span style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 15 }}>₹{s.price}</span>
                    )}
                  </td>
                  <td style={{ padding: "14px 20px" }}>
                    <button onClick={() => { setEditingId(s.id); setNewPrice(String(s.price)); }}
                      style={{ color: "#2dd4bf", fontSize: 13, fontWeight: 600, background: "rgba(45,212,191,0.08)", border: "1px solid rgba(45,212,191,0.2)", borderRadius: 8, padding: "5px 12px", cursor: "pointer" }}>
                      Edit Price
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
