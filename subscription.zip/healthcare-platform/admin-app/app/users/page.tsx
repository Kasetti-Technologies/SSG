"use client";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import { adminApi } from "@/lib/api";

export default function UsersPage() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => { adminApi.users().then(setUsers).finally(() => setLoading(false)); }, []);

  const filtered = users.filter(u => u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "36px 32px", overflow: "auto" }}>
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Users</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>{users.length} registered patients</p>
        </div>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search name or email…"
          style={{ width: "100%", maxWidth: 360, padding: "10px 14px", borderRadius: 12, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.04)", color: "#f1f5f9", fontSize: 14, outline: "none", marginBottom: 20 }} />
        <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead style={{ background: "rgba(255,255,255,0.03)" }}>
              <tr>
                {["Patient", "Email", "Phone", "Plan", "Joined"].map(h => (
                  <th key={h} style={{ color: "#334155", fontSize: 11, fontWeight: 700, textAlign: "left", padding: "14px 20px", textTransform: "uppercase", letterSpacing: "0.08em" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={5} style={{ color: "#475569", textAlign: "center", padding: 48 }}>Loading…</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={5} style={{ color: "#334155", textAlign: "center", padding: 48 }}>No users found</td></tr>
              ) : filtered.map((u: any) => (
                <tr key={u.id} style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                  <td style={{ padding: "14px 20px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 34, height: 34, borderRadius: 10, background: "linear-gradient(135deg,#0d9488,#0891b2)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontWeight: 700, fontSize: 14, flexShrink: 0 }}>
                        {u.name.charAt(0).toUpperCase()}
                      </div>
                      <span style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{u.name}</span>
                    </div>
                  </td>
                  <td style={{ padding: "14px 20px", color: "#64748b", fontSize: 13 }}>{u.email}</td>
                  <td style={{ padding: "14px 20px", color: "#475569", fontSize: 13 }}>{u.phone || "—"}</td>
                  <td style={{ padding: "14px 20px" }}>
                    {u.package_name
                      ? <span style={{ background: "rgba(13,148,136,0.15)", color: "#2dd4bf", fontSize: 12, fontWeight: 600, padding: "4px 12px", borderRadius: 999, border: "1px solid rgba(45,212,191,0.2)" }}>{u.package_name}</span>
                      : <span style={{ color: "#334155", fontSize: 12 }}>No plan</span>}
                  </td>
                  <td style={{ padding: "14px 20px", color: "#334155", fontSize: 12 }}>{new Date(u.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
}
