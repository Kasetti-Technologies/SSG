"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/dashboard", icon: "📊", label: "Dashboard" },
  { href: "/services", icon: "🔬", label: "Services" },
  { href: "/packages", icon: "💎", label: "Packages" },
  { href: "/users", icon: "👥", label: "Users" },
  { href: "/bookings", icon: "📅", label: "Bookings" },
];

export default function Sidebar() {
  const path = usePathname();
  return (
    <aside style={{ width: 240, background: "#060d1a", borderRight: "1px solid rgba(255,255,255,0.06)", minHeight: "100vh", display: "flex", flexDirection: "column", flexShrink: 0, fontFamily: "'Sora', sans-serif" }}>
      <div style={{ padding: "28px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 24 }}>🏥</span>
          <div>
            <div style={{ color: "#2dd4bf", fontWeight: 800, fontSize: 15, letterSpacing: "-0.3px" }}>HealthCare+</div>
            <div style={{ color: "#334155", fontSize: 11, marginTop: 1 }}>Admin Panel</div>
          </div>
        </div>
      </div>
      <nav style={{ padding: "16px 12px", flex: 1 }}>
        {links.map(({ href, icon, label }) => {
          const active = path === href;
          return (
            <Link key={href} href={href} style={{ display: "flex", alignItems: "center", gap: 12, padding: "11px 14px", borderRadius: 12, marginBottom: 4, textDecoration: "none", background: active ? "rgba(45,212,191,0.1)" : "transparent", color: active ? "#2dd4bf" : "#475569", fontWeight: active ? 600 : 400, fontSize: 14, transition: "all 0.15s", borderLeft: active ? "3px solid #2dd4bf" : "3px solid transparent" }}>
              <span style={{ fontSize: 17 }}>{icon}</span>
              {label}
            </Link>
          );
        })}
      </nav>
      <div style={{ padding: 16, borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: 14 }}>
          <div style={{ color: "#334155", fontSize: 11, fontWeight: 600, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.08em" }}>Services</div>
          {[
            { label: "Kill Bill UI", url: "http://localhost:9090", color: "#2dd4bf" },
            { label: "Odoo ERP", url: "http://localhost:8069", color: "#a78bfa" },
            { label: "Backend API", url: "http://localhost:3001/health", color: "#60a5fa" },
          ].map(({ label, url, color }) => (
            <a key={label} href={url} target="_blank" rel="noreferrer"
              style={{ display: "flex", alignItems: "center", gap: 8, padding: "5px 0", textDecoration: "none", fontSize: 12, color: "#475569" }}>
              <span style={{ width: 7, height: 7, borderRadius: "50%", background: color, display: "inline-block" }} />
              {label}
              <span style={{ marginLeft: "auto", color: "#334155" }}>↗</span>
            </a>
          ))}
        </div>
      </div>
    </aside>
  );
}
