const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";

async function apiFetch<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Request failed" }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

export const adminApi = {
  stats: () => apiFetch<any>("/api/admin/stats"),
  users: () => apiFetch<any[]>("/api/admin/users"),
  services: {
    list: () => apiFetch<any[]>("/api/admin/services"),
    save: (data: any) =>
      apiFetch<any>("/api/admin/services", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    updatePrice: (code: string, price: number) =>
      apiFetch<any>(`/api/admin/services/${code}/price`, {
        method: "PATCH",
        body: JSON.stringify({ price }),
      }),
  },
  packages: {
    list: () => apiFetch<any[]>("/api/packages"),
    create: (data: any) =>
      apiFetch<any>("/api/packages", { method: "POST", body: JSON.stringify(data) }),
  },
  bookings: () => apiFetch<any[]>("/api/admin/bookings"),
};
