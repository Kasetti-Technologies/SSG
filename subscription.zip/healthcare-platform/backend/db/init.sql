-- ─────────────────────────────────────────────────────────────────
--  Healthcare Platform — PostgreSQL Schema
-- ─────────────────────────────────────────────────────────────────

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users
CREATE TABLE IF NOT EXISTS users (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         VARCHAR(255) NOT NULL,
  email        VARCHAR(255) UNIQUE NOT NULL,
  phone        VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  kb_account_id VARCHAR(255),
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Services (synced from Odoo)
CREATE TABLE IF NOT EXISTS services (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code         VARCHAR(100) UNIQUE NOT NULL,
  name         VARCHAR(255) NOT NULL,
  description  TEXT,
  price        NUMERIC(10, 2) NOT NULL,
  category     VARCHAR(100),
  odoo_product_id INTEGER,
  is_active    BOOLEAN DEFAULT TRUE,
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Packages
CREATE TABLE IF NOT EXISTS packages (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name           VARCHAR(255) NOT NULL,
  description    TEXT,
  monthly_price  NUMERIC(10, 2) NOT NULL,
  kb_plan_name   VARCHAR(255),
  is_active      BOOLEAN DEFAULT TRUE,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- Package Items
CREATE TABLE IF NOT EXISTS package_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  package_id  UUID REFERENCES packages(id) ON DELETE CASCADE,
  service_id  UUID REFERENCES services(id),
  quantity    INTEGER NOT NULL DEFAULT 1
);

-- User Subscriptions
CREATE TABLE IF NOT EXISTS subscriptions (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id            UUID REFERENCES users(id),
  package_id         UUID REFERENCES packages(id),
  kb_subscription_id VARCHAR(255),
  kb_bundle_id       VARCHAR(255),
  status             VARCHAR(50) DEFAULT 'ACTIVE',
  started_at         TIMESTAMPTZ DEFAULT NOW(),
  renewed_at         TIMESTAMPTZ,
  expires_at         TIMESTAMPTZ
);

-- Entitlements (what user can use from their package)
CREATE TABLE IF NOT EXISTS entitlements (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID REFERENCES users(id),
  subscription_id UUID REFERENCES subscriptions(id),
  service_id   UUID REFERENCES services(id),
  remaining    INTEGER NOT NULL DEFAULT 0,
  total        INTEGER NOT NULL DEFAULT 0,
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Bookings
CREATE TABLE IF NOT EXISTS bookings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID REFERENCES users(id),
  service_id      UUID REFERENCES services(id),
  entitlement_id  UUID REFERENCES entitlements(id),
  covered_by_plan BOOLEAN DEFAULT FALSE,
  amount_paid     NUMERIC(10, 2) DEFAULT 0,
  razorpay_order_id VARCHAR(255),
  razorpay_payment_id VARCHAR(255),
  status          VARCHAR(50) DEFAULT 'CONFIRMED',
  booked_at       TIMESTAMPTZ DEFAULT NOW(),
  scheduled_at    TIMESTAMPTZ
);

-- Payments log
CREATE TABLE IF NOT EXISTS payments (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id             UUID REFERENCES users(id),
  booking_id          UUID REFERENCES bookings(id),
  razorpay_order_id   VARCHAR(255),
  razorpay_payment_id VARCHAR(255),
  amount              NUMERIC(10,2),
  currency            VARCHAR(10) DEFAULT 'INR',
  status              VARCHAR(50),
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Seed Data ───────────────────────────────────────────────────

INSERT INTO services (code, name, description, price, category) VALUES
  ('MRI_BRAIN',   'MRI Brain Scan',       'Full brain MRI scan with contrast',         2000.00, 'Radiology'),
  ('MRI_HEART',   'MRI Heart Scan',        'Cardiac MRI scan',                          3000.00, 'Radiology'),
  ('CT_CHEST',    'CT Chest Scan',         'High-resolution CT scan of the chest',      1500.00, 'Radiology'),
  ('XRAY_CHEST',  'Chest X-Ray',           'Standard chest X-ray',                       500.00, 'Radiology'),
  ('BLOOD_FULL',  'Full Blood Panel',      'Complete blood count + metabolic panel',     800.00, 'Pathology'),
  ('ECG',         'ECG / EKG',             'Electrocardiogram',                          600.00, 'Cardiology'),
  ('ULTRASOUND',  'Abdominal Ultrasound',  'Ultrasound of abdominal organs',            1200.00, 'Radiology')
ON CONFLICT (code) DO NOTHING;

INSERT INTO packages (name, description, monthly_price, kb_plan_name) VALUES
  ('Silver Plan', 'Basic diagnostics coverage', 1999.00, 'SILVER_MONTHLY'),
  ('Gold Plan',   'Comprehensive radiology + labs', 4999.00, 'GOLD_MONTHLY'),
  ('Platinum Plan','Full coverage — unlimited scans + labs', 8999.00, 'PLATINUM_MONTHLY')
ON CONFLICT DO NOTHING;

-- Gold Plan items
WITH gold AS (SELECT id FROM packages WHERE name = 'Gold Plan' LIMIT 1),
     mri_brain AS (SELECT id FROM services WHERE code = 'MRI_BRAIN'),
     ct_chest  AS (SELECT id FROM services WHERE code = 'CT_CHEST'),
     blood     AS (SELECT id FROM services WHERE code = 'BLOOD_FULL'),
     ecg       AS (SELECT id FROM services WHERE code = 'ECG')
INSERT INTO package_items (package_id, service_id, quantity)
SELECT gold.id, mri_brain.id, 2 FROM gold, mri_brain
UNION ALL
SELECT gold.id, ct_chest.id,  1 FROM gold, ct_chest
UNION ALL
SELECT gold.id, blood.id,     3 FROM gold, blood
UNION ALL
SELECT gold.id, ecg.id,       2 FROM gold, ecg
ON CONFLICT DO NOTHING;

-- Silver Plan items
WITH silver AS (SELECT id FROM packages WHERE name = 'Silver Plan' LIMIT 1),
     xray   AS (SELECT id FROM services WHERE code = 'XRAY_CHEST'),
     blood  AS (SELECT id FROM services WHERE code = 'BLOOD_FULL'),
     ecg    AS (SELECT id FROM services WHERE code = 'ECG')
INSERT INTO package_items (package_id, service_id, quantity)
SELECT silver.id, xray.id,  2 FROM silver, xray
UNION ALL
SELECT silver.id, blood.id, 2 FROM silver, blood
UNION ALL
SELECT silver.id, ecg.id,   1 FROM silver, ecg
ON CONFLICT DO NOTHING;

-- Platinum Plan items
WITH plat AS (SELECT id FROM packages WHERE name = 'Platinum Plan' LIMIT 1),
     mri_brain AS (SELECT id FROM services WHERE code = 'MRI_BRAIN'),
     mri_heart AS (SELECT id FROM services WHERE code = 'MRI_HEART'),
     ct_chest  AS (SELECT id FROM services WHERE code = 'CT_CHEST'),
     xray      AS (SELECT id FROM services WHERE code = 'XRAY_CHEST'),
     blood     AS (SELECT id FROM services WHERE code = 'BLOOD_FULL'),
     ecg       AS (SELECT id FROM services WHERE code = 'ECG'),
     ultrasound AS (SELECT id FROM services WHERE code = 'ULTRASOUND')
INSERT INTO package_items (package_id, service_id, quantity)
SELECT plat.id, mri_brain.id,  5 FROM plat, mri_brain
UNION ALL
SELECT plat.id, mri_heart.id,  3 FROM plat, mri_heart
UNION ALL
SELECT plat.id, ct_chest.id,   3 FROM plat, ct_chest
UNION ALL
SELECT plat.id, xray.id,       5 FROM plat, xray
UNION ALL
SELECT plat.id, blood.id,      5 FROM plat, blood
UNION ALL
SELECT plat.id, ecg.id,        5 FROM plat, ecg
UNION ALL
SELECT plat.id, ultrasound.id, 3 FROM plat, ultrasound
ON CONFLICT DO NOTHING;
