import "dotenv/config";
import express from "express";
import cors from "cors";

import authRoutes from "./routes/auth";
import servicesRoutes from "./routes/services";
import packagesRoutes from "./routes/packages";
import subscriptionsRoutes from "./routes/subscriptions";
import bookingsRoutes from "./routes/bookings";
import adminRoutes from "./routes/admin";

const app = express();
const PORT = process.env.PORT || 3001;

app.use(
  cors({
    origin: ["http://localhost:3000", "http://localhost:3002"],
    credentials: true,
  })
);
app.use(express.json());

// Health
app.get("/health", (_req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/services", servicesRoutes);
app.use("/api/packages", packagesRoutes);
app.use("/api/subscriptions", subscriptionsRoutes);
app.use("/api/bookings", bookingsRoutes);
app.use("/api/admin", adminRoutes);

app.listen(PORT, () => {
  console.log(`\n🏥 Healthcare Backend running on http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health`);
});

export default app;
