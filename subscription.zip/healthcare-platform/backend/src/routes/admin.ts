import { Router, Request, Response } from "express";
import { query } from "../db";
import {
  pushServiceToOdoo,
  pushPackageToOdoo,
  pushAllToOdoo,
  pullPricesFromOdoo,
  checkOdooConnection,
} from "../services/odoo";

const router = Router();

// ─── GET /api/admin/stats ────────────────────────────────────────────────────
router.get("/stats", async (_req, res: Response) => {
  try {
    const [users] = await query<{ count: string }>("SELECT COUNT(*) AS count FROM users");
    const [activeSubs] = await query<{ count: string }>("SELECT COUNT(*) AS count FROM subscriptions WHERE status = 'ACTIVE'");
    const [bookings] = await query<{ count: string }>("SELECT COUNT(*) AS count FROM bookings");
    const [revenue] = await query<{ total: string }>("SELECT COALESCE(SUM(amount), 0) AS total FROM payments WHERE status = 'SUCCESS'");

    res.json({
      totalUsers: parseInt(users.count),
      activeSubscriptions: parseInt(activeSubs.count),
      totalBookings: parseInt(bookings.count),
      totalRevenue: parseFloat(revenue.total),
    });
  } catch (err) {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/admin/users ────────────────────────────────────────────────────
router.get("/users", async (_req, res) => {
  try {
    const users = await query(`
      SELECT u.id, u.name, u.email, u.phone, u.created_at,
             sub.status AS sub_status, p.name AS package_name
      FROM users u
      LEFT JOIN subscriptions sub ON sub.user_id = u.id AND sub.status = 'ACTIVE'
      LEFT JOIN packages p ON p.id = sub.package_id
      ORDER BY u.created_at DESC
    `);
    res.json(users);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/admin/services ─────────────────────────────────────────────────
router.get("/services", async (_req, res) => {
  try {
    const rows = await query("SELECT * FROM services ORDER BY category, name");
    res.json(rows);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── POST /api/admin/services — create or update ─────────────────────────────
// Auto-pushes to Odoo after saving to PostgreSQL
router.post("/services", async (req: Request, res: Response) => {
  try {
    const { code, name, description, price, category } = req.body;

    // 1. Save to PostgreSQL
    const existing = await query("SELECT id FROM services WHERE code = $1", [code]);
    if (existing.length > 0) {
      await query(
        `UPDATE services SET name=$1, description=$2, price=$3, category=$4, updated_at=NOW()
         WHERE code=$5`,
        [name, description, price, category, code]
      );
    } else {
      await query(
        `INSERT INTO services (code, name, description, price, category)
         VALUES ($1, $2, $3, $4, $5)`,
        [code, name, description, price, category]
      );
    }

    // 2. Push to Odoo (best-effort — don't fail if Odoo is down)
    let odooResult: any = null;
    try {
      odooResult = await pushServiceToOdoo({ code, name, description, price: parseFloat(price), category });
    } catch (e: any) {
      console.warn(`[Odoo] Push failed for service ${code}:`, e.message);
    }

    res.json({
      message: "Service saved",
      odoo: odooResult
        ? { synced: true, action: odooResult.action, odooId: odooResult.odooId }
        : { synced: false, reason: "Odoo unavailable" },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed" });
  }
});

// ─── PATCH /api/admin/services/:code/price ───────────────────────────────────
// Update price only — also pushes to Odoo
router.patch("/services/:code/price", async (req: Request, res: Response) => {
  try {
    const { price } = req.body;
    const { code } = req.params;

    // 1. Update PostgreSQL
    const rows = await query<{ id: string; name: string; description: string; category: string }>(
      `UPDATE services SET price=$1, updated_at=NOW()
       WHERE code=$2
       RETURNING id, name, description, category`,
      [price, code]
    );

    if (!rows.length) {
      res.status(404).json({ error: "Service not found" });
      return;
    }

    const svc = rows[0];

    // 2. Push to Odoo
    let odooResult: any = null;
    try {
      odooResult = await pushServiceToOdoo({
        code,
        name: svc.name,
        description: svc.description,
        price: parseFloat(price),
        category: svc.category,
      });
    } catch (e: any) {
      console.warn(`[Odoo] Price push failed for ${code}:`, e.message);
    }

    res.json({
      message: "Price updated",
      odoo: odooResult
        ? { synced: true, action: odooResult.action }
        : { synced: false, reason: "Odoo unavailable" },
    });
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/admin/bookings ──────────────────────────────────────────────────
router.get("/bookings", async (_req, res) => {
  try {
    const rows = await query(`
      SELECT b.*, s.name AS service_name, u.name AS user_name
      FROM bookings b
      JOIN services s ON s.id = b.service_id
      JOIN users u ON u.id = b.user_id
      ORDER BY b.booked_at DESC LIMIT 50
    `);
    res.json(rows);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/admin/odoo/status ──────────────────────────────────────────────
router.get("/odoo/status", async (_req, res) => {
  try {
    const result = await checkOdooConnection();
    res.json(result);
  } catch {
    res.json({ ok: false, message: "Odoo unreachable" });
  }
});

// ─── POST /api/admin/odoo/push-all ───────────────────────────────────────────
// Push ALL services + packages from PostgreSQL → Odoo
router.post("/odoo/push-all", async (_req, res) => {
  try {
    const services = await query("SELECT * FROM services WHERE is_active = TRUE");
    const packages = await query("SELECT * FROM packages WHERE is_active = TRUE");

    const result = await pushAllToOdoo(services, packages);

    res.json({
      message: "Sync complete",
      services: result.services,
      packages: result.packages,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error("[Odoo] Push-all failed:", err.message);
    res.status(500).json({ error: err.message });
  }
});

// ─── POST /api/admin/odoo/pull-prices ────────────────────────────────────────
// Pull prices from Odoo → update PostgreSQL (optional reverse sync)
router.post("/odoo/pull-prices", async (_req, res) => {
  try {
    const result = await pullPricesFromOdoo();
    res.json({
      message: "Pull complete",
      updated: result.updated,
      skipped: result.skipped,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
