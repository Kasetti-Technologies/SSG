import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { query, queryOne } from "../db";
import { signToken } from "../middleware/auth";
import { createKBAccount, addDefaultPaymentMethod } from "../services/killbill";

const router = Router();

router.post("/register", async (req: Request, res: Response) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !password) {
      res.status(400).json({ error: "name, email and password required" });
      return;
    }

    const existing = await queryOne(
      "SELECT id FROM users WHERE email = $1",
      [email]
    );
    if (existing) {
      res.status(409).json({ error: "Email already registered" });
      return;
    }

    const hash = await bcrypt.hash(password, 10);
    const users = await query<{ id: string }>(
      `INSERT INTO users (name, email, phone, password_hash)
       VALUES ($1, $2, $3, $4) RETURNING id`,
      [name, email, phone || null, hash]
    );
    const userId = users[0].id;

    // Create Kill Bill account (best-effort)
    let kbAccountId: string | null = null;
    try {
      kbAccountId = await createKBAccount({
        name,
        email,
        externalKey: `USER_${userId.slice(0, 8).toUpperCase()}`,
      });
      await addDefaultPaymentMethod(kbAccountId);
      await query("UPDATE users SET kb_account_id = $1 WHERE id = $2", [
        kbAccountId,
        userId,
      ]);
    } catch (e) {
      console.warn("[KillBill] Could not create KB account:", e);
    }

    const token = signToken(userId, email);
    res.status(201).json({
      token,
      user: { id: userId, name, email, kbAccountId },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Registration failed" });
  }
});

router.post("/login", async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = await queryOne<{
      id: string;
      name: string;
      email: string;
      password_hash: string;
    }>("SELECT * FROM users WHERE email = $1", [email]);

    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    const token = signToken(user.id, user.email);
    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login failed" });
  }
});

export default router;
