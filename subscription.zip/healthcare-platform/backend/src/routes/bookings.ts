import { Router, Response } from "express";
import { query, queryOne } from "../db";
import { authMiddleware, AuthRequest } from "../middleware/auth";
import { createOrder, verifyPaymentSignature } from "../services/razorpay";

const router = Router();

// ─── Helper: get the single latest active subscription for a user ────────────
async function getActiveSubscription(userId: string) {
  return queryOne<{ id: string }>(
    `SELECT id FROM subscriptions
     WHERE user_id = $1 AND status = 'ACTIVE'
     ORDER BY started_at DESC LIMIT 1`,
    [userId]
  );
}

// ─── Helper: get entitlement ONLY from the active subscription ───────────────
async function getEntitlement(userId: string, serviceId: string, subscriptionId: string) {
  return queryOne<{ id: string; remaining: number; total: number }>(
    `SELECT id, remaining, total
     FROM entitlements
     WHERE user_id = $1
       AND service_id = $2
       AND subscription_id = $3
       AND remaining > 0
     LIMIT 1`,
    [userId, serviceId, subscriptionId]
  );
}

// ─── GET /api/bookings/check/:serviceCode ────────────────────────────────────
// FLOW 6 — Is this service covered or pay-per-use?
router.get("/check/:serviceCode", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { serviceCode } = req.params;
    const userId = req.userId!;

    const service = await queryOne<{ id: string; code: string; name: string; price: number; category: string }>(
      "SELECT * FROM services WHERE code = $1 AND is_active = TRUE", [serviceCode]
    );
    if (!service) { res.status(404).json({ error: "Service not found" }); return; }

    // Only check against the single latest active subscription
    const activeSub = await getActiveSubscription(userId);
    const entitlement = activeSub
      ? await getEntitlement(userId, service.id, activeSub.id)
      : null;

    if (entitlement) {
      res.json({ service, covered: true, remaining: entitlement.remaining, entitlementId: entitlement.id, amountDue: 0 });
    } else {
      res.json({ service, covered: false, remaining: 0, entitlementId: null, amountDue: service.price });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Check failed" });
  }
});

// ─── POST /api/bookings/book ─────────────────────────────────────────────────
// FLOW 7 — Book using plan entitlement (free)
router.post("/book", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { serviceCode, scheduledAt } = req.body;
    const userId = req.userId!;

    const service = await queryOne<{ id: string; name: string; price: number }>(
      "SELECT * FROM services WHERE code = $1", [serviceCode]
    );
    if (!service) { res.status(404).json({ error: "Service not found" }); return; }

    // Only use entitlement from the current active subscription
    const activeSub = await getActiveSubscription(userId);
    if (!activeSub) {
      res.status(402).json({ error: "No active subscription", requiresPayment: true, price: service.price });
      return;
    }

    const entitlement = await getEntitlement(userId, service.id, activeSub.id);
    if (!entitlement) {
      res.status(402).json({ error: "No remaining entitlements. Please pay for this service.", requiresPayment: true, price: service.price });
      return;
    }

    // Create booking + decrement entitlement atomically
    const bookings = await query<{ id: string }>(
      `INSERT INTO bookings
         (user_id, service_id, entitlement_id, covered_by_plan, amount_paid, status, scheduled_at)
       VALUES ($1, $2, $3, TRUE, 0, 'CONFIRMED', $4)
       RETURNING id`,
      [userId, service.id, entitlement.id, scheduledAt || null]
    );

    await query(
      "UPDATE entitlements SET remaining = remaining - 1, updated_at = NOW() WHERE id = $1",
      [entitlement.id]
    );

    res.status(201).json({
      bookingId: bookings[0].id,
      service: service.name,
      coveredByPlan: true,
      amountPaid: 0,
      status: "CONFIRMED",
      entitlementRemaining: entitlement.remaining - 1,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Booking failed" });
  }
});

// ─── POST /api/bookings/pay/order ───────────────────────────────────────────
// Create Razorpay order for pay-per-use booking
router.post("/pay/order", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { serviceCode } = req.body;
    const service = await queryOne<{ id: string; price: number; name: string }>(
      "SELECT * FROM services WHERE code = $1", [serviceCode]
    );
    if (!service) { res.status(404).json({ error: "Service not found" }); return; }
    const order = await createOrder(Number(service.price));
    res.json({ order, service });
  } catch (err) {
    res.status(500).json({ error: "Failed to create order" });
  }
});

// ─── POST /api/bookings/pay/confirm ─────────────────────────────────────────
// Confirm pay-per-use booking after payment
router.post("/pay/confirm", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { serviceCode, scheduledAt, razorpayOrderId, razorpayPaymentId, razorpaySignature } = req.body;
    const userId = req.userId!;

    const valid = verifyPaymentSignature(razorpayOrderId, razorpayPaymentId, razorpaySignature || "demo_sig");
    if (!valid) { res.status(400).json({ error: "Invalid payment" }); return; }

    const service = await queryOne<{ id: string; price: number; name: string }>(
      "SELECT * FROM services WHERE code = $1", [serviceCode]
    );
    if (!service) { res.status(404).json({ error: "Service not found" }); return; }

    const bookings = await query<{ id: string }>(
      `INSERT INTO bookings
         (user_id, service_id, covered_by_plan, amount_paid, razorpay_order_id, razorpay_payment_id, status, scheduled_at)
       VALUES ($1, $2, FALSE, $3, $4, $5, 'CONFIRMED', $6)
       RETURNING id`,
      [userId, service.id, service.price, razorpayOrderId, razorpayPaymentId, scheduledAt || null]
    );

    await query(
      `INSERT INTO payments (user_id, booking_id, razorpay_order_id, razorpay_payment_id, amount, status)
       VALUES ($1, $2, $3, $4, $5, 'SUCCESS')`,
      [userId, bookings[0].id, razorpayOrderId, razorpayPaymentId, service.price]
    );

    res.status(201).json({
      bookingId: bookings[0].id,
      service: service.name,
      coveredByPlan: false,
      amountPaid: service.price,
      status: "CONFIRMED",
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Booking failed" });
  }
});

// ─── GET /api/bookings/my ───────────────────────────────────────────────────
router.get("/my", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const bookings = await query(
      `SELECT b.*, s.name AS service_name, s.code, s.category
       FROM bookings b
       JOIN services s ON s.id = b.service_id
       WHERE b.user_id = $1
       ORDER BY b.booked_at DESC`,
      [req.userId]
    );
    res.json(bookings);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// ─── GET /api/bookings/admin/all ─────────────────────────────────────────────
router.get("/admin/all", async (_req, res) => {
  try {
    const bookings = await query(
      `SELECT b.*, s.name AS service_name, u.name AS user_name, u.email
       FROM bookings b
       JOIN services s ON s.id = b.service_id
       JOIN users u ON u.id = b.user_id
       ORDER BY b.booked_at DESC
       LIMIT 100`
    );
    res.json(bookings);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

export default router;
