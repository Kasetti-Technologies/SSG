import { Router, Response, Request } from "express";
import { query } from "../db";
import { authMiddleware, AuthRequest } from "../middleware/auth";

const router = Router();

// GET /api/packages
router.get("/", async (_req: Request, res: Response) => {
  try {
    const packages = await query(`
      SELECT
        p.id, p.name, p.description, p.monthly_price, p.kb_plan_name,
        COALESCE(
          json_agg(
            json_build_object(
              'service_id',   pi.service_id,
              'service_code', s.code,
              'service_name', s.name,
              'quantity',     pi.quantity
            )
          ) FILTER (WHERE pi.id IS NOT NULL),
          '[]'
        ) AS items
      FROM packages p
      LEFT JOIN package_items pi ON pi.package_id = p.id
      LEFT JOIN services s ON s.id = pi.service_id
      WHERE p.is_active = TRUE
      GROUP BY p.id
      ORDER BY p.monthly_price
    `);
    res.json(packages);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch packages" });
  }
});

// GET /api/packages/:id
router.get("/:id", async (req: Request, res: Response) => {
  try {
    const rows = await query(
      `SELECT p.*, json_agg(
        json_build_object('service_code', s.code, 'service_name', s.name, 'quantity', pi.quantity)
      ) AS items
      FROM packages p
      JOIN package_items pi ON pi.package_id = p.id
      JOIN services s ON s.id = pi.service_id
      WHERE p.id = $1 GROUP BY p.id`,
      [req.params.id]
    );
    if (!rows[0]) { res.status(404).json({ error: "Package not found" }); return; }
    res.json(rows[0]);
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

// POST /api/packages (admin) — create package + push to Odoo + register in KB
router.post("/", async (req: Request, res: Response) => {
  try {
    const { name, description, monthly_price, items } = req.body;
    const planName = name.toUpperCase().replace(/\s+/g, "_");

    // 1. Save to PostgreSQL
    const rows = await query<{ id: string }>(
      `INSERT INTO packages (name, description, monthly_price, kb_plan_name)
       VALUES ($1, $2, $3, $4) RETURNING id`,
      [name, description, monthly_price, `${planName}_MONTHLY`]
    );
    const packageId = rows[0].id;

    for (const item of items || []) {
      const svc = await query("SELECT id FROM services WHERE code = $1", [item.service_code]);
      if (svc[0]) {
        await query(
          `INSERT INTO package_items (package_id, service_id, quantity) VALUES ($1, $2, $3)`,
          [packageId, svc[0].id, item.quantity]
        );
      }
    }

    // 2. Register in Kill Bill
    try {
      const { ensurePlanExists } = await import("../services/killbill");
      await ensurePlanExists(planName, monthly_price);
    } catch (e: any) {
      console.warn("[KillBill] Plan registration skipped:", e.message);
    }

    // 3. Push to Odoo (best-effort)
    let odooResult: any = null;
    try {
      const { pushPackageToOdoo } = await import("../services/odoo");
      odooResult = await pushPackageToOdoo({
        name,
        description,
        monthly_price: parseFloat(monthly_price),
      });
    } catch (e: any) {
      console.warn("[Odoo] Package push failed:", e.message);
    }

    res.status(201).json({
      id: packageId,
      name,
      monthly_price,
      odoo: odooResult
        ? { synced: true, action: odooResult.action, odooId: odooResult.odooId }
        : { synced: false, reason: "Odoo unavailable" },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create package" });
  }
});

// GET /api/packages/my/subscription — active subscription with entitlements
router.get("/my/subscription", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const sub = await query(
      `SELECT sub.*, p.name AS package_name, p.monthly_price, p.kb_plan_name
       FROM subscriptions sub
       JOIN packages p ON p.id = sub.package_id
       WHERE sub.user_id = $1 AND sub.status = 'ACTIVE'
       ORDER BY sub.started_at DESC LIMIT 1`,
      [req.userId]
    );
    if (!sub[0]) { res.json(null); return; }

    const entitlements = await query(
      `SELECT e.*, s.code, s.name, s.category
       FROM entitlements e
       JOIN services s ON s.id = e.service_id
       WHERE e.user_id = $1 AND e.subscription_id = $2`,
      [req.userId, sub[0].id]
    );

    const pendingDowngrade = await query(
      `SELECT sub.*, p.name AS package_name, p.monthly_price
       FROM subscriptions sub
       JOIN packages p ON p.id = sub.package_id
       WHERE sub.user_id = $1 AND sub.status = 'PENDING'
       ORDER BY sub.started_at DESC LIMIT 1`,
      [req.userId]
    );

    res.json({ ...sub[0], entitlements, pendingDowngrade: pendingDowngrade[0] || null });
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

export default router;
