import { Router, Response } from "express";
import { query } from "../db";
import { authMiddleware, AuthRequest } from "../middleware/auth";
import { syncServicesFromOdoo } from "../services/odoo";

const router = Router();

// GET /api/services — list all services with remaining from ACTIVE subscription only
router.get("/", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.userId!;

    // Get the single latest active subscription
    const activeSubs = await query<{ id: string }>(
      `SELECT id FROM subscriptions
       WHERE user_id = $1 AND status = 'ACTIVE'
       ORDER BY started_at DESC LIMIT 1`,
      [userId]
    );
    const activeSubId = activeSubs[0]?.id || null;

    const services = await query(
      `SELECT
         s.id,
         s.code,
         s.name,
         s.description,
         s.price,
         s.category,
         COALESCE(e.remaining, 0) AS remaining,
         COALESCE(e.total, 0)     AS total
       FROM services s
       LEFT JOIN entitlements e
         ON e.service_id = s.id
         AND e.user_id = $1
         AND e.subscription_id = $2
         AND e.remaining > 0
       WHERE s.is_active = TRUE
       ORDER BY s.category, s.name`,
      [userId, activeSubId]
    );

    res.json(services);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch services" });
  }
});

// POST /api/services/sync — sync prices from Odoo
router.post("/sync", async (_req, res: Response) => {
  try {
    await syncServicesFromOdoo();
    res.json({ message: "Sync complete" });
  } catch {
    res.status(500).json({ error: "Sync failed" });
  }
});

export default router;
