import { Router, Response } from "express";
import { query, queryOne } from "../db";
import { authMiddleware, AuthRequest } from "../middleware/auth";
import { createSubscription, cancelSubscription } from "../services/killbill";
import { createOrder, verifyPaymentSignature } from "../services/razorpay";
import { v4 as uuidv4 } from "uuid";

const router = Router();

// ─── helpers ────────────────────────────────────────────────────────────────

// Plan tier — higher number = higher tier
const PLAN_TIER: Record<string, number> = {
  SILVER_MONTHLY: 1,
  GOLD_MONTHLY:   2,
  PLATINUM_MONTHLY: 3,
};

function getTier(kbPlanName: string): number {
  return PLAN_TIER[kbPlanName] ?? 0;
}

// ─── GET /api/subscriptions/my ───────────────────────────────────────────────
// Returns active subscription + entitlements + pending downgrade info
router.get("/my", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const sub = await queryOne(
      `SELECT sub.*, p.name AS package_name, p.monthly_price, p.kb_plan_name
       FROM subscriptions sub
       JOIN packages p ON p.id = sub.package_id
       WHERE sub.user_id = $1 AND sub.status = 'ACTIVE'
       ORDER BY sub.started_at DESC LIMIT 1`,
      [req.userId]
    );

    if (!sub) { res.json(null); return; }

    const entitlements = await query(
      `SELECT e.*, s.code, s.name, s.category
       FROM entitlements e
       JOIN services s ON s.id = e.service_id
       WHERE e.user_id = $1 AND e.subscription_id = $2`,
      [req.userId, sub.id]
    );

    // Check if there is a pending downgrade scheduled
    const pendingDowngrade = await queryOne(
      `SELECT sub.*, p.name AS package_name, p.monthly_price
       FROM subscriptions sub
       JOIN packages p ON p.id = sub.package_id
       WHERE sub.user_id = $1 AND sub.status = 'PENDING'
       ORDER BY sub.started_at DESC LIMIT 1`,
      [req.userId]
    );

    res.json({ ...sub, entitlements, pendingDowngrade: pendingDowngrade || null });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed" });
  }
});

// ─── POST /api/subscriptions/order ──────────────────────────────────────────
router.post("/order", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { packageId } = req.body;
    const pkg = await queryOne<{ id: string; name: string; monthly_price: number; kb_plan_name: string }>(
      "SELECT * FROM packages WHERE id = $1 AND is_active = TRUE", [packageId]
    );
    if (!pkg) { res.status(404).json({ error: "Package not found" }); return; }

    const order = await createOrder(Number(pkg.monthly_price));
    res.json({ order, package: pkg });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// ─── POST /api/subscriptions/activate ───────────────────────────────────────
// Handles: first subscribe, upgrade (immediate), downgrade (scheduled)
router.post("/activate", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const { packageId, razorpayOrderId, razorpayPaymentId, razorpaySignature } = req.body;
    const userId = req.userId!;

    // 1. Verify payment
    const valid = verifyPaymentSignature(
      razorpayOrderId,
      razorpayPaymentId,
      razorpaySignature || "demo_sig"
    );
    if (!valid) { res.status(400).json({ error: "Invalid payment signature" }); return; }

    // 2. Get new package
    const newPkg = await queryOne<{ id: string; name: string; monthly_price: number; kb_plan_name: string }>(
      "SELECT * FROM packages WHERE id = $1", [packageId]
    );
    if (!newPkg) { res.status(404).json({ error: "Package not found" }); return; }

    const user = await queryOne<{ kb_account_id: string }>(
      "SELECT kb_account_id FROM users WHERE id = $1", [userId]
    );

    // 3. Get current active subscription if any
    const existing = await queryOne<{ id: string; kb_subscription_id: string; kb_plan_name: string; package_id: string }>(
      `SELECT sub.id, sub.kb_subscription_id, sub.package_id, p.kb_plan_name
       FROM subscriptions sub
       JOIN packages p ON p.id = sub.package_id
       WHERE sub.user_id = $1 AND sub.status = 'ACTIVE'
       ORDER BY sub.started_at DESC LIMIT 1`,
      [userId]
    );

    const newTier = getTier(newPkg.kb_plan_name);
    const oldTier = existing ? getTier(existing.kb_plan_name) : 0;

    // 4. Cancel any existing PENDING downgrade
    await query(
      "UPDATE subscriptions SET status = 'CANCELLED' WHERE user_id = $1 AND status = 'PENDING'",
      [userId]
    );

    // ── CASE A: No existing subscription → fresh subscribe ───────────────────
    if (!existing) {
      await activateImmediately({ userId, newPkg, user, razorpayOrderId, razorpayPaymentId });
      res.json({ message: "Subscription activated", type: "new" });
      return;
    }

    // ── CASE B: Upgrade (immediate) ──────────────────────────────────────────
    if (newTier > oldTier) {
      // Cancel old KB subscription immediately
      if (existing.kb_subscription_id) {
        try {
          await cancelSubscription(existing.kb_subscription_id, "IMMEDIATE");
          console.log(`[KB] Cancelled subscription ${existing.kb_subscription_id} immediately`);
        } catch (e: any) {
          console.error(`[KB] Cancel failed: ${e?.response?.data || e.message}`);
          // Still continue — KB may already be cancelled or in test mode
        }
      }

      // Zero out old entitlements
      await query(
        `UPDATE entitlements SET remaining = 0, updated_at = NOW()
         WHERE user_id = $1 AND subscription_id = $2`,
        [userId, existing.id]
      );

      // Mark old subscription cancelled
      await query(
        "UPDATE subscriptions SET status = 'CANCELLED' WHERE id = $1",
        [existing.id]
      );

      // Activate new plan immediately
      await activateImmediately({ userId, newPkg, user, razorpayOrderId, razorpayPaymentId });
      res.json({ message: `Upgraded to ${newPkg.name}`, type: "upgrade" });
      return;
    }

    // ── CASE C: Same plan → reject ───────────────────────────────────────────
    if (newTier === oldTier) {
      res.status(400).json({ error: "You are already on this plan" });
      return;
    }

    // ── CASE D: Downgrade → schedule for next renewal ────────────────────────
    if (newTier < oldTier) {
      // Create a PENDING subscription — activates when old one expires
      const subExtKey = `SUB_${uuidv4().slice(0, 8).toUpperCase()}`;
      await query(
        `INSERT INTO subscriptions
           (user_id, package_id, kb_subscription_id, kb_bundle_id, status, started_at)
         VALUES ($1, $2, NULL, $3, 'PENDING', NOW())`,
        [userId, newPkg.id, subExtKey]
      );

      // Log payment for scheduled downgrade
      await query(
        `INSERT INTO payments (user_id, razorpay_order_id, razorpay_payment_id, amount, status)
         VALUES ($1, $2, $3, $4, 'SUCCESS')`,
        [userId, razorpayOrderId, razorpayPaymentId, newPkg.monthly_price]
      );

      res.json({
        message: `Downgrade to ${newPkg.name} scheduled. Your current plan stays active until renewal.`,
        type: "downgrade",
      });
      return;
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Activation failed" });
  }
});

// ─── Helper: activate a subscription immediately ────────────────────────────
async function activateImmediately(params: {
  userId: string;
  newPkg: { id: string; name: string; monthly_price: number; kb_plan_name: string };
  user: { kb_account_id: string } | null;
  razorpayOrderId: string;
  razorpayPaymentId: string;
}) {
  const { userId, newPkg, user, razorpayOrderId, razorpayPaymentId } = params;

  // Create Kill Bill subscription
  let kbSubscriptionId: string | null = null;
  const subExtKey = `SUB_${uuidv4().slice(0, 8).toUpperCase()}`;
  const bundleExtKey = `BUNDLE_${uuidv4().slice(0, 8).toUpperCase()}`;

  if (user?.kb_account_id) {
    try {
      kbSubscriptionId = await createSubscription({
        accountId: user.kb_account_id,
        planName: newPkg.kb_plan_name,
        externalKey: subExtKey,
        bundleExternalKey: bundleExtKey,
      });
      console.log(`[KB] Created subscription ${kbSubscriptionId} for plan ${newPkg.kb_plan_name}`);
    } catch (e: any) {
      console.error(`[KB] Create subscription failed: ${e?.response?.data || e.message}`);
    }
  }

  // Insert subscription record
  const subs = await query<{ id: string }>(
    `INSERT INTO subscriptions
       (user_id, package_id, kb_subscription_id, kb_bundle_id, status, started_at)
     VALUES ($1, $2, $3, $4, 'ACTIVE', NOW())
     RETURNING id`,
    [userId, newPkg.id, kbSubscriptionId, bundleExtKey]
  );
  const subscriptionId = subs[0].id;

  // Grant fresh entitlements
  const items = await query<{ service_id: string; quantity: number }>(
    "SELECT service_id, quantity FROM package_items WHERE package_id = $1",
    [newPkg.id]
  );
  for (const item of items) {
    await query(
      `INSERT INTO entitlements (user_id, subscription_id, service_id, remaining, total)
       VALUES ($1, $2, $3, $4, $4)`,
      [userId, subscriptionId, item.service_id, item.quantity]
    );
  }

  // Log payment
  await query(
    `INSERT INTO payments (user_id, razorpay_order_id, razorpay_payment_id, amount, status)
     VALUES ($1, $2, $3, $4, 'SUCCESS')`,
    [userId, razorpayOrderId, razorpayPaymentId, newPkg.monthly_price]
  );

  return subscriptionId;
}

// ─── DELETE /api/subscriptions/:id — full cancel ────────────────────────────
router.delete("/:id", authMiddleware, async (req: AuthRequest, res: Response) => {
  try {
    const sub = await queryOne<{ id: string; user_id: string; kb_subscription_id: string }>(
      "SELECT * FROM subscriptions WHERE id = $1 AND user_id = $2",
      [req.params.id, req.userId]
    );
    if (!sub) { res.status(404).json({ error: "Subscription not found" }); return; }

    // Cancel in Kill Bill immediately
    if (sub.kb_subscription_id) {
      try {
        await cancelSubscription(sub.kb_subscription_id, "IMMEDIATE");
        console.log(`[KB] Cancelled subscription ${sub.kb_subscription_id}`);
      } catch (e: any) {
        console.error(`[KB] Cancel failed: ${e?.response?.data || e.message}`);
      }
    }

    // Mark cancelled + zero entitlements
    await query("UPDATE subscriptions SET status = 'CANCELLED' WHERE id = $1", [sub.id]);
    await query(
      "UPDATE entitlements SET remaining = 0, updated_at = NOW() WHERE user_id = $1 AND subscription_id = $2",
      [req.userId, sub.id]
    );

    // Also cancel any pending downgrade
    await query(
      "UPDATE subscriptions SET status = 'CANCELLED' WHERE user_id = $1 AND status = 'PENDING'",
      [req.userId]
    );

    res.json({ message: "Subscription cancelled" });
  } catch (err) {
    res.status(500).json({ error: "Cancellation failed" });
  }
});

// ─── POST /api/subscriptions/webhook/renewal ────────────────────────────────
// Kill Bill calls this on successful monthly renewal
router.post("/webhook/renewal", async (req, res) => {
  try {
    const { userId, subscriptionId } = req.body;

    // Check if there is a pending downgrade waiting
    const pendingDowngrade = await queryOne<{ id: string; package_id: string }>(
      "SELECT * FROM subscriptions WHERE user_id = $1 AND status = 'PENDING' ORDER BY started_at DESC LIMIT 1",
      [userId]
    );

    if (pendingDowngrade) {
      // Activate the pending downgrade now
      // 1. Zero out current active subscription entitlements
      await query(
        `UPDATE entitlements SET remaining = 0, updated_at = NOW()
         WHERE user_id = $1 AND subscription_id = $2`,
        [userId, subscriptionId]
      );
      // 2. Cancel old active subscription
      await query(
        "UPDATE subscriptions SET status = 'CANCELLED' WHERE id = $1",
        [subscriptionId]
      );
      // 3. Activate pending as new active
      await query(
        "UPDATE subscriptions SET status = 'ACTIVE', started_at = NOW() WHERE id = $1",
        [pendingDowngrade.id]
      );
      // 4. Grant fresh entitlements for new plan
      const items = await query<{ service_id: string; quantity: number }>(
        "SELECT service_id, quantity FROM package_items WHERE package_id = $1",
        [pendingDowngrade.package_id]
      );
      for (const item of items) {
        await query(
          `INSERT INTO entitlements (user_id, subscription_id, service_id, remaining, total)
           VALUES ($1, $2, $3, $4, $4)`,
          [userId, pendingDowngrade.id, item.service_id, item.quantity]
        );
      }
      res.json({ message: "Pending downgrade activated" });
    } else {
      // Normal renewal — reset entitlements to full
      const sub = await queryOne<{ package_id: string }>(
        "SELECT package_id FROM subscriptions WHERE id = $1", [subscriptionId]
      );
      if (sub) {
        const items = await query<{ service_id: string; quantity: number }>(
          "SELECT service_id, quantity FROM package_items WHERE package_id = $1",
          [sub.package_id]
        );
        for (const item of items) {
          await query(
            `UPDATE entitlements SET remaining = $1, total = $1, updated_at = NOW()
             WHERE user_id = $2 AND subscription_id = $3 AND service_id = $4`,
            [item.quantity, userId, subscriptionId, item.service_id]
          );
        }
      }
      res.json({ message: "Renewal processed" });
    }
  } catch {
    res.status(500).json({ error: "Webhook failed" });
  }
});

export default router;
