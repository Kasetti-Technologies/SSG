import axios, { AxiosInstance } from "axios";

const KB_URL = process.env.KILLBILL_URL || "http://localhost:8080";
const KB_API_KEY = process.env.KILLBILL_API_KEY || "bob";
const KB_API_SECRET = process.env.KILLBILL_API_SECRET || "lazar";
const KB_USERNAME = process.env.KILLBILL_USERNAME || "admin";
const KB_PASSWORD = process.env.KILLBILL_PASSWORD || "password";

function createKBClient(): AxiosInstance {
  return axios.create({
    baseURL: KB_URL,
    headers: {
      "Content-Type": "application/json",
      "X-Killbill-ApiKey": KB_API_KEY,
      "X-Killbill-ApiSecret": KB_API_SECRET,
      "X-Killbill-CreatedBy": "healthcare-backend",
    },
    auth: {
      username: KB_USERNAME,
      password: KB_PASSWORD,
    },
  });
}

export async function createKBAccount(params: {
  name: string;
  email: string;
  externalKey: string;
}) {
  const client = createKBClient();
  const res = await client.post("/1.0/kb/accounts", {
    name: params.name,
    externalKey: params.externalKey,
    email: params.email,
    currency: "INR",
    timeZone: "Asia/Kolkata",
    country: "IN",
    locale: "en_US",
  });
  // Kill Bill returns accountId in Location header
  const location = res.headers["location"] as string;
  const accountId = location?.split("/").pop() || "";
  return accountId;
}

export async function addDefaultPaymentMethod(accountId: string) {
  const client = createKBClient();
  const res = await client.post(
    `/1.0/kb/accounts/${accountId}/paymentMethods?isDefault=true`,
    {
      pluginName: "__EXTERNAL_PAYMENT__",
    }
  );
  const location = res.headers["location"] as string;
  return location?.split("/").pop() || "";
}

export async function createSubscription(params: {
  accountId: string;
  planName: string;
  externalKey: string;
  bundleExternalKey: string;
}) {
  const client = createKBClient();
  const res = await client.post("/1.0/kb/subscriptions", {
    accountId: params.accountId,
    externalKey: params.externalKey,
    bundleExternalKey: params.bundleExternalKey,
    planName: params.planName,
  });
  const location = res.headers["location"] as string;
  return location?.split("/").pop() || "";
}

export async function cancelSubscription(
  subscriptionId: string,
  policy: "IMMEDIATE" | "END_OF_TERM" = "IMMEDIATE"
) {
  const client = createKBClient();
  await client.delete(
    `/1.0/kb/subscriptions/${subscriptionId}?policy=${policy}&billingPolicy=${policy}`
  );
}

export async function getAccountInvoices(accountId: string) {
  const client = createKBClient();
  const res = await client.get(
    `/1.0/kb/accounts/${accountId}/invoices?withItems=true`
  );
  return res.data;
}

export async function uploadCatalog(catalogXml: string) {
  const client = createKBClient();
  await client.post("/1.0/kb/catalog/xml", catalogXml, {
    headers: { "Content-Type": "text/xml" },
  });
}

export async function ensurePlanExists(planName: string, price: number) {
  const catalogXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<catalog xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="https://docs.killbill.io/latest/catalog.xsd">
  <effectiveDate>${new Date().toISOString()}</effectiveDate>
  <catalogName>HEALTHCARE</catalogName>
  <currencies><currency>INR</currency></currencies>
  <products>
    <product name="${planName}"><category>BASE</category></product>
  </products>
  <rules>
    <changePolicy><changePolicyCase><policy>IMMEDIATE</policy></changePolicyCase></changePolicy>
    <cancelPolicy><cancelPolicyCase><policy>END_OF_TERM</policy></cancelPolicyCase></cancelPolicy>
    <billingAlignment><billingAlignmentCase><alignment>ACCOUNT</alignment></billingAlignmentCase></billingAlignment>
    <priceList><priceListCase><toPriceList>DEFAULT</toPriceList></priceListCase></priceList>
  </rules>
  <plans>
    <plan name="${planName}_MONTHLY">
      <product>${planName}</product>
      <recurringBillingMode>IN_ADVANCE</recurringBillingMode>
      <finalPhase type="EVERGREEN">
        <duration><unit>UNLIMITED</unit></duration>
        <recurring>
          <billingPeriod>MONTHLY</billingPeriod>
          <recurringPrice>
            <price><currency>INR</currency><value>${price.toFixed(2)}</value></price>
          </recurringPrice>
        </recurring>
      </finalPhase>
    </plan>
  </plans>
  <priceLists>
    <defaultPriceList name="DEFAULT">
      <plans><plan>${planName}_MONTHLY</plan></plans>
    </defaultPriceList>
  </priceLists>
</catalog>`;
  await uploadCatalog(catalogXml);
}
