import axios from "axios";

const ODOO_URL = process.env.ODOO_URL || "http://localhost:8069";
const ODOO_DB = process.env.ODOO_DB || "healthcare_odoo";
const ODOO_USER = process.env.ODOO_USER || "admin";
const ODOO_PASSWORD = process.env.ODOO_PASSWORD || "admin";

let cachedUid: number | null = null;

// ─── Core: login ─────────────────────────────────────────────────────────────
async function getUid(): Promise<number> {
  if (cachedUid) return cachedUid;

  const res = await axios.post(`${ODOO_URL}/jsonrpc`, {
    jsonrpc: "2.0",
    method: "call",
    id: 1,
    params: {
      service: "common",
      method: "login",
      args: [ODOO_DB, ODOO_USER, ODOO_PASSWORD],
    },
  });

  const uid = res.data?.result;
  if (!uid) throw new Error(`[Odoo] Login failed. DB=${ODOO_DB} USER=${ODOO_USER}`);

  cachedUid = uid;
  console.log(`[Odoo] Logged in — UID: ${uid}`);
  return uid;
}

// ─── Core: execute ────────────────────────────────────────────────────────────
async function execute(
  model: string,
  method: string,
  args: any[],
  kwargs: any = {}
): Promise<any> {
  const uid = await getUid();

  const res = await axios.post(`${ODOO_URL}/jsonrpc`, {
    jsonrpc: "2.0",
    method: "call",
    id: Date.now(),
    params: {
      service: "object",
      method: "execute_kw",
      args: [ODOO_DB, uid, ODOO_PASSWORD, model, method, args, kwargs],
    },
  });

  if (res.data?.error) {
    throw new Error(
      `[Odoo] ${model}.${method} failed: ${JSON.stringify(
        res.data.error.data?.message || res.data.error
      )}`
    );
  }

  return res.data?.result;
}

// ─── Check connection ─────────────────────────────────────────────────────────
export async function checkOdooConnection(): Promise<{ ok: boolean; message: string }> {
  try {
    cachedUid = null;
    const uid = await getUid();
    return { ok: true, message: `Connected — UID ${uid}` };
  } catch (err: any) {
    return { ok: false, message: err.message };
  }
}

// ─── PUSH: service → Odoo product ────────────────────────────────────────────
// No category used — works with base Odoo install
export async function pushServiceToOdoo(service: {
  code: string;
  name: string;
  description?: string;
  price: number;
  category: string;
}): Promise<{ odooId: number; action: "created" | "updated" }> {

  // Check if product already exists by internal reference code
  const existing = await execute(
    "product.template",
    "search_read",
    [[["default_code", "=", service.code]]],
    { fields: ["id", "name"], limit: 1 }
  );

  const data: any = {
    name: service.name,
    default_code: service.code,
    list_price: service.price,
    type: "service",
  };

  if (service.description) {
    data.description_sale = service.description;
  }

  if (existing?.length > 0) {
    await execute("product.template", "write", [[existing[0].id], data]);
    console.log(`[Odoo] Updated service ${service.code} id=${existing[0].id}`);
    return { odooId: existing[0].id, action: "updated" };
  } else {
    const id = await execute("product.template", "create", [data]);
    console.log(`[Odoo] Created service ${service.code} id=${id}`);
    return { odooId: id, action: "created" };
  }
}

// ─── PUSH: package → Odoo product ────────────────────────────────────────────
export async function pushPackageToOdoo(pkg: {
  name: string;
  monthly_price: number;
  description?: string;
}): Promise<{ odooId: number; action: "created" | "updated" }> {
  const code = `PKG_${pkg.name.toUpperCase().replace(/\s+/g, "_")}`;

  const existing = await execute(
    "product.template",
    "search_read",
    [[["default_code", "=", code]]],
    { fields: ["id"], limit: 1 }
  );

  const data: any = {
    name: pkg.name,
    default_code: code,
    list_price: pkg.monthly_price,
    type: "service",
  };

  if (pkg.description) {
    data.description_sale = pkg.description;
  }

  if (existing?.length > 0) {
    await execute("product.template", "write", [[existing[0].id], data]);
    console.log(`[Odoo] Updated package ${pkg.name} id=${existing[0].id}`);
    return { odooId: existing[0].id, action: "updated" };
  } else {
    const id = await execute("product.template", "create", [data]);
    console.log(`[Odoo] Created package ${pkg.name} id=${id}`);
    return { odooId: id, action: "created" };
  }
}

// ─── PUSH ALL: sync everything PostgreSQL → Odoo ──────────────────────────────
export async function pushAllToOdoo(
  services: any[],
  packages: any[]
): Promise<{
  services: { pushed: number; failed: number };
  packages: { pushed: number; failed: number };
}> {
  const result = {
    services: { pushed: 0, failed: 0 },
    packages: { pushed: 0, failed: 0 },
  };

  for (const svc of services) {
    try {
      await pushServiceToOdoo(svc);
      result.services.pushed++;
    } catch (e: any) {
      console.error(`[Odoo] Failed to push service ${svc.code}:`, e.message);
      result.services.failed++;
    }
  }

  for (const pkg of packages) {
    try {
      await pushPackageToOdoo(pkg);
      result.packages.pushed++;
    } catch (e: any) {
      console.error(`[Odoo] Failed to push package ${pkg.name}:`, e.message);
      result.packages.failed++;
    }
  }

  return result;
}

// ─── PULL: Odoo prices → PostgreSQL ──────────────────────────────────────────
export async function pullPricesFromOdoo(): Promise<{
  updated: number;
  skipped: number;
}> {
  // Pull all service-type products that have an internal reference code
  const products = await execute(
    "product.template",
    "search_read",
    [[["type", "=", "service"], ["default_code", "!=", false]]],
    { fields: ["id", "default_code", "list_price", "name"] }
  );

  if (!products?.length) {
    console.log("[Odoo] No products found");
    return { updated: 0, skipped: 0 };
  }

  const { query } = await import("../db");
  let updated = 0;
  let skipped = 0;

  for (const p of products) {
    if (!p.default_code) { skipped++; continue; }

    // Update service price if code matches
    const res = await query(
      `UPDATE services SET price = $1, updated_at = NOW()
       WHERE code = $2 RETURNING id`,
      [p.list_price, p.default_code]
    );
    if (res.length > 0) {
      updated++;
      console.log(`[Odoo] Pulled price for ${p.default_code}: ₹${p.list_price}`);
    } else {
      skipped++;
    }
  }

  console.log(`[Odoo] Pull complete — updated=${updated} skipped=${skipped}`);
  return { updated, skipped };
}
