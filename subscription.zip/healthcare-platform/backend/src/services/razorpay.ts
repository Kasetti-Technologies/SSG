import crypto from "crypto";

const RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID || "rzp_test_demo";
const RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || "demo_secret";

// For demo mode — simulate Razorpay without actual SDK calls
// In production, use the razorpay npm package

export async function createOrder(amount: number, currency = "INR") {
  // Demo: return a simulated order
  const orderId = `order_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  return {
    id: orderId,
    amount: Math.round(amount * 100), // paise
    currency,
    status: "created",
  };
}

export function verifyPaymentSignature(
  orderId: string,
  paymentId: string,
  signature: string
): boolean {
  // In demo mode, accept any payment
  if (
    RAZORPAY_KEY_SECRET === "demo_secret_456" ||
    RAZORPAY_KEY_SECRET === "demo_secret"
  ) {
    return true;
  }
  const body = `${orderId}|${paymentId}`;
  const expectedSig = crypto
    .createHmac("sha256", RAZORPAY_KEY_SECRET)
    .update(body)
    .digest("hex");
  return expectedSig === signature;
}
