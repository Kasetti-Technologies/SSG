#!/usr/bin/env node
// scripts/setup-killbill.js
// Run after Kill Bill is healthy: node scripts/setup-killbill.js

const http = require("http");

const KB_BASE = "http://localhost:8080";
const KB_API_KEY = "bob";
const KB_API_SECRET = "lazar";
const AUTH = Buffer.from("admin:password").toString("base64");

function request(method, path, body, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const url = new URL(KB_BASE + path);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${AUTH}`,
        "X-Killbill-ApiKey": KB_API_KEY,
        "X-Killbill-ApiSecret": KB_API_SECRET,
        "X-Killbill-CreatedBy": "setup-script",
        ...(data ? { "Content-Length": Buffer.byteLength(data) } : {}),
        ...extraHeaders,
      },
    };
    const req = http.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => {
        resolve({ status: res.statusCode, headers: res.headers, body });
      });
    });
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

function xmlRequest(method, path, xmlBody) {
  return new Promise((resolve, reject) => {
    const url = new URL(KB_BASE + path);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      method,
      headers: {
        "Content-Type": "text/xml",
        Authorization: `Basic ${AUTH}`,
        "X-Killbill-ApiKey": KB_API_KEY,
        "X-Killbill-ApiSecret": KB_API_SECRET,
        "X-Killbill-CreatedBy": "setup-script",
        "Content-Length": Buffer.byteLength(xmlBody),
      },
    };
    const req = http.request(options, (res) => {
      let body = "";
      res.on("data", (chunk) => (body += chunk));
      res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body }));
    });
    req.on("error", reject);
    req.write(xmlBody);
    req.end();
  });
}

async function waitForKillBill() {
  console.log("⏳ Waiting for Kill Bill to be ready...");
  for (let i = 0; i < 40; i++) {
    try {
      const res = await request("GET", "/1.0/healthcheck");
      if (res.status === 200) {
        console.log("✅ Kill Bill is ready!\n");
        return;
      }
    } catch {}
    process.stdout.write(".");
    await new Promise((r) => setTimeout(r, 5000));
  }
  throw new Error("Kill Bill did not become ready in time");
}

async function createTenant() {
  console.log("1️⃣  Creating tenant (bob/lazar)...");
  const res = await request("POST", "/1.0/kb/tenants", {
    apiKey: "bob",
    apiSecret: "lazar",
    externalKey: "healthcare-tenant",
  });
  if (res.status === 201) {
    console.log("   ✅ Tenant created");
  } else if (res.status === 409) {
    console.log("   ℹ️  Tenant already exists");
  } else {
    console.log(`   ⚠️  Status ${res.status}: ${res.body}`);
  }
}

async function uploadCatalog() {
  console.log("\n2️⃣  Uploading catalog...");

  const plans = [
    { product: "SILVER_PLAN", plan: "SILVER_MONTHLY", price: "1999.00" },
    { product: "GOLD_PLAN", plan: "GOLD_MONTHLY", price: "4999.00" },
    { product: "PLATINUM_PLAN", plan: "PLATINUM_MONTHLY", price: "8999.00" },
  ];

  const products = plans
    .map((p) => `<product name="${p.product}"><category>BASE</category></product>`)
    .join("\n    ");

  const planDefs = plans
    .map(
      (p) => `
    <plan name="${p.plan}">
      <product>${p.product}</product>
      <recurringBillingMode>IN_ADVANCE</recurringBillingMode>
      <finalPhase type="EVERGREEN">
        <duration><unit>UNLIMITED</unit></duration>
        <recurring>
          <billingPeriod>MONTHLY</billingPeriod>
          <recurringPrice>
            <price><currency>INR</currency><value>${p.price}</value></price>
          </recurringPrice>
        </recurring>
      </finalPhase>
    </plan>`
    )
    .join("\n");

  const planRefs = plans.map((p) => `<plan>${p.plan}</plan>`).join("\n      ");

  const catalogXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<catalog xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:noNamespaceSchemaLocation="https://docs.killbill.io/latest/catalog.xsd">
  <effectiveDate>${new Date().toISOString()}</effectiveDate>
  <catalogName>HEALTHCARE</catalogName>
  <currencies><currency>INR</currency></currencies>
  <products>
    ${products}
  </products>
  <rules>
    <changePolicy><changePolicyCase><policy>IMMEDIATE</policy></changePolicyCase></changePolicy>
    <cancelPolicy><cancelPolicyCase><policy>END_OF_TERM</policy></cancelPolicyCase></cancelPolicy>
    <billingAlignment><billingAlignmentCase><alignment>ACCOUNT</alignment></billingAlignmentCase></billingAlignment>
    <priceList><priceListCase><toPriceList>DEFAULT</toPriceList></priceListCase></priceList>
  </rules>
  <plans>${planDefs}
  </plans>
  <priceLists>
    <defaultPriceList name="DEFAULT">
      <plans>
        ${planRefs}
      </plans>
    </defaultPriceList>
  </priceLists>
</catalog>`;

  const res = await xmlRequest("POST", "/1.0/kb/catalog/xml", catalogXml);
  if (res.status === 201 || res.status === 200) {
    console.log("   ✅ Catalog uploaded (Silver, Gold, Platinum plans)");
  } else {
    console.log(`   ⚠️  Catalog upload status ${res.status}: ${res.body.slice(0, 200)}`);
  }
}

async function main() {
  console.log("🏥 Kill Bill Setup Script\n");
  try {
    await waitForKillBill();
    await createTenant();
    await uploadCatalog();
    console.log("\n🎉 Kill Bill setup complete!");
    console.log("   KAUI UI: http://localhost:9090");
    console.log("   Login: admin / password\n");
  } catch (err) {
    console.error("\n❌ Setup failed:", err.message);
    process.exit(1);
  }
}

main();
