#!/usr/bin/env node
// Waits for Odoo to be ready and resets admin password to "admin"

const http = require("http");

function post(path, body) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const options = {
      hostname: "localhost",
      port: 8069,
      path,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(data),
      },
    };
    const req = http.request(options, (res) => {
      let result = "";
      res.on("data", (chunk) => (result += chunk));
      res.on("end", () => {
        try { resolve(JSON.parse(result)); }
        catch { resolve(result); }
      });
    });
    req.on("error", reject);
    req.write(data);
    req.end();
  });
}

async function waitForOdoo() {
  console.log("⏳ Waiting for Odoo to be ready...");
  for (let i = 0; i < 60; i++) {
    try {
      // Check if DB exists
      const res = await post("/jsonrpc", {
        jsonrpc: "2.0", method: "call", id: 1,
        params: { service: "db", method: "list", args: [] },
      });
      if (res.result && res.result.includes("healthcare_odoo")) {
        console.log("✅ Odoo database ready!");
        return true;
      }
    } catch {}
    process.stdout.write(".");
    await new Promise((r) => setTimeout(r, 5000));
  }
  return false;
}

async function tryLogin(password) {
  const res = await post("/jsonrpc", {
    jsonrpc: "2.0", method: "call", id: 1,
    params: {
      service: "common", method: "login",
      args: ["healthcare_odoo", "admin", password],
    },
  });
  return res.result && res.result !== false ? res.result : null;
}

async function resetAdminPassword() {
  // Try common passwords
  const passwords = ["admin", "admin1", "Administrator", "odoo", "1234"];
  for (const pwd of passwords) {
    const uid = await tryLogin(pwd);
    if (uid) {
      console.log(`\n✅ Odoo login successful with password: ${pwd} (UID: ${uid})`);
      if (pwd !== "admin") {
        console.log("   Resetting password to 'admin'...");
        // Use the working credentials to reset password
        const res = await post("/jsonrpc", {
          jsonrpc: "2.0", method: "call", id: 2,
          params: {
            service: "object", method: "execute_kw",
            args: ["healthcare_odoo", uid, pwd, "res.users", "write",
              [[uid], { password: "admin" }]],
          },
        });
        if (res.result) console.log("   ✅ Password reset to 'admin'");
      }
      return true;
    }
  }
  return false;
}

async function main() {
  console.log("\n🏢 Odoo Setup Script\n");
  const ready = await waitForOdoo();
  if (!ready) {
    console.log("\n⚠️  Odoo not ready in time — you may need to set it up manually");
    process.exit(0);
  }

  // Give Odoo a moment to fully initialize
  await new Promise((r) => setTimeout(r, 3000));

  const ok = await resetAdminPassword();
  if (!ok) {
    console.log("\n⚠️  Could not auto-login. Please set admin password manually at localhost:8069");
  }

  console.log("\n🎉 Odoo setup complete!");
  console.log("   URL:      http://localhost:8069");
  console.log("   Login:    admin");
  console.log("   Password: admin\n");
}

main().catch(console.error);
