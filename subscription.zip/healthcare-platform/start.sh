#!/bin/bash
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   🏥 HealthCare+ Platform Startup        ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════╝${NC}"
echo ""

command -v docker >/dev/null 2>&1 || { echo "❌ Docker not found."; exit 1; }
command -v node >/dev/null 2>&1 || { echo "❌ Node.js not found."; exit 1; }

echo -e "${YELLOW}Step 1: Starting all Docker services...${NC}"
docker compose up -d --build
echo -e "${GREEN}✅ Docker services started${NC}"

echo ""
echo -e "${YELLOW}Step 2: Waiting for PostgreSQL...${NC}"
until docker exec postgres pg_isready -U admin -d healthcare >/dev/null 2>&1; do
  sleep 2
  echo -n "."
done
echo -e "\n${GREEN}✅ PostgreSQL ready${NC}"

echo ""
echo -e "${YELLOW}Step 3: Setting up Kill Bill (this takes ~2 minutes)...${NC}"
node scripts/setup-killbill.js
echo -e "${GREEN}✅ Kill Bill configured${NC}"

echo ""
echo -e "${YELLOW}Step 4: Setting up Odoo (this takes ~3 minutes)...${NC}"
node scripts/setup-odoo.js
echo -e "${GREEN}✅ Odoo configured${NC}"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   🎉 Platform is ready!                  ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BLUE}👤 User App${NC}      →  http://localhost:3000"
echo -e "  ${BLUE}🔧 Admin App${NC}     →  http://localhost:3002"
echo -e "  ${BLUE}🔌 Backend API${NC}   →  http://localhost:3001"
echo -e "  ${BLUE}📊 Kill Bill UI${NC}  →  http://localhost:9090  (admin/password)"
echo -e "  ${BLUE}🏢 Odoo ERP${NC}      →  http://localhost:8069  (admin/admin)"
echo -e "  ${BLUE}📖 API Docs${NC}      →  http://localhost:8080/api.html"
echo ""
echo -e "${YELLOW}To stop:   docker compose down${NC}"
echo -e "${YELLOW}To reset:  docker compose down -v && ./start.sh${NC}"
echo ""
