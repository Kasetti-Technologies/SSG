"use client";
import { useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault(); setError(""); setLoading(true);
    try { await login(form.email, form.password); router.push("/dashboard"); }
    catch (err: any) { setError(err.message); }
    finally { setLoading(false); }
  }

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg, #0f172a 0%, #134e4a 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: 24, fontFamily: "'Sora', sans-serif" }}>
      <div style={{ background: "rgba(255,255,255,0.04)", backdropFilter: "blur(24px)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 24, padding: "40px 36px", width: "100%", maxWidth: 420 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🏥</div>
          <h1 style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800, margin: 0 }}>Welcome back</h1>
          <p style={{ color: "#64748b", marginTop: 8, fontSize: 14 }}>Sign in to HealthCare+</p>
        </div>
        {error && <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", borderRadius: 10, padding: "10px 14px", fontSize: 13, marginBottom: 20 }}>{error}</div>}
        <form onSubmit={handleSubmit}>
          {[{ key: "email", label: "Email", type: "email", ph: "you@example.com" }, { key: "password", label: "Password", type: "password", ph: "••••••••" }].map(({ key, label, type, ph }) => (
            <div key={key} style={{ marginBottom: 16 }}>
              <label style={{ display: "block", color: "#94a3b8", fontSize: 13, fontWeight: 500, marginBottom: 6 }}>{label}</label>
              <input type={type} value={(form as any)[key]} onChange={e => setForm({ ...form, [key]: e.target.value })} required placeholder={ph}
                style={{ width: "100%", padding: "12px 14px", borderRadius: 10, border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.05)", color: "#f1f5f9", fontSize: 15, outline: "none", boxSizing: "border-box" }} />
            </div>
          ))}
          <button type="submit" disabled={loading}
            style={{ width: "100%", padding: "13px", borderRadius: 12, fontWeight: 700, fontSize: 16, background: loading ? "#1e3a35" : "linear-gradient(135deg, #0d9488, #0891b2)", color: "#fff", border: "none", cursor: "pointer", marginTop: 8, transition: "opacity 0.15s" }}>
            {loading ? "Signing in…" : "Sign In"}
          </button>
        </form>
        <div style={{ marginTop: 16, padding: "12px 14px", background: "rgba(20,184,166,0.08)", border: "1px solid rgba(20,184,166,0.2)", borderRadius: 10, fontSize: 13, color: "#5eead4" }}>
          💡 Demo: register a new account to try the full flow
        </div>
        <p style={{ textAlign: "center", color: "#475569", fontSize: 14, marginTop: 24 }}>
          No account? <Link href="/auth/register" style={{ color: "#2dd4bf", fontWeight: 600, textDecoration: "none" }}>Create one</Link>
        </p>
      </div>
    </div>
  );
}
