"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";
import Link from "next/link";

const catIcon: Record<string, string> = { Radiology: "🔬", Pathology: "🧪", Cardiology: "❤️" };

export default function BookingsPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.push("/auth/login"); return; }
    api.bookings.myBookings().then(setBookings).catch(console.error).finally(() => setLoading(false));
  }, [user]);

  return (
    <div style={{ minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Navbar />
      <div style={{ maxWidth: 860, margin: "0 auto", padding: "36px 24px" }}>
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 28, fontWeight: 800, margin: 0 }}>My Bookings</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>{bookings.length} total bookings</p>
        </div>

        {loading ? (
          <div style={{ textAlign: "center", color: "#2dd4bf", padding: 60 }}>Loading…</div>
        ) : bookings.length === 0 ? (
          <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: "64px 24px", textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📅</div>
            <div style={{ color: "#f1f5f9", fontSize: 20, fontWeight: 700, marginBottom: 8 }}>No bookings yet</div>
            <p style={{ color: "#475569", marginBottom: 24 }}>Book your first diagnostic service</p>
            <Link href="/services" style={{ display: "inline-block", padding: "12px 28px", borderRadius: 12, background: "linear-gradient(135deg,#0d9488,#0891b2)", color: "#fff", fontWeight: 700, textDecoration: "none" }}>
              Browse Services
            </Link>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {bookings.map((b: any) => (
              <div key={b.id} style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 16, padding: "18px 22px", display: "flex", alignItems: "center", gap: 18, justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                  <div style={{ width: 48, height: 48, borderRadius: 14, background: "rgba(255,255,255,0.05)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
                    {catIcon[b.category] || "🏥"}
                  </div>
                  <div>
                    <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 15 }}>{b.service_name}</div>
                    <div style={{ color: "#475569", fontSize: 12, marginTop: 3 }}>
                      {new Date(b.booked_at).toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "long", year: "numeric" })}
                    </div>
                    <div style={{ color: "#334155", fontSize: 11, marginTop: 2 }}>{b.category}</div>
                  </div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  {b.covered_by_plan ? (
                    <span style={{ background: "rgba(13,148,136,0.2)", color: "#2dd4bf", fontSize: 12, fontWeight: 700, padding: "5px 14px", borderRadius: 999, border: "1px solid rgba(45,212,191,0.25)" }}>
                      Covered
                    </span>
                  ) : (
                    <div style={{ color: "#f1f5f9", fontWeight: 800, fontSize: 18 }}>₹{b.amount_paid}</div>
                  )}
                  <div style={{ color: b.status === "CONFIRMED" ? "#4ade80" : "#64748b", fontSize: 11, marginTop: 4, fontWeight: 600 }}>
                    {b.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
