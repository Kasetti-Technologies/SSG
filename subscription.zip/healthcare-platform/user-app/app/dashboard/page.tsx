"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";
import Link from "next/link";

const C = {
  page: { minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" } as React.CSSProperties,
  main: { maxWidth: 1100, margin: "0 auto", padding: "36px 24px" } as React.CSSProperties,
  h1: { color: "#f1f5f9", fontSize: 28, fontWeight: 800, margin: 0 } as React.CSSProperties,
  sub: { color: "#475569", fontSize: 14, marginTop: 6 } as React.CSSProperties,
  card: { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 20, padding: 24 } as React.CSSProperties,
};

export default function DashboardPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [subscription, setSubscription] = useState<any>(null);
  const [bookings, setBookings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { router.push("/auth/login"); return; }
    Promise.all([
      api.packages.mySubscription().catch(() => null),
      api.bookings.myBookings().catch(() => []),
    ]).then(([sub, bks]) => { setSubscription(sub); setBookings(bks.slice(0, 5)); }).finally(() => setLoading(false));
  }, [user]);

  if (loading) return <div style={{ ...C.page, display: "flex", alignItems: "center", justifyContent: "center" }}><span style={{ color: "#2dd4bf", fontSize: 18 }}>Loading…</span></div>;

  return (
    <div style={C.page}>
      <Navbar />
      <div style={C.main}>
        {/* Header */}
        <div style={{ marginBottom: 32 }}>
          <h1 style={C.h1}>Welcome back, {user?.name?.split(" ")[0]} 👋</h1>
          <p style={C.sub}>Here's your health dashboard</p>
        </div>

        {/* Active subscription card */}
        {subscription ? (
          <div style={{ background: "linear-gradient(135deg, #0d9488 0%, #0891b2 100%)", borderRadius: 24, padding: "28px 32px", marginBottom: 28, position: "relative", overflow: "hidden" }}>
            <div style={{ position: "absolute", top: -40, right: -40, width: 200, height: 200, background: "rgba(255,255,255,0.06)", borderRadius: "50%" }} />
            <div style={{ position: "absolute", bottom: -60, right: 40, width: 150, height: 150, background: "rgba(255,255,255,0.04)", borderRadius: "50%" }} />
            <div style={{ position: "relative" }}>
              <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 6 }}>Active Plan</div>
              <div style={{ color: "#fff", fontSize: 30, fontWeight: 800, marginBottom: 4 }}>{subscription.package_name}</div>
              <div style={{ color: "rgba(255,255,255,0.65)", fontSize: 15, marginBottom: 24 }}>₹{subscription.monthly_price} / month</div>
              {subscription.entitlements?.length > 0 && (
                <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                  {subscription.entitlements.map((e: any) => (
                    <div key={e.id} style={{ background: "rgba(255,255,255,0.15)", borderRadius: 12, padding: "10px 16px", textAlign: "center", minWidth: 90 }}>
                      <div style={{ color: "#fff", fontSize: 24, fontWeight: 800, lineHeight: 1 }}>{e.remaining}</div>
                      <div style={{ color: "rgba(255,255,255,0.7)", fontSize: 11, marginTop: 4 }}>{e.name}</div>
                      <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 10 }}>of {e.total}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div style={{ ...C.card, borderStyle: "dashed", textAlign: "center", padding: "48px 24px", marginBottom: 28 }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📋</div>
            <div style={{ color: "#f1f5f9", fontSize: 20, fontWeight: 700, marginBottom: 8 }}>No Active Subscription</div>
            <div style={{ color: "#475569", fontSize: 15, marginBottom: 24 }}>Subscribe to a plan to get covered diagnostics</div>
            <Link href="/plans" style={{ display: "inline-block", padding: "12px 28px", borderRadius: 12, background: "linear-gradient(135deg, #0d9488, #0891b2)", color: "#fff", fontWeight: 700, fontSize: 15, textDecoration: "none" }}>
              View Plans →
            </Link>
          </div>
        )}

        {/* Quick actions */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 16, marginBottom: 28 }}>
          {[
            { href: "/services", icon: "🔬", label: "Book a Service", color: "#0d9488" },
            { href: "/plans", icon: "💎", label: "View Plans", color: "#7c3aed" },
            { href: "/bookings", icon: "📅", label: "My Bookings", color: "#0891b2" },
            { href: "/services", icon: "🧪", label: "Blood Tests", color: "#d97706" },
          ].map(({ href, icon, label, color }) => (
            <Link key={label} href={href} style={{ ...C.card, textAlign: "center", padding: "22px 16px", textDecoration: "none", cursor: "pointer", transition: "transform 0.15s, border-color 0.15s", display: "block" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = color; (e.currentTarget as HTMLElement).style.transform = "translateY(-2px)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = "rgba(255,255,255,0.08)"; (e.currentTarget as HTMLElement).style.transform = "none"; }}>
              <div style={{ fontSize: 28, marginBottom: 10 }}>{icon}</div>
              <div style={{ color: "#cbd5e1", fontSize: 14, fontWeight: 600 }}>{label}</div>
            </Link>
          ))}
        </div>

        {/* Recent bookings */}
        {bookings.length > 0 && (
          <div style={C.card}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <div style={{ color: "#f1f5f9", fontSize: 17, fontWeight: 700 }}>Recent Bookings</div>
              <Link href="/bookings" style={{ color: "#2dd4bf", fontSize: 13, fontWeight: 600, textDecoration: "none" }}>View all →</Link>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {bookings.map((b: any) => (
                <div key={b.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(255,255,255,0.03)", borderRadius: 12, padding: "14px 16px", border: "1px solid rgba(255,255,255,0.05)" }}>
                  <div>
                    <div style={{ color: "#e2e8f0", fontWeight: 600, fontSize: 14 }}>{b.service_name}</div>
                    <div style={{ color: "#475569", fontSize: 12, marginTop: 3 }}>{new Date(b.booked_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</div>
                  </div>
                  {b.covered_by_plan
                    ? <span style={{ background: "rgba(13,148,136,0.2)", color: "#2dd4bf", fontSize: 12, fontWeight: 600, padding: "4px 12px", borderRadius: 999, border: "1px solid rgba(45,212,191,0.2)" }}>Covered</span>
                    : <span style={{ color: "#f1f5f9", fontWeight: 700 }}>₹{b.amount_paid}</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
