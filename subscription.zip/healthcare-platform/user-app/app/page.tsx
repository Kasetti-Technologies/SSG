"use client";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import Link from "next/link";

const s = {
  page: { minHeight: "100vh", background: "linear-gradient(135deg, #0f172a 0%, #134e4a 50%, #0f172a 100%)", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px", fontFamily: "'Sora', sans-serif" } as React.CSSProperties,
  wrap: { textAlign: "center" as const, maxWidth: 680 },
  badge: { display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(20,184,166,0.15)", border: "1px solid rgba(20,184,166,0.3)", color: "#5eead4", padding: "6px 16px", borderRadius: 999, fontSize: 13, fontWeight: 500, marginBottom: 32 },
  dot: { width: 8, height: 8, background: "#14b8a6", borderRadius: "50%", animation: "pulse 2s infinite" },
  h1: { fontSize: "clamp(2.2rem, 6vw, 4rem)", fontWeight: 800, color: "#fff", lineHeight: 1.1, marginBottom: 20 },
  accent: { color: "#2dd4bf" },
  sub: { color: "#94a3b8", fontSize: 18, lineHeight: 1.7, marginBottom: 40, maxWidth: 500, margin: "0 auto 40px" },
  btnRow: { display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" as const, marginBottom: 64 },
  btnPrimary: { padding: "14px 32px", borderRadius: 12, fontWeight: 700, fontSize: 16, background: "linear-gradient(135deg, #0d9488, #0891b2)", color: "#fff", border: "none", cursor: "pointer", textDecoration: "none", display: "inline-block", transition: "transform 0.15s, box-shadow 0.15s", boxShadow: "0 4px 24px rgba(13,148,136,0.35)" },
  btnSecondary: { padding: "14px 32px", borderRadius: 12, fontWeight: 700, fontSize: 16, background: "transparent", color: "#2dd4bf", border: "1.5px solid rgba(45,212,191,0.4)", cursor: "pointer", textDecoration: "none", display: "inline-block", transition: "transform 0.15s" },
  grid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 },
  card: { background: "rgba(255,255,255,0.05)", backdropFilter: "blur(12px)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 16, padding: "24px 20px", textAlign: "center" as const },
  cardIcon: { fontSize: 32, marginBottom: 10 },
  cardTitle: { color: "#f1f5f9", fontWeight: 600, fontSize: 15 },
  cardSub: { color: "#64748b", fontSize: 13, marginTop: 4 },
};

export default function Home() {
  const { user } = useAuth();
  const router = useRouter();
  useEffect(() => { if (user) router.push("/dashboard"); }, [user, router]);

  return (
    <main style={s.page}>
      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }`}</style>
      <div style={s.wrap}>
        <div style={s.badge}>
          <span style={s.dot} />
          Healthcare Subscription Platform
        </div>
        <h1 style={s.h1}>Your Health,<br /><span style={s.accent}>Fully Covered.</span></h1>
        <p style={s.sub}>Subscribe to a plan. Book MRI scans, CT scans, blood tests and more — all covered by your monthly subscription.</p>
        <div style={s.btnRow}>
          <Link href="/auth/login" style={s.btnPrimary}>Sign In</Link>
          <Link href="/auth/register" style={s.btnSecondary}>Get Started →</Link>
        </div>
        <div style={s.grid}>
          {[{ icon: "🔬", label: "MRI & CT Scans", sub: "Brain, Heart, Chest" }, { icon: "🧪", label: "Blood Tests", sub: "Full panel & more" }, { icon: "❤️", label: "Cardiology", sub: "ECG & diagnostics" }].map(({ icon, label, sub }) => (
            <div key={label} style={s.card}>
              <div style={s.cardIcon}>{icon}</div>
              <div style={s.cardTitle}>{label}</div>
              <div style={s.cardSub}>{sub}</div>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
