"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

const PLAN_TIER: Record<string, number> = {
  SILVER_MONTHLY: 1,
  GOLD_MONTHLY: 2,
  PLATINUM_MONTHLY: 3,
};

const planMeta: Record<string, { icon: string; color: string; grad: string }> = {
  "Silver Plan":   { icon: "🥈", color: "#94a3b8", grad: "linear-gradient(135deg,#475569,#64748b)" },
  "Gold Plan":     { icon: "🥇", color: "#f59e0b", grad: "linear-gradient(135deg,#d97706,#f59e0b)" },
  "Platinum Plan": { icon: "💎", color: "#a78bfa", grad: "linear-gradient(135deg,#7c3aed,#a78bfa)" },
};

export default function PlansPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [plans, setPlans] = useState<any[]>([]);
  const [currentSub, setCurrentSub] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: string; text: string } | null>(null);

  useEffect(() => {
    if (!user) { router.push("/auth/login"); return; }
    loadData();
  }, [user]);

  async function loadData() {
    setLoading(true);
    const [p, s] = await Promise.all([
      api.packages.list(),
      api.packages.mySubscription().catch(() => null),
    ]);
    setPlans(p);
    setCurrentSub(s);
    setLoading(false);
  }

  function showToast(type: string, text: string) {
    setToast({ type, text });
    setTimeout(() => setToast(null), 5000);
  }

  async function handleAction(plan: any) {
    setBusy(plan.id);
    try {
      const { order } = await api.subscriptions.createOrder(plan.id);
      const result = await api.subscriptions.activate({
        packageId: plan.id,
        razorpayOrderId: order.id,
        razorpayPaymentId: `pay_demo_${Date.now()}`,
        razorpaySignature: "demo_signature",
      });
      showToast("success", result.message);
      await loadData();
    } catch (err: any) {
      showToast("error", err.message);
    } finally {
      setBusy(null);
    }
  }

  async function handleCancel() {
    if (!currentSub || !confirm("Cancel your subscription? All remaining entitlements will be lost immediately.")) return;
    try {
      await api.subscriptions.cancel(currentSub.id);
      showToast("success", "Subscription cancelled successfully.");
      setCurrentSub(null);
      await loadData();
    } catch (err: any) {
      showToast("error", err.message);
    }
  }

  // Determine button label + style for each plan
  function getPlanAction(plan: any) {
    if (!currentSub) return { label: "Subscribe Now", style: "primary", disabled: false };

    const currentTier = PLAN_TIER[currentSub.kb_plan_name] ?? 0;
    const planTier = PLAN_TIER[plan.kb_plan_name] ?? 0;

    if (plan.id === currentSub.package_id) return { label: "Current Plan", style: "current", disabled: true };
    if (planTier > currentTier) return { label: "⬆ Upgrade Now", style: "upgrade", disabled: false };
    if (planTier < currentTier) return { label: "⬇ Downgrade at Renewal", style: "downgrade", disabled: false };
    return { label: "Subscribe Now", style: "primary", disabled: false };
  }

  if (loading) return (
    <div style={{ minHeight: "100vh", background: "#0b1120", display: "flex", alignItems: "center", justifyContent: "center", color: "#2dd4bf", fontFamily: "'Sora', sans-serif", fontSize: 18 }}>Loading…</div>
  );

  const btnStyles: Record<string, React.CSSProperties> = {
    primary:   { background: "linear-gradient(135deg,#0d9488,#0891b2)", color: "#fff", border: "none" },
    upgrade:   { background: "linear-gradient(135deg,#7c3aed,#a78bfa)", color: "#fff", border: "none" },
    downgrade: { background: "transparent", color: "#f59e0b", border: "1.5px solid rgba(245,158,11,0.4)" },
    current:   { background: "rgba(13,148,136,0.15)", color: "#2dd4bf", border: "1px solid rgba(45,212,191,0.3)" },
  };

  return (
    <div style={{ minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" }}>
      <Navbar />

      {toast && (
        <div style={{ position: "fixed", top: 80, right: 24, zIndex: 100, maxWidth: 400,
          background: toast.type === "success" ? "rgba(13,148,136,0.97)" : "rgba(220,38,38,0.97)",
          color: "#fff", padding: "14px 20px", borderRadius: 14, fontSize: 14, fontWeight: 600,
          boxShadow: "0 8px 32px rgba(0,0,0,0.4)" }}>
          {toast.text}
        </div>
      )}

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "48px 24px" }}>
        <div style={{ textAlign: "center", marginBottom: 48 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 36, fontWeight: 800, margin: 0 }}>Your Plans</h1>
          <p style={{ color: "#475569", marginTop: 10, fontSize: 16 }}>Upgrade anytime · Downgrade at renewal · Cancel anytime</p>
        </div>

        {/* Active plan banner */}
        {currentSub && (
          <div style={{ background: "linear-gradient(135deg, rgba(13,148,136,0.15), rgba(8,145,178,0.1))", border: "1px solid rgba(45,212,191,0.2)", borderRadius: 20, padding: "20px 28px", marginBottom: 36, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 16 }}>
            <div>
              <div style={{ color: "#2dd4bf", fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 4 }}>Active Plan</div>
              <div style={{ color: "#f1f5f9", fontWeight: 800, fontSize: 20 }}>{currentSub.package_name}</div>
              <div style={{ color: "#475569", fontSize: 14, marginTop: 2 }}>₹{currentSub.monthly_price}/month</div>
            </div>
            {/* Pending downgrade badge */}
            {currentSub.pendingDowngrade && (
              <div style={{ background: "rgba(245,158,11,0.12)", border: "1px solid rgba(245,158,11,0.3)", borderRadius: 12, padding: "10px 16px", textAlign: "center" }}>
                <div style={{ color: "#f59e0b", fontSize: 12, fontWeight: 700 }}>⏳ Downgrade Scheduled</div>
                <div style={{ color: "#d97706", fontSize: 13, marginTop: 2 }}>{currentSub.pendingDowngrade.package_name} starts at next renewal</div>
              </div>
            )}
            <button onClick={handleCancel}
              style={{ padding: "9px 20px", borderRadius: 12, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.3)", color: "#f87171", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
              Cancel Plan
            </button>
          </div>
        )}

        {/* Rules explainer */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 40 }}>
          {[
            { icon: "⬆", label: "Upgrade", desc: "Immediate. Old plan cancelled, new entitlements granted now.", color: "#a78bfa" },
            { icon: "⬇", label: "Downgrade", desc: "Scheduled. Current plan stays active until renewal date.", color: "#f59e0b" },
            { icon: "✕", label: "Cancel", desc: "Immediate. All remaining entitlements lost instantly.", color: "#f87171" },
          ].map(({ icon, label, desc, color }) => (
            <div key={label} style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 14, padding: "16px 18px" }}>
              <div style={{ color, fontSize: 18, marginBottom: 6 }}>{icon} <span style={{ fontWeight: 700, fontSize: 14 }}>{label}</span></div>
              <div style={{ color: "#475569", fontSize: 12, lineHeight: 1.5 }}>{desc}</div>
            </div>
          ))}
        </div>

        {/* Plan cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 20 }}>
          {plans.map(plan => {
            const meta = planMeta[plan.name] || { icon: "⭐", color: "#2dd4bf", grad: "linear-gradient(135deg,#0d9488,#0891b2)" };
            const { label, style, disabled } = getPlanAction(plan);
            const isGold = plan.name === "Gold Plan";
            const isCurrent = style === "current";

            return (
              <div key={plan.id} style={{ background: "rgba(255,255,255,0.04)", border: `2px solid ${isCurrent ? "rgba(45,212,191,0.4)" : isGold ? meta.color + "44" : "rgba(255,255,255,0.08)"}`, borderRadius: 24, padding: "32px 28px", position: "relative", display: "flex", flexDirection: "column" }}>
                {isGold && !isCurrent && (
                  <div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: meta.grad, color: "#fff", fontSize: 11, fontWeight: 800, padding: "4px 14px", borderRadius: 999, letterSpacing: "0.08em", whiteSpace: "nowrap" }}>
                    MOST POPULAR
                  </div>
                )}
                {isCurrent && (
                  <div style={{ position: "absolute", top: -14, left: "50%", transform: "translateX(-50%)", background: "linear-gradient(135deg,#0d9488,#0891b2)", color: "#fff", fontSize: 11, fontWeight: 800, padding: "4px 14px", borderRadius: 999, whiteSpace: "nowrap" }}>
                    ✅ YOUR PLAN
                  </div>
                )}

                <div style={{ fontSize: 36, marginBottom: 12 }}>{meta.icon}</div>
                <div style={{ color: "#f1f5f9", fontSize: 22, fontWeight: 800, marginBottom: 6 }}>{plan.name}</div>
                <div style={{ color: "#475569", fontSize: 14, marginBottom: 20, lineHeight: 1.5 }}>{plan.description}</div>
                <div style={{ marginBottom: 24 }}>
                  <span style={{ color: meta.color, fontSize: 40, fontWeight: 800 }}>₹{plan.monthly_price}</span>
                  <span style={{ color: "#475569", fontSize: 14 }}>/month</span>
                </div>

                <div style={{ flex: 1, marginBottom: 24 }}>
                  {plan.items?.map((item: any) => (
                    <div key={item.service_code} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
                      <span style={{ color: "#2dd4bf" }}>✓</span>
                      <span style={{ color: "#cbd5e1", fontSize: 14 }}>{item.quantity}× {item.service_name}</span>
                    </div>
                  ))}
                </div>

                <button onClick={() => !disabled && handleAction(plan)}
                  disabled={disabled || busy === plan.id}
                  style={{ padding: "13px", borderRadius: 14, fontWeight: 800, fontSize: 15, cursor: disabled ? "default" : busy === plan.id ? "not-allowed" : "pointer", opacity: busy === plan.id ? 0.6 : 1, transition: "opacity 0.15s", ...btnStyles[style] }}>
                  {busy === plan.id ? "Processing…" : label}
                </button>
              </div>
            );
          })}
        </div>

        <p style={{ textAlign: "center", color: "#1e293b", fontSize: 13, marginTop: 32 }}>
          Demo mode — payments are simulated. No real charges.
        </p>
      </div>
    </div>
  );
}
