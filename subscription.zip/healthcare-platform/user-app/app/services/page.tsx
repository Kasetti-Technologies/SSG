"use client";
import { useEffect, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

const catIcon: Record<string, string> = { Radiology: "🔬", Pathology: "🧪", Cardiology: "❤️", General: "🏥" };

export default function ServicesPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState<string | null>(null);
  const [toast, setToast] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    if (!user) { router.push("/auth/login"); return; }
    api.services.list().then(setServices).catch(console.error).finally(() => setLoading(false));
  }, [user]);

  function showToast(type: "success" | "error", text: string) {
    setToast({ type, text });
    setTimeout(() => setToast(null), 4000);
  }

  async function handleBook(service: any) {
    setBooking(service.code);
    try {
      const check = await api.services.check(service.code);
      if (check.covered) {
        const result = await api.bookings.book(service.code);
        showToast("success", `✅ ${service.name} booked! ${result.entitlementRemaining} uses remaining.`);
        api.services.list().then(setServices);
      } else {
        const orderRes = await api.bookings.payOrder(service.code);
        await api.bookings.payConfirm({
          serviceCode: service.code,
          razorpayOrderId: orderRes.order.id,
          razorpayPaymentId: `pay_demo_${Date.now()}`,
          razorpaySignature: "demo_signature",
        });
        showToast("success", `✅ ${service.name} booked! ₹${service.price} paid.`);
      }
    } catch (err: any) {
      showToast("error", err.message);
    } finally {
      setBooking(null);
    }
  }

  const categories = ["All", ...Array.from(new Set(services.map(s => s.category)))];
  const filtered = filter === "All" ? services : services.filter(s => s.category === filter);

  const page = { minHeight: "100vh", background: "#0b1120", fontFamily: "'Sora', sans-serif" } as React.CSSProperties;

  return (
    <div style={page}>
      <Navbar />

      {/* Toast */}
      {toast && (
        <div style={{ position: "fixed", top: 80, right: 24, zIndex: 100, background: toast.type === "success" ? "rgba(13,148,136,0.95)" : "rgba(220,38,38,0.95)", color: "#fff", padding: "14px 20px", borderRadius: 14, fontSize: 14, fontWeight: 600, boxShadow: "0 8px 32px rgba(0,0,0,0.4)", backdropFilter: "blur(8px)", maxWidth: 360 }}>
          {toast.text}
        </div>
      )}

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "36px 24px" }}>
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ color: "#f1f5f9", fontSize: 28, fontWeight: 800, margin: 0 }}>Diagnostic Services</h1>
          <p style={{ color: "#475569", fontSize: 14, marginTop: 6 }}>Services covered by your plan show remaining uses</p>
        </div>

        {/* Category pills */}
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 28 }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setFilter(cat)}
              style={{ padding: "8px 18px", borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: "pointer", border: "1px solid", transition: "all 0.15s",
                background: filter === cat ? "linear-gradient(135deg,#0d9488,#0891b2)" : "rgba(255,255,255,0.04)",
                borderColor: filter === cat ? "transparent" : "rgba(255,255,255,0.1)",
                color: filter === cat ? "#fff" : "#64748b" }}>
              {cat}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ textAlign: "center", color: "#2dd4bf", padding: 60, fontSize: 18 }}>Loading services…</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
            {filtered.map(service => {
              const covered = service.remaining > 0;
              return (
                <div key={service.id} style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${covered ? "rgba(45,212,191,0.3)" : "rgba(255,255,255,0.08)"}`, borderRadius: 20, padding: 24, display: "flex", flexDirection: "column", justifyContent: "space-between", gap: 16, transition: "border-color 0.2s" }}>
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                      <div>
                        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                          <span style={{ fontSize: 20 }}>{catIcon[service.category] || "🏥"}</span>
                          <span style={{ color: "#475569", fontSize: 11, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.08em" }}>{service.category}</span>
                        </div>
                        <div style={{ color: "#f1f5f9", fontWeight: 700, fontSize: 16 }}>{service.name}</div>
                      </div>
                      {covered && (
                        <span style={{ background: "rgba(13,148,136,0.2)", color: "#2dd4bf", fontSize: 11, fontWeight: 700, padding: "4px 10px", borderRadius: 999, border: "1px solid rgba(45,212,191,0.25)", whiteSpace: "nowrap" }}>
                          PLAN
                        </span>
                      )}
                    </div>
                    {service.description && <p style={{ color: "#475569", fontSize: 13, lineHeight: 1.5, margin: 0 }}>{service.description}</p>}
                  </div>

                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div>
                      {covered ? (
                        <>
                          <div style={{ color: "#2dd4bf", fontSize: 26, fontWeight: 800 }}>FREE</div>
                          <div style={{ color: "#475569", fontSize: 12 }}>{service.remaining} of {service.total} uses left</div>
                        </>
                      ) : (
                        <div style={{ color: "#f1f5f9", fontSize: 26, fontWeight: 800 }}>₹{service.price}</div>
                      )}
                    </div>
                    <button onClick={() => handleBook(service)} disabled={booking === service.code}
                      style={{ padding: "10px 20px", borderRadius: 12, fontWeight: 700, fontSize: 14, border: "none", cursor: booking === service.code ? "not-allowed" : "pointer", transition: "opacity 0.15s", opacity: booking === service.code ? 0.6 : 1,
                        background: covered ? "linear-gradient(135deg,#0d9488,#0891b2)" : "rgba(255,255,255,0.07)",
                        color: covered ? "#fff" : "#94a3b8",
                        border: covered ? "none" : "1px solid rgba(255,255,255,0.12)" as any }}>
                      {booking === service.code ? "…" : covered ? "Book Free" : "Book & Pay"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
