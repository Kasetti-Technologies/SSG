"use client";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { useRouter, usePathname } from "next/navigation";

export default function Navbar() {
  const { user, logout } = useAuth();
  const router = useRouter();
  const path = usePathname();

  const links = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/services", label: "Services" },
    { href: "/plans", label: "Plans" },
    { href: "/bookings", label: "Bookings" },
  ];

  return (
    <nav style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(16px)", borderBottom: "1px solid rgba(255,255,255,0.07)", position: "sticky", top: 0, zIndex: 50, fontFamily: "'Sora', sans-serif" }}>
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px", height: 60, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <Link href="/dashboard" style={{ textDecoration: "none", display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 22 }}>🏥</span>
          <span style={{ color: "#2dd4bf", fontWeight: 800, fontSize: 18, letterSpacing: "-0.5px" }}>HealthCare+</span>
        </Link>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {links.map(({ href, label }) => (
            <Link key={href} href={href} style={{ padding: "6px 14px", borderRadius: 8, fontSize: 14, fontWeight: 500, textDecoration: "none", color: path === href ? "#2dd4bf" : "#64748b", background: path === href ? "rgba(45,212,191,0.1)" : "transparent", transition: "all 0.15s" }}>
              {label}
            </Link>
          ))}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: "#475569", fontSize: 14 }}>{user?.name}</span>
          <button onClick={() => { logout(); router.push("/"); }}
            style={{ padding: "6px 14px", borderRadius: 8, fontSize: 13, fontWeight: 600, background: "transparent", border: "1px solid rgba(239,68,68,0.3)", color: "#f87171", cursor: "pointer" }}>
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}
