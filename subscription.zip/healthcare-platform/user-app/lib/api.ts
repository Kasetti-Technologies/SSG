const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001";

function getToken(): string | null {
  if (typeof window === "undefined") return null;
  return localStorage.getItem("hp_token");
}

async function apiFetch<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Request failed" }));
    throw new Error(err.error || "Request failed");
  }
  return res.json();
}

export const api = {
  auth: {
    register: (data: {
      name: string;
      email: string;
      phone?: string;
      password: string;
    }) =>
      apiFetch<{ token: string; user: any }>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    login: (data: { email: string; password: string }) =>
      apiFetch<{ token: string; user: any }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify(data),
      }),
  },
  services: {
    list: () => apiFetch<any[]>("/api/services"),
    check: (code: string) => apiFetch<any>(`/api/bookings/check/${code}`),
  },
  packages: {
    list: () => apiFetch<any[]>("/api/packages"),
    mySubscription: () => apiFetch<any>("/api/subscriptions/my"),
  },
  subscriptions: {
    createOrder: (packageId: string) =>
      apiFetch<any>("/api/subscriptions/order", {
        method: "POST",
        body: JSON.stringify({ packageId }),
      }),
    activate: (data: {
      packageId: string;
      razorpayOrderId: string;
      razorpayPaymentId: string;
      razorpaySignature: string;
    }) =>
      apiFetch<any>("/api/subscriptions/activate", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    cancel: (id: string) =>
      apiFetch<any>(`/api/subscriptions/${id}`, { method: "DELETE" }),
  },
  bookings: {
    book: (serviceCode: string, scheduledAt?: string) =>
      apiFetch<any>("/api/bookings/book", {
        method: "POST",
        body: JSON.stringify({ serviceCode, scheduledAt }),
      }),
    payOrder: (serviceCode: string) =>
      apiFetch<any>("/api/bookings/pay/order", {
        method: "POST",
        body: JSON.stringify({ serviceCode }),
      }),
    payConfirm: (data: any) =>
      apiFetch<any>("/api/bookings/pay/confirm", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    myBookings: () => apiFetch<any[]>("/api/bookings/my"),
  },
};
