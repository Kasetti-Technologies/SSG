# Webhook Forwarder Dashboard

A web application that receives JSON webhook payloads, displays them in a live dashboard, and forwards them to up to two configured endpoints.

---

## Local Setup (Without Docker)

### Prerequisites
- Node.js v18+ → https://nodejs.org
- PostgreSQL v14+ → https://www.postgresql.org/download/

---

### Step 1 — Create PostgreSQL Database

Open your PostgreSQL client (psql or pgAdmin) and run:

```sql
CREATE DATABASE webhook_forwarder;
```

---

### Step 2 — Setup Backend

```bash
cd backend
npm install
```

Create a `.env` file:

```bash
cp .env.example .env
```

Edit `.env` and set your database credentials:

```
PORT=4000
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/webhook_forwarder
FRONTEND_URL=http://localhost:3000
```

Start the backend:

```bash
npm start
```

The backend will auto-create the required tables on first run.
Backend runs at: http://localhost:4000

---

### Step 3 — Setup Frontend

Open a new terminal:

```bash
cd frontend
npm install
```

Create a `.env` file:

```bash
echo "REACT_APP_API_URL=http://localhost:4000" > .env
```

Start the frontend:

```bash
npm start
```

Frontend runs at: http://localhost:3000

---

### Step 4 — Test the Webhook

Send a test payload using curl:

```bash
curl -X POST http://localhost:4000/webhook \
  -H "Content-Type: application/json" \
  -d '{"name": "John", "amount": 100, "status": "active"}'
```

Or use Postman/Insomnia to POST to `http://localhost:4000/webhook`.

The dashboard at http://localhost:3000 will refresh every 3 seconds automatically.

---

## Local Setup (With Docker)

### Prerequisites
- Docker Desktop → https://www.docker.com/products/docker-desktop/
- Docker Compose (included with Docker Desktop)

### Start Everything

```bash
docker-compose up --build
```

This starts:
- PostgreSQL on port 5432
- Backend API on port 4000
- Frontend on port 3000

Open http://localhost:3000 in your browser.

### Stop

```bash
docker-compose down
```

To also remove the database volume:

```bash
docker-compose down -v
```

---

## API Reference

| Method | Endpoint        | Description                        |
|--------|-----------------|------------------------------------|
| POST   | /webhook        | Receive a JSON payload             |
| GET    | /latest-json    | Get the latest stored payload      |
| GET    | /endpoints      | Get configured forwarding URLs     |
| PUT    | /endpoints      | Update forwarding URLs             |
| GET    | /health         | Health check                       |

---

## Project Structure

```
webhook-forwarder/
├── backend/
│   ├── server.js          # Express API server
│   ├── db.js              # PostgreSQL connection & init
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.js         # Main React dashboard
│   │   ├── App.css        # Styles
│   │   └── index.js
│   ├── public/
│   │   └── index.html
│   ├── package.json
│   └── Dockerfile
├── docker-compose.yml
└── README.md
```
