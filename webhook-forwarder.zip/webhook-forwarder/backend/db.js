const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

const initDB = async () => {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS settings (
        id SERIAL PRIMARY KEY,
        endpoint1 TEXT,
        endpoint2 TEXT
      );
    `);
    await client.query(`
      INSERT INTO settings (endpoint1, endpoint2)
      SELECT NULL, NULL
      WHERE NOT EXISTS (SELECT 1 FROM settings);
    `);
    await client.query(`
      CREATE TABLE IF NOT EXISTS latest_payload (
        id SERIAL PRIMARY KEY,
        payload JSONB,
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    await client.query(`
      INSERT INTO latest_payload (payload, updated_at)
      SELECT NULL, NOW()
      WHERE NOT EXISTS (SELECT 1 FROM latest_payload);
    `);
    console.log('✅ Database initialized');
  } finally {
    client.release();
  }
};

module.exports = { pool, initDB };
