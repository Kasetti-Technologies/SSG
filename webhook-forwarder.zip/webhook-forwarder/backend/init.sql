-- Create settings table
CREATE TABLE IF NOT EXISTS settings (
    id SERIAL PRIMARY KEY,
    endpoint1 TEXT,
    endpoint2 TEXT
);

-- Seed one row so we always have a settings record
INSERT INTO settings (endpoint1, endpoint2)
SELECT NULL, NULL
WHERE NOT EXISTS (SELECT 1 FROM settings);

-- Create latest_payload table
CREATE TABLE IF NOT EXISTS latest_payload (
    id SERIAL PRIMARY KEY,
    payload JSONB,
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Seed one row so we always have a payload record
INSERT INTO latest_payload (payload, updated_at)
SELECT NULL, NOW()
WHERE NOT EXISTS (SELECT 1 FROM latest_payload);
