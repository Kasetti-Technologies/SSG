const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const { pool, initDB } = require('./db');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type'],
}));

app.use(express.json({ limit: '10mb' }));

// ─── POST /webhook ────────────────────────────────────────────────────────────
app.post('/webhook', async (req, res) => {
  const payload = req.body;

  if (!payload || typeof payload !== 'object') {
    return res.status(400).json({ error: 'Invalid JSON payload' });
  }

  const client = await pool.connect();
  try {
    // Upsert latest payload (always id=1)
    await client.query(`
      UPDATE latest_payload SET payload = $1, updated_at = NOW() WHERE id = 1
    `, [JSON.stringify(payload)]);

    // Get configured endpoints
    const { rows } = await client.query('SELECT endpoint1, endpoint2 FROM settings WHERE id = 1');
    const { endpoint1, endpoint2 } = rows[0] || {};

    const forwardResults = [];

    const forwardTo = async (url, label) => {
      if (!url || url.trim() === '') {
        forwardResults.push({ label, url: null, status: 'not_configured' });
        return;
      }
      try {
        await axios.post(url.trim(), payload, {
          timeout: 8000,
          headers: { 'Content-Type': 'application/json' },
        });
        forwardResults.push({ label, url, status: 'success' });
      } catch (err) {
        forwardResults.push({
          label,
          url,
          status: 'failed',
          error: err.message,
        });
      }
    };

    await Promise.all([
      forwardTo(endpoint1, 'endpoint1'),
      forwardTo(endpoint2, 'endpoint2'),
    ]);

    // Persist forwarding status
    await client.query(`
      UPDATE latest_payload SET forward_status = $1 WHERE id = 1
    `, [JSON.stringify(forwardResults)]).catch(() => {
      // Column may not exist yet; handle gracefully
    });

    res.json({
      message: 'Payload received',
      forwarding: forwardResults,
    });
  } finally {
    client.release();
  }
});

// ─── GET /latest-json ─────────────────────────────────────────────────────────
app.get('/latest-json', async (req, res) => {
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT payload, updated_at, forward_status FROM latest_payload WHERE id = 1');
    const row = rows[0];
    res.json({
      payload: row?.payload ?? null,
      updated_at: row?.updated_at ?? null,
      forward_status: row?.forward_status ?? null,
    });
  } finally {
    client.release();
  }
});

// ─── GET /endpoints ───────────────────────────────────────────────────────────
app.get('/endpoints', async (req, res) => {
  const client = await pool.connect();
  try {
    const { rows } = await client.query('SELECT endpoint1, endpoint2 FROM settings WHERE id = 1');
    res.json(rows[0] || { endpoint1: null, endpoint2: null });
  } finally {
    client.release();
  }
});

// ─── PUT /endpoints ───────────────────────────────────────────────────────────
app.put('/endpoints', async (req, res) => {
  const { endpoint1, endpoint2 } = req.body;
  const client = await pool.connect();
  try {
    await client.query(
      'UPDATE settings SET endpoint1 = $1, endpoint2 = $2 WHERE id = 1',
      [endpoint1 || null, endpoint2 || null]
    );
    res.json({ message: 'Endpoints updated', endpoint1: endpoint1 || null, endpoint2: endpoint2 || null });
  } finally {
    client.release();
  }
});

// ─── Health check ─────────────────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok' }));

// ─── Add forward_status column if missing then start ──────────────────────────
const start = async () => {
  await initDB();
  // Add forward_status column if it doesn't exist
  const client = await pool.connect();
  try {
    await client.query(`
      ALTER TABLE latest_payload ADD COLUMN IF NOT EXISTS forward_status JSONB;
    `);
  } finally {
    client.release();
  }
  app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
  });
};

start().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
