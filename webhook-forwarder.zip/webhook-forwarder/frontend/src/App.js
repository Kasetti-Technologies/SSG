import React, { useState, useEffect, useCallback, useRef } from 'react';
import './App.css';

const API = process.env.REACT_APP_API_URL || '';

function useInterval(cb, delay) {
  const savedCb = useRef(cb);
  useEffect(() => { savedCb.current = cb; }, [cb]);
  useEffect(() => {
    if (delay === null) return;
    const id = setInterval(() => savedCb.current(), delay);
    return () => clearInterval(id);
  }, [delay]);
}

const StatusBadge = ({ status }) => {
  const map = {
    success: { label: 'Success', cls: 'badge-success' },
    failed: { label: 'Failed', cls: 'badge-failed' },
    not_configured: { label: 'Not Configured', cls: 'badge-nc' },
  };
  const info = map[status] || { label: status, cls: 'badge-nc' };
  return <span className={`badge ${info.cls}`}>{info.label}</span>;
};

const CopyButton = ({ text }) => {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button className="copy-btn" onClick={copy} title="Copy to clipboard">
      {copied ? (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      ) : (
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
      )}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
};

export default function App() {
  const [latestData, setLatestData] = useState(null);
  const [endpoints, setEndpoints] = useState({ endpoint1: '', endpoint2: '' });
  const [epInput, setEpInput] = useState({ endpoint1: '', endpoint2: '' });
  const [showEndpoints, setShowEndpoints] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveMsg, setSaveMsg] = useState('');
  const [pulseKey, setPulseKey] = useState(0);
  const prevPayloadRef = useRef(null);

  const fetchLatest = useCallback(async () => {
    try {
      const res = await fetch(`${API}/latest-json`);
      const data = await res.json();
      if (JSON.stringify(data.payload) !== JSON.stringify(prevPayloadRef.current)) {
        if (prevPayloadRef.current !== null) setPulseKey(k => k + 1);
        prevPayloadRef.current = data.payload;
      }
      setLatestData(data);
    } catch (e) { /* silent */ }
  }, []);

  const fetchEndpoints = useCallback(async () => {
    try {
      const res = await fetch(`${API}/endpoints`);
      const data = await res.json();
      setEndpoints(data);
      setEpInput({ endpoint1: data.endpoint1 || '', endpoint2: data.endpoint2 || '' });
    } catch (e) { /* silent */ }
  }, []);

  useEffect(() => {
    fetchLatest();
    fetchEndpoints();
  }, [fetchLatest, fetchEndpoints]);

  useInterval(fetchLatest, 3000);

  const handleSaveEndpoints = async () => {
    setSaving(true);
    setSaveMsg('');
    try {
      const res = await fetch(`${API}/endpoints`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint1: epInput.endpoint1, endpoint2: epInput.endpoint2 }),
      });
      if (res.ok) {
        setSaveMsg('saved');
        await fetchEndpoints();
      } else {
        setSaveMsg('error');
      }
    } catch {
      setSaveMsg('error');
    } finally {
      setSaving(false);
      setTimeout(() => setSaveMsg(''), 3000);
    }
  };

  const webhookUrl = `${window.location.protocol}//${window.location.hostname}${window.location.port && window.location.port !== '80' && window.location.port !== '443' ? ':4000' : ''}/webhook`;

  const forwardStatus = latestData?.forward_status || null;

  const formatTime = (ts) => {
    if (!ts) return '—';
    const d = new Date(ts);
    return d.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'medium' });
  };

  const configuredCount = [endpoints.endpoint1, endpoints.endpoint2].filter(e => e && e.trim()).length;

  return (
    <div className="app">
      {/* Header */}
      <header className="header">
        <div className="header-left">
          <div className="logo">
            <div className="logo-icon">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
            </div>
            <span className="logo-text">WebhookForwarder</span>
          </div>
        </div>
        <div className="header-right">
          <div className="status-pill">
            <span className="dot-live"></span>
            <span>Live</span>
          </div>
        </div>
      </header>

      <main className="main">
        {/* Top bar: Webhook URL */}
        <section className="card webhook-card">
          <div className="card-label">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
            Your Webhook Endpoint
          </div>
          <div className="webhook-url-row">
            <span className="method-badge">POST</span>
            <code className="webhook-url">{webhookUrl}</code>
            <CopyButton text={webhookUrl} />
          </div>
          <p className="webhook-hint">Send any valid JSON payload to this URL. It will be captured and forwarded automatically.</p>
        </section>

        <div className="grid-2">
          {/* Latest Payload */}
          <section className="card payload-card" key={pulseKey}>
            <div className="card-header">
              <div className="card-label">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                Latest Payload
              </div>
              {latestData?.updated_at && (
                <span className="timestamp">
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                  {formatTime(latestData.updated_at)}
                </span>
              )}
            </div>
            {latestData?.payload ? (
              <div className="json-wrapper">
                <div className="json-toolbar">
                  <span className="json-lines">{JSON.stringify(latestData.payload, null, 2).split('\n').length} lines</span>
                  <CopyButton text={JSON.stringify(latestData.payload, null, 2)} />
                </div>
                <pre className="json-block">{JSON.stringify(latestData.payload, null, 2)}</pre>
              </div>
            ) : (
              <div className="empty-state">
                <div className="empty-icon">
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                </div>
                <p>No payload received yet</p>
                <span>Send a POST request to your webhook URL to get started</span>
              </div>
            )}
          </section>

          {/* Right column */}
          <div className="right-col">
            {/* Forwarding Status */}
            <section className="card status-card">
              <div className="card-label">
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                Forwarding Status
              </div>
              <div className="status-rows">
                {['endpoint1', 'endpoint2'].map((ep, i) => {
                  const fwd = forwardStatus?.find(f => f.label === ep);
                  return (
                    <div className="status-row" key={ep}>
                      <span className="ep-label">Endpoint {i + 1}</span>
                      <StatusBadge status={fwd?.status || 'not_configured'} />
                      {fwd?.error && <span className="fwd-error" title={fwd.error}>⚠ {fwd.error.slice(0, 40)}{fwd.error.length > 40 ? '…' : ''}</span>}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Configure Endpoints */}
            <section className="card endpoint-card">
              <div className="card-header">
                <div className="card-label">
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>
                  Configure Forwarding
                </div>
                <span className="configured-count">{configuredCount}/2 configured</span>
              </div>

              <div className="ep-form">
                {['endpoint1', 'endpoint2'].map((ep, i) => (
                  <div className="ep-field" key={ep}>
                    <label className="ep-field-label">Endpoint {i + 1}</label>
                    <div className="ep-input-row">
                      <div className={`ep-dot ${epInput[ep] ? 'ep-dot-active' : ''}`}></div>
                      <input
                        type="url"
                        className="ep-input"
                        placeholder={`https://your-service.com/hook-${i + 1}`}
                        value={epInput[ep]}
                        onChange={e => setEpInput(prev => ({ ...prev, [ep]: e.target.value }))}
                      />
                    </div>
                  </div>
                ))}

                <div className="ep-actions">
                  <button
                    className={`save-btn ${saving ? 'saving' : ''} ${saveMsg === 'saved' ? 'saved' : ''} ${saveMsg === 'error' ? 'errored' : ''}`}
                    onClick={handleSaveEndpoints}
                    disabled={saving}
                  >
                    {saving ? (
                      <><span className="spinner"></span> Saving…</>
                    ) : saveMsg === 'saved' ? (
                      <><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg> Saved!</>
                    ) : saveMsg === 'error' ? (
                      '✗ Error'
                    ) : (
                      <>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                        Save Endpoints
                      </>
                    )}
                  </button>

                  <button className="show-ep-btn" onClick={() => setShowEndpoints(v => !v)}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                    {showEndpoints ? 'Hide' : 'Show'} Configured Endpoints
                  </button>
                </div>

                {showEndpoints && (
                  <div className="ep-view">
                    {['endpoint1', 'endpoint2'].map((ep, i) => (
                      <div className="ep-view-row" key={ep}>
                        <span className="ep-view-label">Endpoint {i + 1}</span>
                        {endpoints[ep] ? (
                          <code className="ep-view-url">{endpoints[ep]}</code>
                        ) : (
                          <span className="ep-view-empty">— not configured —</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
